extends Node
## Run orchestration (autoload: GM).

const RoadGen = preload("res://scripts/game/road_generator.gd")
const TrafficMgr = preload("res://scripts/game/traffic_manager.gd")
const PlayerCtl = preload("res://scripts/game/player_controller.gd")
const CamCtl = preload("res://scripts/game/camera_controller.gd")
const EconMgr = preload("res://scripts/game/economy_manager.gd")
const WeatherMgr = preload("res://scripts/game/weather_manager.gd")
const TodMgr = preload("res://scripts/game/time_of_day_manager.gd")
const InputMgr = preload("res://scripts/game/input_manager.gd")

var main
var ui
var input
var state := "menu"
var paused := false
var run: Node3D
var cfg: Dictionary = {}
var road
var traffic
var player
var cam
var econ
var weather
var tod
var run_time := 0.0
var time_left := 0.0
var end_timer := 0.0
var end_reason := ""
var last_s := 0.0
var results: Dictionary = {}
var collisions_run := 0

func _ready() -> void:
	input = InputMgr.new()
	add_child(input)
	apply_graphics()

func apply_graphics() -> void:
	Engine.max_fps = Save.si("fps")
	var q = Save.si("quality")
	get_viewport().msaa_3d = Viewport.MSAA_2X if q >= 3 else Viewport.MSAA_DISABLED
	var sh = Save.si("shadow")
	RenderingServer.directional_shadow_atlas_set_size([1024, 1024, 2048, 4096][sh], true)
	Sfx.apply_volumes()

func apply_quality_preset(q: int) -> void:
	var presets = [
		{"shadow": 0, "traffic_gfx": 0, "render": 0, "fx": 0},
		{"shadow": 1, "traffic_gfx": 1, "render": 1, "fx": 1},
		{"shadow": 2, "traffic_gfx": 2, "render": 2, "fx": 2},
		{"shadow": 3, "traffic_gfx": 2, "render": 3, "fx": 2},
	]
	Save.set_s("quality", q)
	for k in presets[q].keys():
		Save.set_s(k, presets[q][k])
	apply_graphics()

func build_cfg() -> Dictionary:
	var map = GameData.MAPS[clampi(Save.su("map"), 0, GameData.MAPS.size() - 1)]
	var tod_i = Save.su("tod")
	if int(map["force_tod"]) >= 0:
		tod_i = int(map["force_tod"])
	if tod_i == 4:
		tod_i = randi() % 4
	var wx = Save.su("weather")
	if wx == 3:
		wx = randi() % 3
	var fx = Save.si("fx")
	var c = {
		"mode": Save.su("mode"),
		"time_limit": float(GameData.TIME_LIMITS[clampi(Save.su("tl"), 0, 4)]),
		"map": map,
		"tod": tod_i,
		"weather": wx,
		"two_way": Save.su("road") == 1,
		"diff": clampi(Save.su("diff"), 0, 3),
		"density": clampf(float(Save.data["setup"]["density"]), 0.1, 1.0),
		"seed": randi() % 1000000 + 1,
		"q": {
			"shadow": Save.si("shadow"),
			"traffic_scale": float(GameData.TRAFFIC_GFX[Save.si("traffic_gfx")]),
			"render": float(GameData.RENDER_DISTS[Save.si("render")]),
			"fx": fx,
			"fx_scale": [0.4, 0.7, 1.0][clampi(fx, 0, 2)],
		},
	}
	return c

func start_run() -> void:
	if state != "menu":
		return
	cfg = build_cfg()
	apply_graphics()
	main.showroom.set_active(false)
	run = Node3D.new()
	run.name = "RunWorld"
	main.add_child(run)
	road = RoadGen.new()
	run.add_child(road)
	road.setup(cfg)
	player = PlayerCtl.new()
	run.add_child(player)
	player.setup(cfg, road, self)
	road.prebuild(player.s)
	cam = CamCtl.new()
	run.add_child(cam)
	cam.setup(player, cfg)
	tod = TodMgr.new()
	tod.setup(run, cam.camera, road, cfg)
	weather = WeatherMgr.new()
	weather.setup(run, cam.camera, road, player, cfg)
	traffic = TrafficMgr.new()
	run.add_child(traffic)
	traffic.setup(self, road, player, cfg)
	econ = EconMgr.new()
	econ.setup(self, cfg)
	run_time = 0.0
	time_left = float(cfg["time_limit"]) if cfg["mode"] == 1 else 0.0
	last_s = player.s
	collisions_run = 0
	paused = false
	end_timer = 0.0
	input.reset()
	if Save.si("steer_mode") == 2:
		input.calibrate()
	input.active = true
	ui.show_hud(cfg)
	Sfx.start_drive(player.phys.st)
	state = "running"

func toast(text: String, col: Color) -> void:
	if ui != null and ui.hud != null:
		ui.hud.toast(text, col)

func set_paused(p: bool) -> void:
	if state != "running" and state != "ending":
		return
	paused = p
	input.active = not p
	if p:
		input.reset()
		Sfx.set_drive_muted(true)
	else:
		Sfx.set_drive_muted(false)
	ui.hud.show_pause(p)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED and state == "running":
		set_paused(true)

func on_player_impact(impact: float, v) -> void:
	if state != "running" and state != "ending":
		return
	if impact < 1.2:
		return
	if player.hit_cd <= 0.0:
		player.hit_cd = 0.4
		collisions_run += 1
		Save.stat_add("collisions", 1.0)
	if impact > 4.0:
		econ.collision_reset()
	Sfx.play("crash" if impact > 6.0 else "scrape", clampf(-12.0 + impact, -10.0, 4.0), randf_range(0.9, 1.1))
	if Save.sb("vibration"):
		Input.vibrate_handheld(int(clampf(impact * 12.0, 30.0, 400.0)))
	if impact > 3.5:
		toast("COLLISION", Color(1.0, 0.3, 0.25))
	var dmg_set = Save.si("damage")
	if dmg_set == 0:
		return
	var dmg = pow(impact / 22.0, 2.0) * 100.0 * (1.4 if dmg_set == 2 else 1.0)
	player.damage = clampf(player.damage + dmg, 0.0, 100.0)
	if impact > 3.0:
		player.apply_visual_damage()
	if cfg["mode"] != 2 and state == "running" and (player.damage >= 100.0 or impact > 30.0):
		begin_end("crash")

func begin_end(reason: String) -> void:
	if state != "running":
		return
	state = "ending"
	end_reason = reason
	end_timer = 2.8 if reason == "crash" else 1.6

func _process(delta: float) -> void:
	if (state == "running" or state == "ending") and not paused:
		_run_step(minf(delta, 0.05))

func _run_step(dt: float) -> void:
	var inp = input.get_state(dt, player.speed())
	if state == "ending":
		inp = {"steer": 0.0, "throttle": 0.0, "brake": 0.7}
		end_timer -= dt
		if end_timer <= 0.0:
			finish_run()
			return
	else:
		run_time += dt
		if cfg["mode"] == 1:
			time_left -= dt
			if time_left <= 0.0:
				time_left = 0.0
				begin_end("time")
	var steps = clampi(ceili(dt * (player.speed() + 30.0) / 3.0), 1, 4)
	var sub = dt / float(steps)
	for i in steps:
		player.step(sub, inp)
		traffic.step(sub)
	road.update(player.s, dt)
	road.follow(player.global_position)
	var ds = player.s - last_s
	last_s = player.s
	if state == "running":
		econ.update(dt, player.speed(), maxf(ds, 0.0))
		Save.data["stats"]["top_speed"] = maxf(float(Save.data["stats"]["top_speed"]), player.speed())
	tod.update(dt, road.tunnel_at(player.s))
	var dark = tod.effective_dark()
	traffic.dark = dark
	traffic.frame(dt)
	weather.update(dt)
	player.update_visuals(dt)
	player.set_lights(dark)
	cam.update(dt)
	var ph = player.phys
	var rf = clampf((ph.rpm - float(ph.st["idle"])) / (float(ph.st["red"]) - float(ph.st["idle"])), 0.0, 1.0)
	Sfx.update_drive(rf, ph.thr, player.speed(), ph.slip, weather.raining, player.offroad, ph.brk, ph.st)
	ui.hud.update_hud({
		"speed": GameData.speed_val(player.speed()),
		"unit": GameData.speed_unit(),
		"dist": econ.distance,
		"time": run_time,
		"time_left": time_left,
		"mode": cfg["mode"],
		"money": econ.earned,
		"mult": econ.mult,
		"tier": econ.tier,
		"damage": player.damage,
		"gear": ph.gear,
		"rpm": rf,
		"top": float(ph.st["top"]) * 3.6,
	})

func finish_run() -> void:
	if state == "results":
		return
	state = "results"
	input.active = false
	Sfx.stop_drive()
	var dist = econ.distance
	var earned = int(econ.earned)
	var prev_best = Save.stat("best_dist")
	var rec = dist > prev_best
	Save.stat_add("total_dist", dist)
	Save.stat_max("best_dist", dist)
	Save.stat_add("total_time", run_time)
	Save.stat_add("money_total", float(earned))
	Save.stat_add("overtakes", float(econ.overtakes))
	Save.stat_add("near_misses", float(econ.near_misses))
	Save.stat_max("best_streak", econ.best_streak)
	Save.add_money(float(earned))
	var ta_rec = false
	if cfg["mode"] == 1:
		var key = str(int(cfg["time_limit"]))
		var prev = float(Save.data["best_ta"].get(key, 0.0))
		if dist > prev:
			Save.data["best_ta"][key] = dist
			ta_rec = true
	Save.save_now()
	results = {"dist": dist, "time": run_time, "earned": earned, "overtakes": econ.overtakes, "near": econ.near_misses,
		"top": player.top_speed_run, "streak": econ.best_streak, "damage": player.damage, "record": rec or ta_rec,
		"reason": end_reason, "mode": cfg["mode"], "collisions": collisions_run}
	ui.show_results(results)

func leave_run() -> void:
	state = "menu"
	paused = false
	input.active = false
	if run != null:
		run.queue_free()
		run = null
	main.showroom.set_active(true)
	ui.show_screen("menu")

func quit_to_results() -> void:
	paused = false
	ui.hud.show_pause(false)
	end_reason = "quit"
	if state == "running" or state == "ending":
		state = "running"
		finish_run()
