extends Node3D
## 3D showroom used behind the menus: turntable car preview.

const CarB = preload("res://scripts/game/car_builder.gd")

var cam: Camera3D
var car_root: Node3D
var holder: Node3D
var spin := 0.4
var auto := true
var car_id := "compact"
var h_off := -1.5

func _ready() -> void:
	var env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.04, 0.05, 0.08)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.45, 0.5, 0.65)
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	cam = Camera3D.new()
	cam.environment = env
	cam.fov = 38.0
	cam.near = 0.2
	cam.far = 100.0
	add_child(cam)
	cam.position = Vector3(0, 1.5, 8.2)
	cam.h_offset = h_off
	cam.look_at(Vector3(0, 0.6, 0), Vector3.UP)
	var sun = DirectionalLight3D.new()
	sun.light_energy = 1.2
	sun.rotation_degrees = Vector3(-40, 35, 0)
	add_child(sun)
	for p in [[Vector3(-4, 3, 3), Color(1.0, 0.6, 0.3)], [Vector3(4, 2.5, -3), Color(0.3, 0.6, 1.0)]]:
		var o = OmniLight3D.new()
		o.position = p[0]
		o.light_color = p[1]
		o.light_energy = 2.0
		o.omni_range = 14.0
		add_child(o)
	var fl = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 3.6
	cm.bottom_radius = 3.6
	cm.height = 0.1
	fl.mesh = cm
	fl.position = Vector3(0, -0.05, 0)
	var fm = StandardMaterial3D.new()
	fm.albedo_color = Color(0.1, 0.11, 0.14)
	fm.metallic = 0.6
	fm.roughness = 0.25
	fl.material_override = fm
	add_child(fl)
	var ring = MeshInstance3D.new()
	var tm = TorusMesh.new()
	tm.inner_radius = 3.5
	tm.outer_radius = 3.62
	ring.mesh = tm
	ring.position = Vector3(0, 0.02, 0)
	var rm = StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color(1.0, 0.62, 0.1)
	ring.material_override = rm
	add_child(ring)
	holder = Node3D.new()
	add_child(holder)
	cam.make_current()

func set_active(a: bool) -> void:
	visible = a
	if a:
		cam.make_current()
		refresh()

func show_car(id: String) -> void:
	car_id = id
	refresh()

func refresh() -> void:
	if car_root != null:
		car_root.queue_free()
		car_root = null
	var parts = CarB.build_player(car_id)
	car_root = parts["root"]
	for sp in parts["spots"]:
		sp.light_energy = 0.0
	holder.add_child(car_root)
	car_root.rotation.y = spin

func _process(dt: float) -> void:
	if not visible or car_root == null:
		return
	if auto:
		spin += dt * 0.35
	car_root.rotation.y = spin
