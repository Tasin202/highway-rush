extends Node3D
## Procedural endless road: samples every 4 m, chunked meshes built incrementally.

const MeshBuf = preload("res://scripts/game/mesh_buf.gd")
const STEP := 4.0
const CH := 32
const RAMP := [0.0, 0.0, 0.12, 0.4, 0.8, 1.0, 1.0]
const COAST_DROP := [0.1, 0.6, 5.0, 14.0, 30.0, 40.0, 40.0]

var map: Dictionary = {}
var two_way := false
var half_w := 5.4
var lanes_fwd: Array = []
var lanes_opp: Array = []
var render_dist := 600.0
var fx := 1.0
var seed_v := 1
var rng := RandomNumberGenerator.new()
var P := PackedVector3Array()
var H := PackedFloat32Array()
var RT := PackedVector3Array()
var GR := PackedFloat32Array()
var K := PackedFloat32Array()
var TN := PackedByteArray()
var base_idx := 0
var seg_left := 0
var seg_total := 1
var seg_i := 0
var seg_k := 0.0
var seg_g := 0.0
var seg_type := "straight"
var seg_tunnel := false
var seg_cycles := 1.0
var last_type := ""
var chunks := {}
var work = null
var mat_road: StandardMaterial3D
var mat_solid: StandardMaterial3D
var mat_glow: StandardMaterial3D
var mat_add: StandardMaterial3D
var mat_ring: StandardMaterial3D
var noise := FastNoiseLite.new()
var noise2 := FastNoiseLite.new()
var offs := []
var ring: MeshInstance3D
var water: MeshInstance3D
var cast_shadow := false
var C_ground: Color
var C_ground2: Color
var C_rock: Color
var C_snow: Color
var scenery := "city"
var hills := 0.0

func setup(cfg: Dictionary) -> void:
	map = cfg["map"]
	two_way = cfg["two_way"]
	seed_v = cfg["seed"]
	render_dist = cfg["q"]["render"]
	fx = cfg["q"]["fx_scale"]
	cast_shadow = cfg["q"]["shadow"] >= 2
	rng.seed = seed_v
	scenery = map["scenery"]
	hills = float(map["hills"])
	C_ground = Color.html(map["ground"])
	C_ground2 = Color.html(map["ground2"])
	C_rock = Color.html(map["rock"])
	C_snow = Color.html(map["snow"])
	if two_way:
		half_w = 7.2
		lanes_fwd = [1.8, 5.4]
		lanes_opp = [-1.8, -5.4]
	else:
		half_w = 5.4
		lanes_fwd = [-3.6, 0.0, 3.6]
		lanes_opp = []
	offs = [half_w + 2.0, 12.0, 24.0, 50.0, 100.0, 220.0, 500.0]
	noise.seed = seed_v
	noise.frequency = 0.004
	noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	noise.fractal_octaves = 3
	noise2.seed = seed_v + 7
	noise2.frequency = 0.012
	_make_materials()
	P.append(Vector3.ZERO)
	H.append(0.0)
	RT.append(Vector3(1, 0, 0))
	GR.append(0.0)
	K.append(0.0)
	TN.append(0)
	seg_left = 90
	seg_total = 90
	seg_type = "straight"
	while P.size() < 260:
		_append_sample()
	_build_ring()
	if map["id"] == "coastal":
		water = MeshInstance3D.new()
		var pm = PlaneMesh.new()
		pm.size = Vector2(9000, 9000)
		water.mesh = pm
		var wm = StandardMaterial3D.new()
		wm.albedo_color = Color(0.06, 0.28, 0.42)
		wm.roughness = 0.12
		wm.metallic = 0.3
		water.material_override = wm
		add_child(water)

func _make_materials() -> void:
	mat_road = StandardMaterial3D.new()
	mat_road.vertex_color_use_as_albedo = true
	mat_road.roughness = 0.85
	mat_road.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat_solid = StandardMaterial3D.new()
	mat_solid.vertex_color_use_as_albedo = true
	mat_solid.roughness = 0.9
	mat_solid.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat_glow = StandardMaterial3D.new()
	mat_glow.vertex_color_use_as_albedo = true
	mat_glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_glow.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat_add = StandardMaterial3D.new()
	mat_add.vertex_color_use_as_albedo = true
	mat_add.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_add.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_add.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat_add.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	mat_add.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat_ring = StandardMaterial3D.new()
	mat_ring.vertex_color_use_as_albedo = true
	mat_ring.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_ring.disable_fog = true
	mat_ring.cull_mode = BaseMaterial3D.CULL_DISABLED
	set_darkness(0.0)

func set_darkness(d: float) -> void:
	var g = lerpf(0.35, 1.0, d)
	mat_glow.albedo_color = Color(g, g, g, 1)
	var a = clampf(d * d, 0.0, 1.0)
	mat_add.albedo_color = Color(a, a, a, 1)

func set_wet(w: float) -> void:
	mat_road.roughness = lerpf(0.85, 0.2, w)
	var c = lerpf(1.0, 0.7, w)
	mat_road.albedo_color = Color(c, c, c)

func set_haze(c: Color) -> void:
	mat_ring.albedo_color = c.darkened(0.15)

func follow(p: Vector3) -> void:
	if ring != null:
		ring.global_position = Vector3(p.x, p.y * 0.3 - 40.0, p.z)
	if water != null:
		water.global_position = Vector3(p.x, -6.0, p.z)

# ----------------------------------------------------------- lanes / lookup
func lane_count(dir: int) -> int:
	return lanes_fwd.size() if dir > 0 else lanes_opp.size()

func lane_d(dir: int, idx: int) -> float:
	return float(lanes_fwd[idx]) if dir > 0 else float(lanes_opp[idx])

func _loc(s: float) -> Vector2:
	var gi = s / STEP
	var fl = floorf(gi)
	var li = int(fl) - base_idx
	var f = gi - fl
	if li < 0:
		li = 0
		f = 0.0
	if li > P.size() - 2:
		li = P.size() - 2
		f = 1.0
	return Vector2(li, f)

func pos_at(s: float) -> Vector3:
	var l = _loc(s)
	var li = int(l.x)
	return P[li].lerp(P[li + 1], l.y)

func y_at(s: float) -> float:
	return pos_at(s).y

func heading_at(s: float) -> float:
	var l = _loc(s)
	var li = int(l.x)
	return lerpf(H[li], H[li + 1], l.y)

func grade_at(s: float) -> float:
	var l = _loc(s)
	return GR[int(l.x) + 1]

func tunnel_at(s: float) -> bool:
	var l = _loc(s)
	return TN[int(l.x)] == 1

func curvature_at(s: float) -> float:
	var l = _loc(s)
	return K[int(l.x)]

func to_world(s: float, d: float) -> Vector3:
	var h = heading_at(s)
	return pos_at(s) + Vector3(cos(h), 0, -sin(h)) * d

func project(p: Vector2, s_hint: float) -> Vector2:
	var s = s_hint
	for it in 3:
		var c = pos_at(s)
		var h = heading_at(s)
		var t = Vector2(-sin(h), -cos(h))
		s += Vector2(p.x - c.x, p.y - c.z).dot(t)
	var c2 = pos_at(s)
	var h2 = heading_at(s)
	return Vector2(s, Vector2(p.x - c2.x, p.y - c2.z).dot(Vector2(cos(h2), -sin(h2))))

# ----------------------------------------------------------- generation
func _new_segment() -> void:
	var curve = float(map["curve"])
	var grade = float(map["grade"])
	var w = {
		"straight": 4.0 / maxf(curve, 0.4),
		"gentle": 2.5 * curve,
		"tight": 0.9 * curve * curve,
		"uphill": 0.3 + grade * 0.5,
		"downhill": 0.3 + grade * 0.5,
		"rolling": 0.5 + grade * 0.5,
		"tunnel": float(map["tunnel"]) * 10.0,
	}
	var total = 0.0
	for k in w.keys():
		total += w[k]
	var pick = rng.randf() * total
	var typ = "straight"
	for k in w.keys():
		pick -= w[k]
		if pick <= 0.0:
			typ = k
			break
	if typ == last_type and (typ == "tight" or typ == "tunnel"):
		typ = "straight"
	last_type = typ
	seg_type = typ
	seg_tunnel = false
	seg_k = 0.0
	seg_g = 0.0
	seg_cycles = 1.0
	var length = 400.0
	var sgn = 1.0 if rng.randf() < 0.5 else -1.0
	match typ:
		"straight":
			length = rng.randf_range(300.0, 1400.0)
		"gentle":
			length = rng.randf_range(250.0, 800.0)
			seg_k = sgn / rng.randf_range(500.0, 1300.0)
		"tight":
			length = rng.randf_range(110.0, 260.0)
			seg_k = sgn / rng.randf_range(130.0, 260.0)
		"uphill", "downhill":
			length = rng.randf_range(220.0, 600.0)
			seg_g = rng.randf_range(0.03, 0.07) * clampf(grade, 0.3, 1.6) * (1.0 if typ == "uphill" else -1.0)
			if rng.randf() < 0.3:
				seg_k = sgn / rng.randf_range(900.0, 1800.0)
		"rolling":
			length = rng.randf_range(400.0, 1000.0)
			seg_g = 0.03 * clampf(grade, 0.3, 1.6)
			seg_cycles = float(rng.randi_range(2, 4))
			if rng.randf() < 0.4:
				seg_k = sgn / rng.randf_range(900.0, 2000.0)
		"tunnel":
			length = rng.randf_range(300.0, 900.0)
			seg_tunnel = true
			if rng.randf() < 0.4:
				seg_k = sgn / rng.randf_range(800.0, 1600.0)
	seg_total = maxi(int(length / STEP), 8)
	seg_left = seg_total
	seg_i = 0

func _append_sample() -> void:
	if seg_left <= 0:
		_new_segment()
	var t = float(seg_i) / float(maxi(seg_total - 1, 1))
	var env = smoothstep(0.0, 0.25, t) * (1.0 - smoothstep(0.75, 1.0, t))
	var k = seg_k * env
	var g = seg_g * env
	if seg_type == "rolling":
		g = seg_g * sin(t * TAU * seg_cycles) * minf(1.0, env * 1.5)
	var last = P.size() - 1
	var y = P[last].y
	if y > 40.0 and g > 0.0:
		g = 0.0
	if y < -12.0 and g < 0.0:
		g = 0.0
	var h = H[last] + k * STEP
	var f = Vector3(-sin(h), 0, -cos(h))
	P.append(P[last] + f * STEP + Vector3(0, g * STEP, 0))
	H.append(h)
	RT.append(Vector3(cos(h), 0, -sin(h)))
	GR.append(g)
	K.append(k)
	TN.append(1 if seg_tunnel else 0)
	seg_i += 1
	seg_left -= 1

func prebuild(ps: float) -> void:
	update(ps, 0.0, 1000000)
	var guard = 0
	while guard < 40:
		guard += 1
		update(ps, 0.0, 1000000)
		if work == null and _missing(ps) == -1:
			break

func _chunk_range(ps: float) -> Vector2i:
	var c0 = maxi(int(floorf((ps - 150.0) / (CH * STEP))), 0)
	var c1 = int(floorf((ps + render_dist) / (CH * STEP)))
	return Vector2i(c0, c1)

func _missing(ps: float) -> int:
	var r = _chunk_range(ps)
	for c in range(r.x, r.y + 1):
		if not chunks.has(c):
			return c
	return -1

func update(ps: float, dt: float, budget_us: int = 2500) -> void:
	var need = int((ps + render_dist + 250.0) / STEP) + 4
	while base_idx + P.size() < need:
		_append_sample()
	var r = _chunk_range(ps)
	for c in chunks.keys():
		if c < r.x:
			chunks[c].queue_free()
			chunks.erase(c)
	if work == null:
		var m = _missing(ps)
		if m >= 0:
			_begin_chunk(m)
	if work != null:
		_work_chunk(budget_us)
	var drop = r.x * CH - base_idx - 4
	if drop > 96:
		P = P.slice(drop)
		H = H.slice(drop)
		RT = RT.slice(drop)
		GR = GR.slice(drop)
		K = K.slice(drop)
		TN = TN.slice(drop)
		base_idx += drop

# ----------------------------------------------------------- chunk meshing
func _begin_chunk(c: int) -> void:
	work = {"c": c, "i": c * CH, "end": c * CH + CH, "road": MeshBuf.new(), "solid": MeshBuf.new(),
		"glow": MeshBuf.new(), "add": MeshBuf.new(), "rng": RandomNumberGenerator.new()}
	work["rng"].seed = hash(str(seed_v) + "c" + str(c))

func _work_chunk(budget_us: int) -> void:
	var t0 = Time.get_ticks_usec()
	while work["i"] < work["end"]:
		_build_sample(work, work["i"])
		work["i"] += 1
		if Time.get_ticks_usec() - t0 > budget_us:
			return
	var mesh = ArrayMesh.new()
	work["road"].to_mesh(mesh, mat_road)
	work["solid"].to_mesh(mesh, mat_solid)
	work["glow"].to_mesh(mesh, mat_glow)
	work["add"].to_mesh(mesh, mat_add)
	var mi = MeshInstance3D.new()
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	chunks[work["c"]] = mi
	work = null

func _pt(li: int, d: float, dy: float = 0.0) -> Vector3:
	return P[li] + RT[li] * d + Vector3(0, dy, 0)

func _ramp(off: float) -> float:
	if off <= offs[1]:
		return 0.0
	for k in range(1, offs.size()):
		if off <= offs[k]:
			var a = float(offs[k - 1])
			var b = float(offs[k])
			return lerpf(RAMP[k - 1], RAMP[k], (off - a) / (b - a))
	return 1.0

func _hy(p: Vector3, k: int, side: int, tn: bool) -> float:
	var ramp = float(RAMP[k])
	var y = -0.1
	if ramp > 0.0 and hills > 0.0:
		y += ramp * hills * (noise.get_noise_2d(p.x, p.z) * 0.5 + 0.35)
	if map["id"] == "coastal" and side < 0:
		y = -float(COAST_DROP[k])
	if tn and k <= 4:
		y = maxf(y, 6.2)
	return y

func _ground(li: int, side: int, off: float) -> Vector3:
	var p = P[li] + RT[li] * (float(side) * off)
	var y = -0.1
	var ramp = _ramp(off)
	if ramp > 0.0 and hills > 0.0:
		y += ramp * hills * (noise.get_noise_2d(p.x, p.z) * 0.5 + 0.35)
	if map["id"] == "coastal" and side < 0:
		y = -0.1 - ramp * 30.0
	p.y = P[li].y + y
	return p

func _col_pos(li: int, side: int, k: int) -> Vector3:
	var off = float(offs[k])
	var kk = K[li]
	if kk * float(-side) > 0.0 and absf(kk) > 0.0001:
		off = minf(off, 0.85 / absf(kk))
	var p = P[li] + RT[li] * (float(side) * off)
	p.y = P[li].y + _hy(p, k, side, TN[li] == 1)
	return p

func _tcol(k: int, p: Vector3, y_rel: float, side: int) -> Color:
	if k == 0:
		return Color(0.42, 0.4, 0.36)
	var n = noise2.get_noise_2d(p.x, p.z) * 0.5 + 0.5
	var c = C_ground.lerp(C_ground2, n)
	if scenery == "country":
		c = C_ground.lerp(C_ground2, smoothstep(0.35, 0.65, n))
	if map["id"] == "coastal" and side < 0:
		c = C_ground2 if y_rel > -4.0 else C_rock
	elif scenery == "mountain":
		if y_rel > 55.0:
			c = C_snow
		elif y_rel > 28.0:
			c = C_rock.lerp(C_snow, clampf((y_rel - 28.0) / 27.0, 0.0, 1.0) * 0.6)
		elif y_rel > 12.0:
			c = c.lerp(C_rock, clampf((y_rel - 12.0) / 16.0, 0.0, 1.0))
	if k == 1:
		c = c.lerp(Color(0.42, 0.4, 0.36), 0.35)
	return c

func _build_sample(w: Dictionary, i: int) -> void:
	var li = i - base_idx
	if li + 1 >= P.size():
		return
	var rd: MeshBuf = w["road"]
	var so: MeshBuf = w["solid"]
	var gl: MeshBuf = w["glow"]
	var ad: MeshBuf = w["add"]
	var rg: RandomNumberGenerator = w["rng"]
	var hw = half_w
	var tn = TN[li] == 1
	var v = 0.92 + 0.08 * float((i * 7919) % 5) / 4.0
	var asph = Color(0.2 * v, 0.2 * v, 0.215 * v)
	var shoulder = Color(0.27, 0.27, 0.28)
	# road surface
	rd.quad(_pt(li, -hw), _pt(li, hw), _pt(li + 1, hw), _pt(li + 1, -hw), asph)
	rd.quad(_pt(li, -hw - 2.0), _pt(li, -hw), _pt(li + 1, -hw), _pt(li + 1, -hw - 2.0), shoulder)
	rd.quad(_pt(li, hw), _pt(li, hw + 2.0), _pt(li + 1, hw + 2.0), _pt(li + 1, hw), shoulder)
	var wh = Color(0.92, 0.92, 0.9)
	var ye = Color(0.95, 0.75, 0.1)
	var yy = 0.05
	_strip(rd, li, -hw + 0.12, -hw + 0.3, yy, wh)
	_strip(rd, li, hw - 0.3, hw - 0.12, yy, wh)
	if two_way:
		_strip(rd, li, -0.24, -0.1, yy, ye)
		_strip(rd, li, 0.1, 0.24, yy, ye)
		if i % 3 == 0:
			_strip(rd, li, 3.5, 3.7, yy, wh)
			_strip(rd, li, -3.7, -3.5, yy, wh)
	elif i % 3 == 0:
		_strip(rd, li, 1.7, 1.9, yy, wh)
		_strip(rd, li, -1.9, -1.7, yy, wh)
	# terrain
	for side in [-1, 1]:
		var prev: Vector3 = _col_pos(li, side, 0)
		var prev2: Vector3 = _col_pos(li + 1, side, 0)
		for k in range(1, offs.size()):
			var a = _col_pos(li, side, k)
			var b = _col_pos(li + 1, side, k)
			var yrel = a.y - P[li].y
			so.quad(prev, a, b, prev2, _tcol(k, a, yrel, side))
			prev = a
			prev2 = b
		# shoulder to first column (flat verge)
		var e0 = _col_pos(li, side, 0)
		var e1 = _col_pos(li + 1, side, 0)
		var s0 = _pt(li, float(side) * (hw + 2.0))
		var s1 = _pt(li + 1, float(side) * (hw + 2.0))
		if tn:
			so.quad(s0, e0, e1, s1, Color(0.4, 0.4, 0.42))
	if tn:
		_tunnel(w, li, i)
	else:
		_scenery(w, li, i, rg)

func _strip(mb: MeshBuf, li: int, d0: float, d1: float, dy: float, col: Color) -> void:
	mb.quad(_pt(li, d0, dy), _pt(li, d1, dy), _pt(li + 1, d1, dy), _pt(li + 1, d0, dy), col)

func _tunnel(w: Dictionary, li: int, i: int) -> void:
	var so: MeshBuf = w["solid"]
	var gl: MeshBuf = w["glow"]
	var tw = half_w + 2.0
	var conc = Color(0.46, 0.46, 0.48)
	var top = 6.0
	so.quad(_pt(li, -tw), _pt(li + 1, -tw), _pt(li + 1, -tw, top), _pt(li, -tw, top), conc)
	so.quad(_pt(li, tw), _pt(li + 1, tw), _pt(li + 1, tw, top), _pt(li, tw, top), conc)
	so.quad(_pt(li, -tw, top), _pt(li, tw, top), _pt(li + 1, tw, top), _pt(li + 1, -tw, top), Color(0.36, 0.36, 0.38))
	if i % 2 == 0:
		for sx in [-0.5, 0.5]:
			var d0 = sx * half_w
			gl.quad(_pt(li, d0 - 0.3, top - 0.05), _pt(li, d0 + 0.3, top - 0.05), _pt(li + 1, d0 + 0.3, top - 0.05), _pt(li + 1, d0 - 0.3, top - 0.05), Color(1.0, 0.95, 0.8))
	var prev_tn = (li > 0 and TN[li - 1] == 1)
	var next_tn = (li + 2 < P.size() and TN[li + 2] == 1)
	if not prev_tn or not next_tn:
		var zc = P[li]
		var yaw = H[li]
		var zo = 0.0 if not prev_tn else STEP
		so.box(_pt(li, 0.0, top + 0.8) + (Vector3(-sin(yaw), 0, -cos(yaw)) * zo), Vector3(tw * 2.0 + 2.0, 1.6, 1.4), Color(0.5, 0.5, 0.52), yaw)

func _scenery(w: Dictionary, li: int, i: int, rg: RandomNumberGenerator) -> void:
	var so: MeshBuf = w["solid"]
	var gl: MeshBuf = w["glow"]
	var ad: MeshBuf = w["add"]
	var hw = half_w
	var yaw = H[li]
	var fwd = Vector3(-sin(yaw), 0, -cos(yaw))
	var rgt = RT[li]
	var dens = fx
	var kk = K[li]
	# guard rails
	if scenery == "mountain" or scenery == "coastal":
		for side in [-1.0, 1.0]:
			var mid = (P[li] + P[li + 1]) * 0.5 + rgt * (side * (hw + 2.6))
			so.box(mid + Vector3(0, 0.62, 0), Vector3(0.1, 0.32, STEP), Color(0.72, 0.74, 0.76), yaw)
			so.box(mid + Vector3(0, 0.3, 0), Vector3(0.1, 0.6, 0.1), Color(0.5, 0.5, 0.52), yaw)
	# street lamps
	if bool(map["lamps"]) and i % 8 == 0:
		var sides = [-1.0, 1.0] if scenery == "city" else [1.0]
		for side in sides:
			var base = P[li] + rgt * (side * (hw + 1.8))
			so.box(base + Vector3(0, 4.0, 0), Vector3(0.18, 8.0, 0.18), Color(0.3, 0.3, 0.32), yaw)
			so.box(base - rgt * (side * 1.1) + Vector3(0, 8.0, 0), Vector3(2.4, 0.12, 0.12), Color(0.3, 0.3, 0.32), yaw)
			var head = base - rgt * (side * 2.1) + Vector3(0, 7.9, 0)
			gl.box(head, Vector3(0.9, 0.16, 0.45), Color(1.0, 0.9, 0.7), yaw)
			var pc = base - rgt * (side * 3.0)
			ad.quad(pc + Vector3(-5, 0.08, -5), pc + Vector3(5, 0.08, -5), pc + Vector3(5, 0.08, 5), pc + Vector3(-5, 0.08, 5), Color(1.0, 0.85, 0.55, 0.38))
			var hc = head + Vector3(0, -0.1, 0)
			ad.quad(hc + Vector3(-0.9, 0, 0), hc + Vector3(0, 0, -0.9), hc + Vector3(0.9, 0, 0), hc + Vector3(0, 0, 0.9), Color(1, 0.9, 0.6, 0.5))
	# gantry sign
	if i % 160 == 80:
		var gh = 6.4
		var pw = hw + 2.2
		for side in [-1.0, 1.0]:
			so.box(P[li] + rgt * (side * pw) + Vector3(0, gh * 0.5, 0), Vector3(0.3, gh, 0.3), Color(0.5, 0.5, 0.52), yaw)
		so.box(P[li] + Vector3(0, gh, 0), Vector3(pw * 2.0, 0.5, 0.4), Color(0.5, 0.5, 0.52), yaw)
		var bk = -fwd * 0.3
		var c0 = P[li] + bk + Vector3(0, gh - 3.6, 0)
		var pcol = Color(0.05, 0.4, 0.2)
		so.quad(c0 - rgt * 3.5, c0 + rgt * 3.5, c0 + rgt * 3.5 + Vector3(0, 2.8, 0), c0 - rgt * 3.5 + Vector3(0, 2.8, 0), pcol)
		var b2 = bk * 1.3
		gl.quad(P[li] + b2 + Vector3(0, gh - 2.4, 0) - rgt * 2.6, P[li] + b2 + Vector3(0, gh - 2.4, 0) + rgt * 2.6, P[li] + b2 + Vector3(0, gh - 2.1, 0) + rgt * 2.6, P[li] + b2 + Vector3(0, gh - 2.1, 0) - rgt * 2.6, Color(0.9, 0.9, 0.9))
		gl.quad(P[li] + b2 + Vector3(0, gh - 1.6, 0) - rgt * 1.6, P[li] + b2 + Vector3(0, gh - 1.6, 0) + rgt * 1.6, P[li] + b2 + Vector3(0, gh - 1.3, 0) + rgt * 1.6, P[li] + b2 + Vector3(0, gh - 1.3, 0) - rgt * 1.6, Color(0.9, 0.9, 0.9))
	match scenery:
		"city":
			_city(w, li, i, rg, fwd, rgt, yaw)
		"country":
			for side in [-1, 1]:
				if rg.randf() < 0.45 * dens:
					_tree(so, _ground(li, side, hw + rg.randf_range(8.0, 70.0)), rg)
				so.box(P[li] + rgt * (float(side) * (hw + 6.5)) + fwd * 2.0 + Vector3(0, 0.8, 0), Vector3(0.08, 0.08, STEP), Color(0.45, 0.35, 0.25), yaw)
				so.box(P[li] + rgt * (float(side) * (hw + 6.5)) + Vector3(0, 0.5, 0), Vector3(0.12, 1.0, 0.12), Color(0.4, 0.3, 0.2), yaw)
			if i % 70 == 12 and rg.randf() < 0.6 * dens + 0.2:
				var sd = 1.0 if rg.randf() < 0.5 else -1.0
				var bp = _ground(li, int(sd), hw + 40.0)
				so.box(bp + Vector3(0, 3.0, 0), Vector3(10, 6, 14), Color(0.62, 0.15, 0.12), yaw)
				so.box(bp + Vector3(0, 6.6, 0), Vector3(10.4, 1.2, 14.4), Color(0.3, 0.1, 0.1), yaw)
				so.prism_y(bp + rgt * 8.0 * sd, 1.6, 1.6, 9.0, 8, Color(0.75, 0.75, 0.78), true)
		"mountain":
			for side in [-1, 1]:
				if rg.randf() < 0.55 * dens:
					_pine(so, _ground(li, side, hw + rg.randf_range(6.0, 60.0)), rg)
				if rg.randf() < 0.12 * dens:
					_rock(so, _ground(li, side, hw + rg.randf_range(4.0, 30.0)), rg)
		"desert":
			for side in [-1, 1]:
				if rg.randf() < 0.1 * dens:
					_cactus(so, _ground(li, side, hw + rg.randf_range(6.0, 80.0)), rg)
				if rg.randf() < 0.1 * dens:
					_rock(so, _ground(li, side, hw + rg.randf_range(5.0, 90.0)), rg)
			if i % 10 == 3:
				var pp = P[li] + rgt * (hw + 6.0)
				so.box(pp + Vector3(0, 4.0, 0), Vector3(0.22, 8.0, 0.22), Color(0.35, 0.25, 0.18), yaw)
				so.box(pp + Vector3(0, 7.6, 0), Vector3(2.4, 0.14, 0.14), Color(0.35, 0.25, 0.18), yaw)
			if i % 90 == 45 and rg.randf() < 0.7:
				var sd2 = 1 if rg.randf() < 0.5 else -1
				var mp = _ground(li, sd2, hw + rg.randf_range(150.0, 260.0))
				so.box(mp + Vector3(0, 18.0, 0), Vector3(rg.randf_range(40, 80), 40.0, rg.randf_range(30, 60)), C_rock.darkened(rg.randf_range(0.0, 0.25)), rg.randf() * PI)
		"coastal":
			for side in [1]:
				if rg.randf() < 0.18 * dens:
					_palm(so, _ground(li, side, hw + rg.randf_range(8.0, 50.0)), rg)
			if rg.randf() < 0.04 * dens:
				var hp = _ground(li, 1, hw + rg.randf_range(15.0, 40.0))
				so.box(hp + Vector3(0, 2.5, 0), Vector3(9, 5, 8), Color(0.92, 0.92, 0.9), yaw)
				so.box(hp + Vector3(0, 5.4, 0), Vector3(9.6, 0.8, 8.6), Color(0.7, 0.28, 0.2), yaw)
			if rg.randf() < 0.1:
				_rock(so, _ground(li, -1, hw + rg.randf_range(10.0, 20.0)), rg)

func _city(w: Dictionary, li: int, i: int, rg: RandomNumberGenerator, fwd: Vector3, rgt: Vector3, yaw: float) -> void:
	var so: MeshBuf = w["solid"]
	var gl: MeshBuf = w["glow"]
	var night = map["id"] == "nightcity"
	if i % 5 != 0:
		return
	for side in [-1.0, 1.0]:
		var kk = K[li]
		if kk * (-side) > 0.0 and absf(kk) > 0.003:
			continue
		if rg.randf() > 0.85 * clampf(fx, 0.5, 1.0) + 0.1:
			continue
		var off = half_w + rg.randf_range(14.0, 26.0)
		var wd = rg.randf_range(14.0, 26.0)
		var dp = rg.randf_range(16.0, 26.0)
		var ht = rg.randf_range(14.0, 120.0 if night else 80.0)
		var bp = P[li] + rgt * (side * (off + dp * 0.5))
		bp.y = P[li].y - 0.1
		var shade = rg.randf_range(0.35, 0.65)
		var bc = Color(shade, shade, shade + 0.06)
		so.box(bp + Vector3(0, ht * 0.5, 0), Vector3(dp, ht, wd), bc, yaw)
		var face = P[li] + rgt * (side * off) + Vector3(0, P[li].y * 0.0, 0)
		face.y = bp.y
		var toward = -rgt * side * 0.07
		var rows = int(ht / 3.6)
		var cols = int(wd / 3.4)
		var lit_p = 0.7 if night else 0.35
		for r in range(1, rows):
			for c in cols:
				if rg.randf() > lit_p:
					continue
				var q = face + fwd * ((float(c) + 0.5) * 3.4 - wd * 0.5) + Vector3(0, float(r) * 3.6, 0) + toward
				var wc = Color(1.0, 0.85, 0.5) if rg.randf() < 0.7 else Color(0.7, 0.85, 1.0)
				gl.quad(q - fwd * 0.7 - Vector3(0, 0.9, 0), q + fwd * 0.7 - Vector3(0, 0.9, 0), q + fwd * 0.7 + Vector3(0, 0.9, 0), q - fwd * 0.7 + Vector3(0, 0.9, 0), wc)
		if rg.randf() < (0.3 if night else 0.08):
			var nc = [Color(1.0, 0.2, 0.6), Color(0.1, 0.9, 1.0), Color(1.0, 0.8, 0.1), Color(0.5, 1.0, 0.3)][rg.randi_range(0, 3)]
			gl.box(face + toward * 8.0 + Vector3(0, ht * rg.randf_range(0.3, 0.8), 0), Vector3(0.6, 3.5, 8.0), nc, yaw)

func _tree(so: MeshBuf, p: Vector3, rg: RandomNumberGenerator) -> void:
	var h = rg.randf_range(4.0, 8.0)
	so.prism_y(p, 0.18, 0.14, h * 0.45, 5, Color(0.3, 0.2, 0.12))
	var g = Color(0.15 + rg.randf() * 0.1, 0.4 + rg.randf() * 0.2, 0.12)
	so.prism_y(p + Vector3(0, h * 0.35, 0), h * 0.32, h * 0.05, h * 0.65, 7, g)

func _pine(so: MeshBuf, p: Vector3, rg: RandomNumberGenerator) -> void:
	var h = rg.randf_range(6.0, 14.0)
	so.prism_y(p, 0.2, 0.15, h * 0.3, 5, Color(0.25, 0.17, 0.1))
	var g = Color(0.08 + rg.randf() * 0.05, 0.25 + rg.randf() * 0.1, 0.12)
	for j in 3:
		var fj = float(j)
		so.prism_y(p + Vector3(0, h * (0.2 + 0.25 * fj), 0), h * (0.28 - 0.06 * fj), h * 0.03, h * 0.35, 6, g)

func _rock(so: MeshBuf, p: Vector3, rg: RandomNumberGenerator) -> void:
	var s = rg.randf_range(1.0, 3.5)
	var c = C_rock.darkened(rg.randf_range(0.0, 0.3))
	so.box(p + Vector3(0, s * 0.3, 0), Vector3(s * 1.4, s * 0.7, s), c, rg.randf() * PI)

func _cactus(so: MeshBuf, p: Vector3, rg: RandomNumberGenerator) -> void:
	var h = rg.randf_range(2.5, 4.5)
	var c = Color(0.2, 0.45, 0.2)
	so.prism_y(p, 0.22, 0.2, h, 6, c, true)
	so.box(p + Vector3(0.5, h * 0.55, 0), Vector3(0.8, 0.2, 0.2), c)
	so.prism_y(p + Vector3(0.9, h * 0.55, 0), 0.15, 0.13, h * 0.3, 5, c, true)

func _palm(so: MeshBuf, p: Vector3, rg: RandomNumberGenerator) -> void:
	var h = rg.randf_range(6.0, 9.0)
	so.prism_y(p, 0.25, 0.15, h, 5, Color(0.5, 0.38, 0.22))
	var top = p + Vector3(0, h, 0)
	var g = Color(0.15, 0.5, 0.2)
	for a in 5:
		var ang = float(a) * TAU / 5.0
		var d = Vector3(cos(ang), -0.25, sin(ang)) * 2.6
		so.tri(top, top + d + Vector3(-d.z, 0, d.x) * 0.15, top + d - Vector3(-d.z, 0, d.x) * 0.15, g)

func _build_ring() -> void:
	var mb = MeshBuf.new()
	var rr = RandomNumberGenerator.new()
	rr.seed = seed_v + 99
	var n = 44
	var col = Color.WHITE
	for j in n:
		var a = TAU * float(j) / float(n) + rr.randf() * 0.1
		var dist = rr.randf_range(1500.0, 1900.0)
		var cx = cos(a) * dist
		var cz = sin(a) * dist
		if scenery == "city":
			var hh = rr.randf_range(80.0, 280.0)
			mb.box(Vector3(cx, hh * 0.5, cz), Vector3(rr.randf_range(60, 140), hh, rr.randf_range(60, 140)), col.darkened(rr.randf_range(0.0, 0.2)), a)
		else:
			var hh2 = rr.randf_range(120.0, 360.0) * (1.4 if scenery == "mountain" else 0.6)
			mb.prism_y(Vector3(cx, -10.0, cz), rr.randf_range(240.0, 420.0), 8.0, hh2, 5, col.darkened(rr.randf_range(0.0, 0.25)))
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat_ring)
	ring = MeshInstance3D.new()
	ring.mesh = m
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ring)
