extends Node3D
## Player vehicle: owns the physics model, the car node, and road-relative state.

const Phys = preload("res://scripts/game/car_physics.gd")
const CarB = preload("res://scripts/game/car_builder.gd")
const Cust = preload("res://scripts/game/customization_manager.gd")

var phys
var parts: Dictionary = {}
var road
var cfg: Dictionary = {}
var gm
var car_id := "compact"
var s := 0.0
var d := 0.0
var road_y := 0.0
var damage := 0.0
var offroad := false
var length := 4.0
var width := 1.8
var steer_vis := 0.0
var wet_mu := 1.0
var rain := false
var steer_in := 0.0
var thr_in := 0.0
var brk_in := 0.0
var top_speed_run := 0.0
var hit_cd := 0.0

func setup(c: Dictionary, r, g) -> void:
	cfg = c
	road = r
	gm = g
	car_id = Save.data["current_car"]
	var stats = Cust.effective(car_id)
	length = stats["L"]
	width = stats["W"]
	parts = CarB.build_player(car_id)
	add_child(parts["root"])
	phys = Phys.new()
	var lane_d = road.lane_d(1, road.lane_count(1) - 1)
	s = 24.0
	d = lane_d
	var p3 = road.to_world(s, d)
	phys.setup(stats, Vector2(p3.x, p3.z), road.heading_at(s))
	var shadows = Save.si("shadow") > 0
	parts["ext"].cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	apply_visual_damage()
	update_visuals(0.0)

func speed() -> float:
	return phys.vel.length()

func fwd_speed() -> float:
	return phys.u

func step(dt: float, inp: Dictionary) -> void:
	steer_in = inp["steer"]
	thr_in = inp["throttle"]
	brk_in = inp["brake"]
	hit_cd = maxf(0.0, hit_cd - dt)
	var mu = 1.0
	if rain:
		mu = 0.82 * float(phys.st["wet"])
	phys.step(dt, steer_in, thr_in, brk_in, mu, offroad)
	var sd = road.project(phys.pos, s)
	s = sd.x
	d = sd.y
	road_y = road.y_at(s)
	var paved = road.half_w + 2.0
	offroad = absf(d) > paved + 0.3
	var barrier = paved + 9.0
	if absf(d) > barrier:
		var h = road.heading_at(s)
		var rv = Vector2(cos(h), -sin(h))
		var out_dir = rv * signf(d)
		var vout = phys.vel.dot(out_dir)
		phys.pos -= out_dir * (absf(d) - barrier)
		if vout > 0.0:
			phys.vel -= out_dir * vout * 1.3
			phys.vel *= 0.85
			gm.on_player_impact(vout, null)
	top_speed_run = maxf(top_speed_run, phys.vel.length())

func apply_visual_damage() -> void:
	var ext: MeshInstance3D = parts["ext"]
	var f = 1.0 - 0.5 * clampf(damage / 100.0, 0.0, 1.0)
	var src = ext.mesh.surface_get_material(0)
	if src == null:
		return
	var m = src.duplicate()
	m.albedo_color = Color(f, f, f)
	ext.set_surface_override_material(0, m)
	parts["pivot"].position = Vector3(0, 0.5, 0)

func update_visuals(dt: float) -> void:
	var y = road_y + phys.bounce
	var grade = atan(road.grade_at(s))
	global_position = Vector3(phys.pos.x, y, phys.pos.y)
	var rel = wrapf(phys.yaw - road.heading_at(s), -PI, PI)
	rotation = Vector3(grade * cos(rel), phys.yaw, 0.0)
	var piv: Node3D = parts["pivot"]
	piv.rotation = Vector3(phys.pitch, 0.0, phys.roll)
	var spd = absf(phys.u)
	var ang = steer_in * lerpf(0.5, 0.06, clampf(spd / 35.0, 0.0, 1.0))
	steer_vis = lerpf(steer_vis, ang, 1.0 - exp(-dt * 12.0)) if dt > 0.0 else ang
	for f in parts["fronts"]:
		f.rotation.y = -steer_vis
	var r = float(parts["wheel_r"])
	for w in parts["spins"]:
		w.rotation.x = -fmod(phys.wheel_rot / r, TAU)
	parts["steer_wheel"].rotation.z = -steer_in * 2.0
	var kmh = GameData.speed_val(phys.vel.length())
	parts["speed_label"].text = str(int(kmh))
	parts["gear_label"].text = "R" if phys.u < -0.5 else str(phys.gear)

func set_lights(dark: float) -> void:
	var braking = brk_in > 0.05
	var tail = CarB.mat("tail_brake") if braking else CarB.mat("tail_run")
	parts["rear_mi"].material_override = tail
	var e = clampf(dark * 3.0, 0.0, 3.0)
	for sp in parts["spots"]:
		sp.light_energy = e

func set_view_mode(fp: bool) -> void:
	pass
