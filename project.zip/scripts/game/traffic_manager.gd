extends Node3D
## Traffic: pooling, spawning, kinematics, collisions with the player, near misses, overtakes.

const CarB = preload("res://scripts/game/car_builder.gd")
const Spawner = preload("res://scripts/game/vehicle_spawner.gd")
const AI = preload("res://scripts/game/traffic_ai.gd")

var gm
var road
var player
var cfg: Dictionary = {}
var map: Dictionary = {}
var diff := 1
var two_way := false
var rng := RandomNumberGenerator.new()
var vehicles: Array = []
var pool := {}
var pinfo := {"s": 0.0, "d": 0.0, "w": 1.8, "l": 4.0, "vs": 0.0, "brake": 0.0}
var spawn_t := 0.0
var target_total := 12.0
var render_dist := 600.0
var dark := 0.0
var ai_cursor := 0
var shadows := false

func setup(g, r, p, c: Dictionary) -> void:
	gm = g
	road = r
	player = p
	cfg = c
	map = c["map"]
	diff = c["diff"]
	two_way = c["two_way"]
	rng.seed = int(c["seed"]) + 4242
	render_dist = c["q"]["render"]
	shadows = c["q"]["shadow"] >= 1
	var dens = float(c["density"]) * float(c["q"]["traffic_scale"])
	var df = [0.7, 1.0, 1.2, 1.35][diff]
	var mf = 0.6 if c["mode"] == 2 else 1.0
	target_total = clampf(22.0 * float(map["dens"]) * dens * df * mf, 3.0, 40.0)
	_update_pinfo()
	initial_fill()

func _update_pinfo() -> void:
	var h = road.heading_at(player.s)
	var hv = Vector2(-sin(h), -cos(h))
	pinfo["s"] = player.s
	pinfo["d"] = player.d
	pinfo["w"] = player.width
	pinfo["l"] = player.length
	pinfo["vs"] = player.phys.vel.dot(hv)
	pinfo["brake"] = player.brk_in

func _target(dir: int) -> int:
	if not two_way:
		return int(round(target_total)) if dir > 0 else 0
	return int(round(target_total * (0.6 if dir > 0 else 0.4)))

func _count(dir: int) -> int:
	var n = 0
	for v in vehicles:
		if v.dir == dir:
			n += 1
	return n

func _get_vehicle(spec: Dictionary, col: String) -> Node3D:
	var key = String(spec["id"]) + col
	if pool.has(key) and pool[key].size() > 0:
		return pool[key].pop_back()
	var v = CarB.build_traffic(spec, col)
	v.set_meta("key", key)
	v.body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(v)
	return v

func _release(v) -> void:
	vehicles.erase(v)
	v.active = false
	v.visible = false
	var key = v.get_meta("key")
	if not pool.has(key):
		pool[key] = []
	pool[key].append(v)

func try_spawn(dir: int, s_lo: float, s_hi: float) -> bool:
	var spec = Spawner.pick_spec(rng)
	var lanes = road.lane_count(dir)
	if lanes == 0:
		return false
	var lane = rng.randi_range(0, lanes - 1)
	if lanes > 1 and rng.randf() < 0.35:
		lane = lanes - 1
	var s = rng.randf_range(s_lo, s_hi)
	var ld = road.lane_d(dir, lane)
	var lead_speed = 99.0
	for o in vehicles:
		if o.dir != dir:
			continue
		var ds = (o.s - s) * float(dir)
		if absf(o.d - ld) < 2.8:
			if absf(ds) < 55.0:
				return false
			if ds > 0.0 and ds < 120.0:
				lead_speed = minf(lead_speed, o.speed)
	if dir > 0 and absf(player.s - s) < 100.0:
		return false
	var col = Spawner.pick_color(rng, spec)
	var v = _get_vehicle(spec, col)
	Spawner.init_vehicle(v, spec, dir, lane, s, self)
	if lead_speed < 90.0:
		v.speed = minf(v.speed, lead_speed)
	vehicles.append(v)
	_place(v)
	return true

func initial_fill() -> void:
	var tries = 0
	while tries < 300:
		tries += 1
		var need = false
		for dir in [1, -1]:
			if _count(dir) < _target(dir):
				need = true
				try_spawn(dir, player.s + 140.0, player.s + render_dist * 0.95)
		if not need:
			break

func lane_free(v, idx: int, scale: float) -> bool:
	var nd = road.lane_d(v.dir, idx)
	for c in vehicles:
		if c == v or c.dir != v.dir:
			continue
		if absf(c.d - nd) > 2.7 and absf(c.lc_to - nd) > 1.0:
			continue
		var ds = (c.s - v.s) * float(v.dir)
		var lens = (v.length + c.length) * 0.5
		if ds >= 0.0:
			var need = maxf(7.0, (v.speed - c.speed) * 1.5 + 6.0)
			if ds - lens < need * scale:
				return false
		else:
			var need2 = maxf(7.0, (c.speed - v.speed) * 1.8 + 8.0)
			if -ds - lens < need2 * scale:
				return false
	# player
	var dsp = (pinfo["s"] - v.s) * float(v.dir)
	if absf(pinfo["d"] - nd) < 2.9:
		var lensp = (v.length + pinfo["l"]) * 0.5
		var pv = pinfo["vs"] * float(v.dir)
		if dsp >= 0.0:
			var need3 = maxf(8.0, (v.speed - pv) * 1.6 + 7.0)
			if dsp - lensp < need3 * scale:
				return false
		else:
			var need4 = maxf(10.0, (pv - v.speed) * 2.2 + 10.0)
			if -dsp - lensp < need4 * scale:
				return false
	return true

func _player_threat(v) -> bool:
	var dsp = (v.s - pinfo["s"]) * float(v.dir)
	if dsp < -2.0 or dsp > 30.0:
		return false
	if absf(pinfo["d"] - v.lc_to) > 2.8:
		return false
	var closing = pinfo["vs"] * float(v.dir) - v.speed
	return closing > 1.0 and dsp / closing < 1.2

func honk(v) -> void:
	var dist = absf(v.s - player.s)
	if dist < 60.0:
		Sfx.play("horn", -8.0 - dist * 0.1, rng.randf_range(0.9, 1.15))

# ------------------------------------------------------------------ per frame
func frame(dt: float) -> void:
	_update_pinfo()
	# AI scheduling
	for v in vehicles:
		if v.state != "drive":
			v.acc_cmd = -4.0
			continue
		v.ai_t += dt
		if v.ai_t >= 0.1:
			AI.think(v, self, v.ai_t)
			v.ai_t = 0.0
	# spawn / despawn
	spawn_t += dt
	if spawn_t > 0.25:
		spawn_t = 0.0
		for dir in [1, -1]:
			if _count(dir) < _target(dir):
				try_spawn(dir, player.s + maxf(260.0, render_dist * 0.8), player.s + render_dist * 0.98)
	for v in vehicles.duplicate():
		var behind = -200.0 if v.dir > 0 else -150.0
		if v.s < player.s + behind or v.s > player.s + render_dist + 300.0:
			_release(v)
	for v in vehicles:
		_place(v)
		v.set_lights(dark, CarB.mat("tail_run"), CarB.mat("tail_brake"))
		v.blink += dt

func _place(v) -> void:
	var h = road.heading_at(v.s)
	var p = road.to_world(v.s, v.d)
	var lat = clampf(v.vd / maxf(v.speed, 4.0), -0.4, 0.4)
	var yaw = h - lat + v.yaw_off
	var gr = atan(road.grade_at(v.s))
	var pitch = gr
	if v.dir < 0:
		yaw = h + PI + lat + v.yaw_off
		pitch = -gr
	v.position = p
	v.rotation = Vector3(pitch, yaw, 0.12 * clampf(v.yaw_off, -1.0, 1.0) if v.state == "wreck" else 0.0)

# ------------------------------------------------------------------ kinematics + collisions
func step(dt: float) -> void:
	_update_pinfo()
	for v in vehicles:
		_kin(v, dt)
	_collide(dt)
	_events()

func _kin(v, dt: float) -> void:
	if v.state == "wreck":
		v.speed = maxf(0.0, v.speed - 5.0 * dt)
		v.s += float(v.dir) * v.speed * dt
		v.d = clampf(v.d + v.vd * dt, -road.half_w - 6.0, road.half_w + 6.0)
		v.vd *= exp(-dt * 1.3)
		v.yaw_off += v.yaw_rate * dt
		v.yaw_rate *= exp(-dt * 1.5)
		v.braking = true
		return
	v.age += dt
	v.speed = maxf(0.0, v.speed + v.acc_cmd * dt)
	v.braking = v.acc_cmd < -1.0
	if v.lc_state == 1:
		v.lc_wait -= dt
		if v.lc_wait <= 0.0:
			var sc = 1.0
			if diff >= 2:
				sc = 0.85
			if lane_free(v, v.target_lane, sc):
				v.lc_state = 2
				v.lc_t = 0.0
				v.lc_from = v.d
				v.lc_to = road.lane_d(v.dir, v.target_lane)
				v.set_meta("aborted", false)
			else:
				v.lc_state = 0
				v.sigdir = 0
				v.signal_on = false
				v.lc_cd = 3.0
	elif v.lc_state == 2:
		v.lc_t += dt
		var u = clampf(v.lc_t / v.lc_dur, 0.0, 1.0)
		var nd = lerpf(v.lc_from, v.lc_to, smoothstep(0.0, 1.0, u))
		v.vd = (nd - v.d) / maxf(dt, 0.0001)
		v.d = nd
		if u < 0.5 and not bool(v.get_meta("aborted", false)) and _player_threat(v):
			var p_ab = [1.0, 0.9, 0.6, 0.4][diff]
			v.set_meta("aborted", true)
			if rng.randf() < p_ab:
				v.lc_to = v.lc_from
				v.lc_from = v.d
				v.lc_t = 0.0
				v.lc_dur = 1.2
				v.target_lane = v.lane
				v.set_meta("aborted", true)
		if u >= 0.5:
			v.lane = v.target_lane
		if u >= 1.0:
			v.lc_state = 0
			v.sigdir = 0
			v.signal_on = false
			v.vd = 0.0
	else:
		v.vd = 0.0
	v.s += float(v.dir) * v.speed * dt

func _obb(c1: Vector2, y1: float, hl1: float, hw1: float, c2: Vector2, y2: float, hl2: float, hw2: float):
	var f1 = Vector2(-sin(y1), -cos(y1))
	var r1 = Vector2(cos(y1), -sin(y1))
	var f2 = Vector2(-sin(y2), -cos(y2))
	var r2 = Vector2(cos(y2), -sin(y2))
	var delta = c1 - c2
	var best = Vector2.ZERO
	var min_d = 1e9
	for ax in [f1, r1, f2, r2]:
		var p1 = hl1 * absf(ax.dot(f1)) + hw1 * absf(ax.dot(r1))
		var p2 = hl2 * absf(ax.dot(f2)) + hw2 * absf(ax.dot(r2))
		var ov = p1 + p2 - absf(delta.dot(ax))
		if ov <= 0.0:
			return null
		if ov < min_d:
			min_d = ov
			best = ax if delta.dot(ax) >= 0.0 else -ax
	return [min_d, best]

func _collide(dt: float) -> void:
	var ph = player.phys
	for v in vehicles:
		if absf(v.s - player.s) > 14.0 or absf(v.d - player.d) > 8.0:
			continue
		var h = road.heading_at(v.s)
		var p3 = road.to_world(v.s, v.d)
		var vp = Vector2(p3.x, p3.z)
		var lat = clampf(v.vd / maxf(v.speed, 4.0), -0.4, 0.4)
		var yaw = h - lat + v.yaw_off
		if v.dir < 0:
			yaw = h + PI + lat + v.yaw_off
		var res = _obb(ph.pos, ph.yaw, player.length * 0.46, player.width * 0.46, vp, yaw, v.length * 0.46, v.width * 0.46)
		if res == null:
			continue
		var depth: float = res[0]
		var n: Vector2 = res[1]
		var fwd = Vector2(-sin(h), -cos(h))
		var rv = Vector2(cos(h), -sin(h))
		var vt = fwd * (float(v.dir) * v.speed) + rv * v.vd
		var vn = (ph.vel - vt).dot(n)
		ph.pos += n * depth * 0.55
		var sep = -n * depth * 0.45
		v.s += sep.dot(fwd)
		v.d += sep.dot(rv)
		if vn < 0.0:
			var mp = float(ph.st["weight"])
			var mt = v.weight
			var j = -(1.2) * vn / (1.0 / mp + 1.0 / mt)
			ph.apply_impulse(n * j, (vp - ph.pos) * 0.5)
			var dvt = -n * (j / mt)
			var sv = float(v.dir) * v.speed + dvt.dot(fwd)
			v.speed = maxf(sv * float(v.dir), 0.0)
			v.vd += dvt.dot(rv)
			var impact = -vn
			v.hit = true
			if impact > 1.5:
				v.state = "wreck"
				v.lc_state = 0
				v.sigdir = 0
				v.yaw_rate = rng.randf_range(-1.0, 1.0) * clampf(impact * 0.08, 0.05, 1.5)
			gm.on_player_impact(impact, v)

func _events() -> void:
	var ps = pinfo["s"]
	var pd = pinfo["d"]
	var pvs = pinfo["vs"]
	for v in vehicles:
		var rel = v.s - ps
		if absf(rel) > 30.0:
			continue
		var half = (v.length + pinfo["l"]) * 0.5
		var clear = absf(v.d - pd) - (v.width + pinfo["w"]) * 0.5
		var near_zone = absf(rel) < half + 1.0 and absf(v.d - pd) < 7.0
		if near_zone and not v.hit:
			if not v.adj:
				var rs0 = absf(pvs - float(v.dir) * v.speed)
				if rs0 > 14.0 and clear < 3.5:
					Sfx.play("whoosh", -6.0 + minf(rs0 * 0.1, 4.0), 0.8 + rs0 * 0.004)
			v.adj = true
			v.nm_min = minf(v.nm_min, clear)
		elif v.adj:
			v.adj = false
			var rs = absf(pvs - float(v.dir) * v.speed)
			var thr = 1.2 if v.dir > 0 else 1.6
			if not v.hit and v.nm_min < thr and rs > 8.0:
				gm.econ.near_miss(maxf(v.nm_min, 0.0), rs)
			v.nm_min = 99.0
		if v.dir > 0 and not v.passed and v.state == "drive":
			if rel > 6.0:
				v.was_ahead = true
			if v.was_ahead and rel < -(half) - 1.0 and absf(v.d - pd) < 7.5 and pvs > v.speed:
				v.passed = true
				gm.econ.overtake(player.speed())
