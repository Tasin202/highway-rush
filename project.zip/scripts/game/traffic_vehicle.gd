extends Node3D
## One pooled traffic vehicle: visual parts + AI/kinematic state.

var spec: Dictionary = {}
var body: MeshInstance3D
var rear: MeshInstance3D
var head: MeshInstance3D
var sig_l: MeshInstance3D
var sig_r: MeshInstance3D
var beam: MeshInstance3D

var active := false
var state := "drive" # drive / wreck
var dir := 1
var s := 0.0
var d := 0.0
var vd := 0.0
var speed := 20.0
var desired := 25.0
var accel_max := 2.5
var brake_max := 7.5
var comfy := 2.5
var length := 4.5
var width := 1.8
var weight := 1400.0
var personality := "normal"
var headway := 1.5
var min_gap := 2.5
var reaction := 0.7
var aggression := 0.5
var lane := 0
var target_lane := 0
var lc_state := 0
var lc_wait := 0.0
var lc_t := 0.0
var lc_dur := 3.0
var lc_from := 0.0
var lc_to := 0.0
var lc_cd := 2.0
var sigdir := 0
var signal_on := false
var blink := 0.0
var acc_cmd := 0.0
var prev_acc := 0.0
var react_left := 0.0
var reacting := false
var ai_t := 0.0
var event_left := 0.0
var event_decel := 0.0
var event_cd := 10.0
var honk_cd := 5.0
var yaw_off := 0.0
var yaw_rate := 0.0
var passed := false
var was_ahead := false
var adj := false
var nm_min := 99.0
var hit := false
var age := 0.0
var shoulder := 0.0
var braking := false

func set_lights(dark: float, mat_run: Material, mat_brake: Material) -> void:
	rear.material_override = mat_brake if (braking or acc_cmd < -1.2) else mat_run
	head.visible = dark > 0.25
	beam.visible = dark > 0.3 and state == "drive"
	var on = signal_on and sigdir != 0 and fmod(blink, 0.8) < 0.4
	sig_l.visible = on and sigdir < 0
	sig_r.visible = on and sigdir > 0
