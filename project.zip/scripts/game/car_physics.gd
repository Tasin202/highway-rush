extends RefCounted
## Player car dynamics in world XZ space. Vector2: x = world X, y = world Z.
## Heading vector = (-sin yaw, -cos yaw). Positive yaw = counter-clockwise (left).

const GEAR_F := [0.22, 0.38, 0.54, 0.70, 0.85, 1.0]

var pos := Vector2.ZERO
var vel := Vector2.ZERO
var yaw := 0.0
var st: Dictionary = {}
var r_state := 0.0
var yaw_extra := 0.0
var thr := 0.0
var brk := 0.0
var gear := 1
var rpm := 900.0
var shift_t := 0.0
var ax := 0.0
var ay := 0.0
var slip := 0.0
var roll := 0.0
var roll_v := 0.0
var pitch := 0.0
var pitch_v := 0.0
var bounce := 0.0
var wheel_rot := 0.0
var u := 0.0
var clock := 0.0

func setup(stats: Dictionary, p: Vector2, y: float) -> void:
	st = stats
	pos = p
	yaw = y
	rpm = float(st["idle"])

func heading() -> Vector2:
	return Vector2(-sin(yaw), -cos(yaw))

func right() -> Vector2:
	return Vector2(cos(yaw), -sin(yaw))

func step(dt: float, steer: float, thr_in: float, brk_in: float, mu: float, offroad: bool) -> void:
	clock += dt
	var hv = heading()
	var rv = right()
	u = vel.dot(hv)
	var speed = absf(u)
	var vtot = vel.length()
	var sgn = 1.0 if u >= 0.0 else -1.0
	thr = move_toward(thr, thr_in, dt * 3.0)
	brk = move_toward(brk, brk_in, dt * 5.0)
	var mu_e = mu * (0.6 if offroad else 1.0)
	var grip = float(st["grip"]) * (1.0 + float(st["down"]) * pow(minf(vtot, 90.0) / 50.0, 2.0))
	var amax = mu_e * 9.81 * grip
	var top = float(st["top"])
	var coef = float(st["accel"]) / (top * top) * float(st["drag_mult"])
	# ---------------- gearbox
	if shift_t > 0.0:
		shift_t -= dt
	if u > 0.0:
		var top_g = top * GEAR_F[gear - 1]
		var frac = speed / top_g
		if gear < 6 and frac > lerpf(0.65, 0.97, thr) and shift_t <= 0.0:
			gear += 1
			shift_t = float(st["shift_time"])
		elif gear > 1 and speed < 0.55 * top * GEAR_F[gear - 2]:
			gear -= 1
	var gfrac = clampf(speed / (top * GEAR_F[gear - 1]), 0.0, 1.0)
	var idle = float(st["idle"])
	var red = float(st["red"])
	var rpm_t = idle + (red - idle) * gfrac
	if speed < 3.0:
		rpm_t = idle + (red - idle) * 0.45 * thr + (red - idle) * 0.1 * gfrac
	if shift_t > 0.0:
		rpm_t = lerpf(rpm_t, idle + (red - idle) * 0.3, 0.5)
	rpm = lerpf(rpm, rpm_t, 1.0 - exp(-dt * 10.0))
	# ---------------- longitudinal
	var a = 0.0
	var reversing = (u < 0.8 and brk > 0.9 and thr < 0.05)
	if reversing and u > -6.0:
		a = -2.6
	else:
		var t_eff = thr if shift_t <= 0.0 else 0.0
		if u < -0.5:
			a += float(st["accel"]) * thr
		else:
			a += float(st["accel"]) * t_eff
		a = minf(a, amax * 0.92)
		a -= sgn * (coef * speed * speed + 0.18)
		if thr < 0.05:
			a -= sgn * 0.55 * clampf(speed / 10.0, 0.0, 1.0)
		if brk > 0.02 and speed > 0.3:
			a -= sgn * minf(brk * float(st["brake"]) * mu_e, amax)
		if offroad:
			a -= sgn * (1.2 + 0.02 * speed * speed)
	a = clampf(a, -amax * 1.05, amax)
	if speed < 0.5 and brk > 0.02 and not reversing and thr < 0.05:
		vel *= maxf(0.0, 1.0 - dt * 8.0)
		a = 0.0
	# ---------------- steering
	var a_ref = 0.85 * 9.81 * grip
	var rmax_k = 0.61 * speed / float(st["wb"])
	var r_cmd = steer * minf(a_ref / maxf(speed, 1.0), rmax_k)
	var tau = (0.09 + float(st["weight"]) / 16000.0) / maxf(float(st["steer"]), 0.3)
	r_state += (r_cmd - r_state) * (1.0 - exp(-dt / tau))
	var a_need = absf(speed * r_state)
	var r_used = r_state
	var sat = 0.0
	if a_need > amax and a_need > 0.01:
		r_used = r_state * amax / a_need
		sat = clampf((a_need - amax) / amax, 0.0, 1.0)
	var yaw_dot = -r_used * sgn
	if vtot > 3.0 and u > 0.0:
		var yaw_v = atan2(-vel.x, -vel.y)
		var da = wrapf(yaw_v - yaw, -PI, PI)
		if absf(da) < 1.4:
			yaw_dot += 1.8 * da * clampf(vtot / 8.0, 0.0, 1.0)
	yaw_dot += yaw_extra
	yaw_extra *= exp(-dt * 1.6)
	yaw += yaw_dot * dt
	# ---------------- lateral tyre force
	hv = heading()
	rv = right()
	u = vel.dot(hv)
	var w = vel.dot(rv)
	var ay_cap = maxf(sqrt(maxf(amax * amax - a * a, 0.0)), 0.35 * amax)
	var lat = -clampf(w * 10.0, -ay_cap, ay_cap)
	if offroad:
		lat -= w * 0.8
	vel += (hv * a + rv * lat) * dt
	pos += vel * dt
	ax = a
	ay = lat
	slip = clampf(absf(w) / 3.5 + sat * 0.7 + (0.5 if (brk > 0.8 and speed > 15.0 and a < -amax * 0.9) else 0.0), 0.0, 1.0)
	# ---------------- body motion
	var rk = 0.0045
	var roll_t = -clampf(ay * rk, -0.07, 0.07)
	var pitch_t = clampf(a * 0.0035, -0.05, 0.05)
	roll_v += ((roll_t - roll) * 140.0 - roll_v * 16.0) * dt
	roll += roll_v * dt
	pitch_v += ((pitch_t - pitch) * 120.0 - pitch_v * 14.0) * dt
	pitch += pitch_v * dt
	var rough = 0.0035 if not offroad else 0.03
	bounce = rough * sin(clock * 37.0 + pos.x * 0.7) * clampf(speed / 30.0, 0.0, 1.0)
	wheel_rot += u * dt

func apply_impulse(J: Vector2, r: Vector2) -> void:
	var m = float(st["weight"])
	vel += J / m
	var inertia = m * (float(st["L"]) * float(st["L"]) + float(st["W"]) * float(st["W"])) / 12.0
	yaw_extra += clampf((r.y * J.x - r.x * J.y) / inertia, -3.0, 3.0)
