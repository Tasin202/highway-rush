extends Node3D
## Third-person chase camera and first-person cockpit camera + rear-view mirror.

var camera: Camera3D
var player
var cam_yaw := 0.0
var pos_s := Vector3.ZERO
var fp := false
var t := 0.0
var rear_vp: SubViewport
var rear_cam: Camera3D
var fov_base := 62.0

func setup(p, cfg: Dictionary) -> void:
	player = p
	camera = Camera3D.new()
	camera.near = 0.25
	camera.far = 2600.0
	camera.fov = fov_base
	add_child(camera)
	camera.make_current()
	cam_yaw = player.phys.yaw
	fp = Save.si("pov") == 1
	var qlevel = cfg["q"]["fx"]
	if qlevel >= 1:
		rear_vp = SubViewport.new()
		rear_vp.size = Vector2i(320, 96)
		rear_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
		rear_vp.msaa_3d = Viewport.MSAA_DISABLED
		add_child(rear_vp)
		rear_cam = Camera3D.new()
		rear_cam.cull_mask = 1
		rear_cam.fov = 55.0
		rear_cam.near = 0.3
		rear_cam.far = 400.0
		rear_vp.add_child(rear_cam)
		var mm = StandardMaterial3D.new()
		mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mm.albedo_texture = rear_vp.get_texture()
		mm.uv1_scale = Vector3(-1, 1, 1)
		mm.uv1_offset = Vector3(1, 0, 0)
		player.parts["mirror_quad"].material_override = mm
	set_pov(fp)

func set_pov(first_person: bool) -> void:
	fp = first_person
	Save.set_s("pov", 1 if fp else 0)
	camera.cull_mask = (1 | 2) if fp else (1 | 4)
	camera.fov = 72.0 if fp else fov_base
	if rear_vp != null:
		rear_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if fp else SubViewport.UPDATE_DISABLED
		player.parts["mirror_quad"].visible = fp

func update(dt: float) -> void:
	t += dt
	var ph = player.phys
	var spd = absf(ph.u)
	var sf = clampf(spd / 55.0, 0.0, 1.0)
	var root: Node3D = player.parts["root"]
	if fp:
		var basis_ = root.global_transform.basis
		var eye_local: Vector3 = player.parts["eye"] + Vector3(0, 0, 0)
		var eye = root.global_transform * (eye_local + Vector3(0, 0.0, 0))
		var vib = 0.0015 * sf + (0.01 if player.offroad else 0.0)
		eye += Vector3(sin(t * 53.0), sin(t * 71.0 + 1.0), 0) * vib
		camera.global_transform = Transform3D(basis_.rotated(basis_.z, 0.0), eye)
		camera.global_transform.basis = basis_ * Basis.from_euler(Vector3(ph.pitch * 0.3, 0, ph.roll * 0.5))
		camera.fov = lerpf(70.0, 82.0, sf)
		if rear_cam != null:
			var rp = root.global_transform * player.parts["rear_cam_pos"]
			rear_cam.global_transform = Transform3D(Basis(Vector3.UP, ph.yaw + PI), rp)
		return
	var sens = Save.sf("cam_sens")
	var k = 5.0 * sens
	cam_yaw = lerp_angle(cam_yaw, ph.yaw, 1.0 - exp(-dt * k))
	var dist = (5.6 + 0.9 * sf) * Save.sf("cam_dist")
	var height = 1.9 * (0.85 + 0.15 * Save.sf("cam_dist"))
	var target = Vector3(ph.pos.x, player.road_y, ph.pos.y)
	var back = Vector3(sin(cam_yaw), 0, cos(cam_yaw))
	var want = target + back * dist + Vector3(0, height, 0)
	pos_s = pos_s.lerp(want, 1.0 - exp(-dt * 14.0)) if pos_s != Vector3.ZERO else want
	var shake = Vector3(sin(t * 47.0), sin(t * 61.0), 0) * (0.004 * sf + (0.02 if player.offroad else 0.0))
	camera.global_position = pos_s + shake
	camera.look_at(target + Vector3(0, 1.1, 0) - back * 3.0 * 0.0 + Vector3(0, ph.pitch * -2.0, 0), Vector3.UP)
	camera.fov = lerpf(fov_base, fov_base + 16.0, sf * sf)
