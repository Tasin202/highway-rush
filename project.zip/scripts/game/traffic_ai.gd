extends RefCounted
## Traffic driver brain: IDM car following + lane-change logic with personalities.

const PERS := {
	"calm": {"T": 1.8, "des": 0.95, "react": 0.5, "lc": 0.3, "gap": 1.0, "sig": 1.0},
	"cautious": {"T": 2.3, "des": 0.85, "react": 0.45, "lc": 0.15, "gap": 1.3, "sig": 1.0},
	"normal": {"T": 1.5, "des": 1.0, "react": 0.7, "lc": 0.5, "gap": 1.0, "sig": 0.9},
	"aggressive": {"T": 0.9, "des": 1.12, "react": 0.5, "lc": 1.0, "gap": 0.7, "sig": 0.6},
	"distracted": {"T": 1.5, "des": 0.95, "react": 1.3, "lc": 0.4, "gap": 1.0, "sig": 0.5},
}
const REACT_DIFF := [0.5, 1.0, 1.2, 1.35]
const T_DIFF := [1.4, 1.0, 0.95, 0.9]
const EVENT_RATE := [0.0, 0.008, 0.016, 0.026]
const EVENT_DECEL := [0.0, 2.5, 4.5, 6.5]

static func apply_personality(v, diff: int) -> void:
	var p = PERS[v.personality]
	v.headway = float(p["T"]) * float(T_DIFF[diff])
	v.reaction = float(p["react"]) * float(REACT_DIFF[diff])
	v.aggression = float(p["lc"])

static func idm(v: float, v0: float, gap: float, dv: float, a: float, b: float, T: float, s0: float) -> float:
	var sstar = s0 + maxf(0.0, v * T + v * dv / (2.0 * sqrt(a * b)))
	var free = 1.0 - pow(maxf(v, 0.0) / maxf(v0, 1.0), 4.0)
	var inter = pow(sstar / maxf(gap, 0.1), 2.0) if gap < 400.0 else 0.0
	return a * (free - inter)

# main per-vehicle decision (called ~10 Hz per car)
static func think(v, mgr, dt: float) -> void:
	var diff = mgr.diff
	var p = mgr.pinfo
	var gap = 999.0
	var lead_speed = v.speed
	for c in mgr.vehicles:
		if c == v or not c.active or c.dir != v.dir:
			continue
		var ds = (c.s - v.s) * float(v.dir)
		if ds <= 0.0:
			continue
		if absf(c.d - v.d) > (v.width + c.width) * 0.5 + 0.35:
			continue
		var g = ds - (v.length + c.length) * 0.5
		if g < gap:
			gap = g
			lead_speed = c.speed
	# the player as a potential leader (same lane region)
	var dsp = (p["s"] - v.s) * float(v.dir)
	var player_lead = false
	if dsp > 0.0 and absf(p["d"] - v.d) < (v.width + p["w"]) * 0.5 + 0.35:
		var gp = dsp - (v.length + p["l"]) * 0.5
		if gp < gap:
			gap = gp
			lead_speed = p["vs"] * float(v.dir)
			player_lead = true
	var v0 = v.desired
	if v.event_left > 0.0:
		v0 = minf(v0, maxf(v.speed - 4.0, 5.0))
	var dv = v.speed - lead_speed
	if player_lead and v.dir < 0:
		dv = minf(dv, 25.0)
	var acc = idm(v.speed, v0, gap, dv, v.accel_max, v.comfy + 1.0, v.headway, v.min_gap)
	# reaction delay for hazards
	if acc < -v.comfy and not v.reacting and v.react_left <= 0.0:
		v.reacting = true
		v.react_left = v.reaction
	if v.reacting:
		v.react_left -= dt
		if v.react_left > 0.0:
			acc = v.prev_acc
		else:
			v.reacting = false
	if v.event_left > 0.0:
		v.event_left -= dt
		acc = minf(acc, -v.event_decel)
	acc = clampf(acc, -v.brake_max, v.accel_max)
	v.acc_cmd = acc
	v.prev_acc = acc
	# hard clamp: never drive through the leader
	if gap < 0.8 and gap < 900.0:
		v.speed = minf(v.speed, maxf(lead_speed, 0.0))
	# random unexpected braking
	if diff > 0 and v.event_left <= 0.0:
		var rate = float(EVENT_RATE[diff]) * (1.6 if v.personality == "distracted" or v.personality == "aggressive" else 1.0)
		if mgr.rng.randf() < rate * dt and v.speed > 12.0:
			var behind_close = false
			if (p["s"] - v.s) * float(v.dir) < 0.0 and (p["s"] - v.s) * float(v.dir) > -35.0 and absf(p["d"] - v.d) < 2.4:
				behind_close = true
			if not behind_close:
				v.event_left = mgr.rng.randf_range(1.0, 2.2)
				v.event_decel = float(EVENT_DECEL[diff]) * mgr.rng.randf_range(0.6, 1.0)
	# oncoming evasion (head-on with the player)
	if v.dir < 0 and player_lead and v.lc_state == 0 and gap < 160.0:
		var closing = v.speed + absf(p["vs"])
		var ttc = gap / maxf(closing, 1.0)
		var lim = [6.0, 4.0, 3.0, 2.3][diff]
		if ttc < lim and v.lane < mgr.road.lane_count(v.dir) - 1 and mgr.lane_free(v, v.lane + 1, 1.0):
			_start_lc(v, v.lane + 1, mgr, true)
	# lane change decisions
	_consider_lc(v, mgr, dt, gap, lead_speed)
	# horn
	v.honk_cd -= dt
	if v.honk_cd <= 0.0 and (v.personality == "aggressive" or v.personality == "distracted"):
		if p["brake"] > 0.5 and absf(p["s"] - v.s) < 25.0 and absf(p["d"] - v.d) < 4.0:
			v.honk_cd = 12.0
			mgr.honk(v)

static func _consider_lc(v, mgr, dt: float, gap: float, lead_speed: float) -> void:
	if v.lc_state != 0 or v.state != "drive":
		return
	v.lc_cd -= dt
	if v.lc_cd > 0.0:
		return
	v.lc_cd = mgr.rng.randf_range(1.5, 4.0)
	var lanes = mgr.road.lane_count(v.dir)
	if lanes < 2:
		return
	var diff = mgr.diff
	var want = 0
	var blocked = gap < maxf(25.0, v.speed * v.headway * 1.6) and lead_speed < v.desired * 0.92 - 1.0
	if blocked and mgr.rng.randf() < 0.4 + 0.6 * v.aggression:
		want = -1 if v.lane > 0 else 1
	elif v.lane < lanes - 1 and v.personality != "aggressive" and gap > 120.0 and mgr.rng.randf() < 0.25:
		want = 1
	var p = mgr.pinfo
	# easy: make way for the player
	if diff == 0 or (diff == 1 and mgr.rng.randf() < 0.3):
		var back = (p["s"] - v.s) * float(v.dir)
		if back < 0.0 and back > -80.0 and absf(p["d"] - v.d) < 2.2 and p["vs"] * float(v.dir) > v.speed + 2.0:
			want = 1 if v.lane < lanes - 1 else -1
	# impatient / random wandering
	if want == 0 and diff >= 2:
		var rate = [0.0, 0.0, 0.015, 0.03][diff] * (1.5 if v.personality == "distracted" or v.personality == "aggressive" else 0.7)
		if mgr.rng.randf() < rate * 3.0:
			want = 1 if (v.lane == 0 or (v.lane < lanes - 1 and mgr.rng.randf() < 0.5)) else -1
	if want == 0:
		return
	var nl = v.lane + want
	if nl < 0 or nl >= lanes:
		return
	var scale = 1.0
	if diff >= 2 and mgr.rng.randf() < (0.12 if diff == 2 else 0.25):
		scale = mgr.rng.randf_range(0.55, 0.85)
	if diff == 0:
		scale = 1.8
	if mgr.lane_free(v, nl, scale):
		_start_lc(v, nl, mgr, false)

static func _start_lc(v, nl: int, mgr, emergency: bool) -> void:
	var diff = mgr.diff
	var use = true
	var lead = 2.0
	match diff:
		0:
			lead = mgr.rng.randf_range(2.0, 3.0)
		1:
			use = mgr.rng.randf() < 0.92
			lead = mgr.rng.randf_range(1.2, 2.5)
		2:
			use = mgr.rng.randf() < 0.6
			lead = mgr.rng.randf_range(0.3, 2.0)
		3:
			use = mgr.rng.randf() < 0.5
			lead = mgr.rng.randf_range(0.1, 1.5)
	if emergency:
		use = false
		lead = 0.0
	v.lc_state = 1
	v.target_lane = nl
	v.sigdir = 1 if nl > v.lane else -1
	v.signal_on = use
	v.lc_wait = lead if use else 0.0
	v.lc_dur = clampf(2.9 - v.aggression * 1.2 - (0.8 if emergency else 0.0) - (0.4 if diff >= 2 else 0.0), 1.3, 4.0)
