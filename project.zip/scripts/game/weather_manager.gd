extends Node3D
## Rain particles, wet road, grip modifier.

var raining := false
var particles: CPUParticles3D
var cam: Camera3D

func setup(parent: Node, camera: Camera3D, road, player, cfg: Dictionary) -> void:
	cam = camera
	raining = cfg["weather"] == 2
	player.rain = raining
	road.set_wet(1.0 if raining else 0.0)
	parent.add_child(self)
	if raining and Save.sb("weather_fx"):
		particles = CPUParticles3D.new()
		particles.amount = 350 if cfg["q"]["fx"] >= 2 else 180
		particles.lifetime = 0.55
		particles.preprocess = 0.5
		particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		particles.emission_box_extents = Vector3(14, 0.2, 14)
		particles.direction = Vector3(0.0, -1.0, 0.0)
		particles.spread = 3.0
		particles.initial_velocity_min = 28.0
		particles.initial_velocity_max = 34.0
		particles.gravity = Vector3(0, -20, 0)
		var qm = QuadMesh.new()
		qm.size = Vector2(0.012, 0.55)
		var m = StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.albedo_color = Color(0.8, 0.85, 0.95, 0.4)
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		qm.material = m
		particles.mesh = qm
		particles.local_coords = false
		particles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(particles)

func update(dt: float) -> void:
	if particles != null and cam != null:
		particles.global_position = cam.global_position + Vector3(0, 9.0, 0)
