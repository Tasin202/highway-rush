extends RefCounted
## Fast procedural mesh accumulator (vertex-coloured, flat shaded).

var V := PackedVector3Array()
var N := PackedVector3Array()
var C := PackedColorArray()

func count() -> int:
	return V.size()

func tri(a: Vector3, b: Vector3, c: Vector3, col: Color) -> void:
	var n = (c - a).cross(b - a).normalized()
	V.append(a); V.append(b); V.append(c)
	N.append(n); N.append(n); N.append(n)
	C.append(col); C.append(col); C.append(col)

func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	tri(a, b, c, col)
	tri(a, c, d, col)

func quadv(a: Vector3, b: Vector3, c: Vector3, d: Vector3, ca: Color, cb: Color, cc: Color, cd: Color) -> void:
	var n = (c - a).cross(b - a).normalized()
	V.append(a); V.append(b); V.append(c)
	V.append(a); V.append(c); V.append(d)
	for i in 6:
		N.append(n)
	C.append(ca); C.append(cb); C.append(cc)
	C.append(ca); C.append(cc); C.append(cd)

func box_b(center: Vector3, size: Vector3, bs: Basis, col: Color) -> void:
	var xs = bs.x * (size.x * 0.5)
	var ys = bs.y * (size.y * 0.5)
	var zs = bs.z * (size.z * 0.5)
	var a = center - xs - ys - zs
	var b = center + xs - ys - zs
	var c = center + xs + ys - zs
	var d = center - xs + ys - zs
	var e = center - xs - ys + zs
	var f = center + xs - ys + zs
	var g = center + xs + ys + zs
	var h = center - xs + ys + zs
	quad(a, b, c, d, col)
	quad(e, f, g, h, col)
	quad(a, d, h, e, col)
	quad(b, c, g, f, col)
	quad(d, c, g, h, col)
	quad(a, b, f, e, col)

func box(center: Vector3, size: Vector3, col: Color, yaw: float = 0.0) -> void:
	box_b(center, size, Basis(Vector3.UP, yaw), col)

# box from point p0 to p1 with square cross-section
func beam(p0: Vector3, p1: Vector3, thick: float, col: Color) -> void:
	var dir = p1 - p0
	var l = dir.length()
	if l < 0.001:
		return
	var z = dir / l
	var up = Vector3.UP
	if absf(z.dot(up)) > 0.98:
		up = Vector3.RIGHT
	var x = up.cross(z).normalized()
	var y = z.cross(x)
	box_b((p0 + p1) * 0.5, Vector3(thick, thick, l), Basis(x, y, z), col)

# frustum: bottom/top rectangles (z ranges differ, widths differ), no bottom face
func frustum(y0: float, y1: float, zb0: float, zb1: float, zt0: float, zt1: float, hwb: float, hwt: float, col: Color, xoff: float = 0.0, with_top: bool = true) -> void:
	var b00 = Vector3(xoff - hwb, y0, zb0)
	var b10 = Vector3(xoff + hwb, y0, zb0)
	var b01 = Vector3(xoff - hwb, y0, zb1)
	var b11 = Vector3(xoff + hwb, y0, zb1)
	var t00 = Vector3(xoff - hwt, y1, zt0)
	var t10 = Vector3(xoff + hwt, y1, zt0)
	var t01 = Vector3(xoff - hwt, y1, zt1)
	var t11 = Vector3(xoff + hwt, y1, zt1)
	quad(b00, b10, t10, t00, col) # front
	quad(b01, b11, t11, t01, col) # rear
	quad(b00, b01, t01, t00, col) # left
	quad(b10, b11, t11, t10, col) # right
	if with_top:
		quad(t00, t10, t11, t01, col)

# vertical prism / cone about y axis
func prism_y(base: Vector3, r0: float, r1: float, h: float, segs: int, col: Color, cap: bool = false) -> void:
	var prev0 = base + Vector3(r0, 0, 0)
	var prev1 = base + Vector3(r1, h, 0)
	var top = base + Vector3(0, h, 0)
	for i in range(1, segs + 1):
		var a = TAU * float(i) / float(segs)
		var cs = cos(a)
		var sn = sin(a)
		var p0 = base + Vector3(r0 * cs, 0, r0 * sn)
		var p1 = base + Vector3(r1 * cs, h, r1 * sn)
		quad(prev0, p0, p1, prev1, col)
		if cap:
			tri(top, prev1, p1, col)
		prev0 = p0
		prev1 = p1

# cylinder along x axis (wheels)
func cyl_x(center: Vector3, r: float, w: float, segs: int, col: Color, caps: bool = true) -> void:
	var hx = w * 0.5
	var prev = Vector3(0, r, 0)
	for i in range(1, segs + 1):
		var a = TAU * float(i) / float(segs)
		var cur = Vector3(0, r * cos(a), r * sin(a))
		var pa = center + prev + Vector3(-hx, 0, 0)
		var pb = center + prev + Vector3(hx, 0, 0)
		var ca = center + cur + Vector3(hx, 0, 0)
		var cb = center + cur + Vector3(-hx, 0, 0)
		quad(pa, pb, ca, cb, col)
		if caps:
			tri(center + Vector3(hx, 0, 0), pb, ca, col)
			tri(center + Vector3(-hx, 0, 0), pa, cb, col)
		prev = cur

func to_mesh(mesh: ArrayMesh, mat: Material) -> void:
	if V.size() == 0:
		return
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = V
	arrays[Mesh.ARRAY_NORMAL] = N
	arrays[Mesh.ARRAY_COLOR] = C
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(mesh.get_surface_count() - 1, mat)
