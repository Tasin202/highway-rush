extends RefCounted
## Chooses vehicle types / personalities and initialises pooled vehicles.

const AI = preload("res://scripts/game/traffic_ai.gd")
const PERS_W := [
	{"calm": 0.4, "cautious": 0.3, "normal": 0.3},
	{"calm": 0.25, "cautious": 0.15, "normal": 0.45, "aggressive": 0.1, "distracted": 0.05},
	{"calm": 0.15, "cautious": 0.1, "normal": 0.4, "aggressive": 0.2, "distracted": 0.15},
	{"calm": 0.1, "cautious": 0.05, "normal": 0.35, "aggressive": 0.25, "distracted": 0.25},
]

static func pick_spec(rng: RandomNumberGenerator) -> Dictionary:
	var total = 0.0
	for t in GameData.TRAFFIC:
		total += float(t["p"])
	var r = rng.randf() * total
	for t in GameData.TRAFFIC:
		r -= float(t["p"])
		if r <= 0.0:
			return t
	return GameData.TRAFFIC[0]

static func pick_personality(rng: RandomNumberGenerator, diff: int) -> String:
	var w = PERS_W[diff]
	var r = rng.randf()
	for k in w.keys():
		r -= float(w[k])
		if r <= 0.0:
			return k
	return "normal"

static func pick_color(rng: RandomNumberGenerator, spec: Dictionary) -> String:
	if spec.has("color"):
		return spec["color"]
	return GameData.PALETTE[rng.randi_range(0, GameData.PALETTE.size() - 1)]

static func init_vehicle(v, spec: Dictionary, dir: int, lane: int, s: float, mgr) -> void:
	var rng: RandomNumberGenerator = mgr.rng
	var diff: int = mgr.diff
	v.active = true
	v.state = "drive"
	v.dir = dir
	v.lane = lane
	v.target_lane = lane
	v.lc_state = 0
	v.sigdir = 0
	v.signal_on = false
	v.s = s
	v.d = mgr.road.lane_d(dir, lane)
	v.vd = 0.0
	v.length = float(spec["L"])
	v.width = float(spec["W"])
	v.weight = float(spec["weight"])
	v.accel_max = float(spec["accel"])
	v.brake_max = float(spec["brake"])
	v.personality = pick_personality(rng, diff)
	AI.apply_personality(v, diff)
	v.comfy = 2.0 if v.personality == "cautious" else 3.0
	v.min_gap = 2.5
	var lanes = mgr.road.lane_count(dir)
	var lane_f = 1.0
	if lanes > 1:
		lane_f = lerpf(1.06, 0.94, float(lane) / float(lanes - 1))
	var base = rng.randf_range(float(spec["vmin"]), float(spec["vmax"])) / 3.6
	var pf = float(AI.PERS[v.personality]["des"])
	var ef = 0.92 if diff == 0 else 1.0
	v.desired = maxf(base * pf * lane_f * float(mgr.map["speed"]) * ef * rng.randf_range(0.93, 1.07), 11.0)
	v.speed = v.desired * rng.randf_range(0.9, 1.0)
	v.acc_cmd = 0.0
	v.prev_acc = 0.0
	v.react_left = 0.0
	v.reacting = false
	v.event_left = 0.0
	v.event_cd = rng.randf_range(5.0, 20.0)
	v.lc_cd = rng.randf_range(1.0, 6.0)
	v.honk_cd = rng.randf_range(2.0, 10.0)
	v.ai_t = rng.randf() * 0.1
	v.yaw_off = 0.0
	v.yaw_rate = 0.0
	v.passed = false
	v.was_ahead = false
	v.adj = false
	v.nm_min = 99.0
	v.hit = false
	v.braking = false
	v.blink = rng.randf() * 2.0
	v.visible = true
