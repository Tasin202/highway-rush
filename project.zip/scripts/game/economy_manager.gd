extends RefCounted
## Money: distance, sustained speed tiers, time bonus, overtakes, near misses.

const DIFF_MULT := [0.8, 1.0, 1.3, 1.7]
var gm
var earned := 0.0
var mult := 1.0
var tier := 0
var t100 := 0.0
var t120 := 0.0
var t150 := 0.0
var run_time := 0.0
var streak := 0.0
var best_streak := 0.0
var below := 0.0
var overtakes := 0
var near_misses := 0
var diff_mult := 1.0
var mode_mult := 1.0
var dens_mult := 1.0
var distance := 0.0

func setup(g, cfg: Dictionary) -> void:
	gm = g
	diff_mult = float(DIFF_MULT[cfg["diff"]])
	mode_mult = 0.5 if cfg["mode"] == 2 else 1.0
	dens_mult = 0.8 + 0.4 * float(cfg["density"])

func update(dt: float, speed_mps: float, dist_delta: float) -> void:
	run_time += dt
	var kmh = speed_mps * 3.6
	t100 = t100 + dt if kmh >= 100.0 else maxf(0.0, t100 - dt * 1.5)
	t120 = t120 + dt if kmh >= 120.0 else maxf(0.0, t120 - dt * 1.5)
	t150 = t150 + dt if kmh >= 150.0 else maxf(0.0, t150 - dt * 1.5)
	var nt = 0
	if t100 >= 4.0:
		nt = 1
	if t120 >= 6.0:
		nt = 2
	if t150 >= 8.0:
		nt = 3
	if nt != tier:
		tier = nt
		if tier > 0:
			gm.toast("SPEED BONUS x%.1f" % [[1.0, 1.3, 1.7, 2.5][tier]], Color(1.0, 0.8, 0.2))
	var target = [1.0, 1.3, 1.7, 2.5][tier]
	mult = lerpf(mult, target, 1.0 - exp(-dt * 2.0))
	if kmh >= 100.0:
		below = 0.0
		streak += dt
		best_streak = maxf(best_streak, streak)
	else:
		below += dt
		if below > 1.0:
			streak = 0.0
	if dist_delta > 0.0:
		distance += dist_delta
		var time_mult = 1.0 + minf(run_time / 600.0, 0.5)
		earned += dist_delta * 0.04 * mult * time_mult * diff_mult * mode_mult * dens_mult

func overtake(speed_mps: float) -> void:
	overtakes += 1
	var r = (20.0 + speed_mps * 3.6 * 0.3) * diff_mult * mode_mult
	earned += r
	gm.toast("OVERTAKE  +$%d" % int(r), Color(0.5, 1.0, 0.6))

func near_miss(clear: float, rel_speed: float) -> void:
	near_misses += 1
	var r = (15.0 + rel_speed * 1.0) * (1.7 - clampf(clear, 0.0, 1.5)) * diff_mult * mode_mult
	earned += r
	gm.toast("NEAR MISS  +$%d" % int(r), Color(1.0, 0.6, 0.2))
	if Save.sb("vibration"):
		Input.vibrate_handheld(25)
	Sfx.play("ding", -4.0, 1.0)

func collision_reset() -> void:
	t100 = 0.0
	t120 = 0.0
	t150 = 0.0
	streak = 0.0
	tier = 0
	mult = 1.0
