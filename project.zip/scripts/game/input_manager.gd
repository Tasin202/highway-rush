extends Node
## Steering wheel / touch / gyroscope + pedals. Touch events are tracked per finger.

var active := false
var accel_rect := Rect2()
var brake_rect := Rect2()
var wheel_center := Vector2.ZERO
var wheel_radius := 120.0
var block_rects: Array = []
var fingers := {}   # index -> role ("accel","brake","wheel","left","right","block")
var finger_pos := {}
var wheel_angle := 0.0     # radians, + = right
var wheel_last := 0.0
var accel_down := false
var brake_down := false
var steer := 0.0           # smoothed output -1..1
var raw_steer := 0.0
var touch_dir := 0.0
var gyro_smooth := 0.0
var horn_pressed := false
var _tilt_ref := 0.0

const WHEEL_MAX := 2.3

func _input(event: InputEvent) -> void:
	if not active:
		return
	if event is InputEventScreenTouch:
		var i = event.index
		if event.pressed:
			_press(i, event.position)
		else:
			_release(i)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position)

func _in_rect(r: Rect2, p: Vector2) -> bool:
	return r.has_point(p)

func _press(i: int, p: Vector2) -> void:
	finger_pos[i] = p
	for r in block_rects:
		if r.has_point(p):
			fingers[i] = "block"
			return
	if accel_rect.has_point(p):
		fingers[i] = "accel"
	elif brake_rect.has_point(p):
		fingers[i] = "brake"
	elif Save.si("steer_mode") == 0 and p.distance_to(wheel_center) < wheel_radius * 1.25:
		fingers[i] = "wheel"
		wheel_last = (p - wheel_center).angle()
	elif Save.si("steer_mode") == 1:
		fingers[i] = "left" if p.x < get_viewport().get_visible_rect().size.x * 0.5 else "right"
	else:
		fingers[i] = "none"
	_recalc()

func _release(i: int) -> void:
	fingers.erase(i)
	finger_pos.erase(i)
	_recalc()

func _drag(i: int, p: Vector2) -> void:
	finger_pos[i] = p
	if fingers.get(i, "") == "wheel":
		var a = (p - wheel_center).angle()
		wheel_angle += wrapf(a - wheel_last, -PI, PI)
		wheel_last = a
		wheel_angle = clampf(wheel_angle, -WHEEL_MAX, WHEEL_MAX)

func _recalc() -> void:
	accel_down = false
	brake_down = false
	touch_dir = 0.0
	var wheel_held = false
	for k in fingers.keys():
		match fingers[k]:
			"accel":
				accel_down = true
			"brake":
				brake_down = true
			"left":
				touch_dir -= 1.0
			"right":
				touch_dir += 1.0
			"wheel":
				wheel_held = true
	if not wheel_held and Save.si("steer_mode") == 0:
		pass
	horn_pressed = false

func is_wheel_held() -> bool:
	return fingers.values().has("wheel")

func calibrate() -> void:
	_tilt_ref = _tilt_angle()
	Save.set_s("gyro_cal", _tilt_ref)

func _tilt_angle() -> float:
	var a = Input.get_accelerometer()
	if absf(a.y) > absf(a.x) * 0.6:
		return atan2(-a.x, a.y)
	return atan2(a.y, absf(a.x)) * (-1.0 if a.x > 0.0 else 1.0)

func reset() -> void:
	fingers.clear()
	finger_pos.clear()
	wheel_angle = 0.0
	steer = 0.0
	accel_down = false
	brake_down = false
	gyro_smooth = 0.0
	_tilt_ref = Save.sf("gyro_cal")

func get_state(dt: float, speed: float) -> Dictionary:
	var mode = Save.si("steer_mode")
	var sens = Save.sf("steer_sens")
	var target = 0.0
	if mode == 0:
		if not is_wheel_held():
			wheel_angle = move_toward(wheel_angle, 0.0, dt * (3.0 + absf(wheel_angle) * 2.0))
		target = clampf(wheel_angle / WHEEL_MAX * sens * 1.15, -1.0, 1.0)
		steer = lerpf(steer, target, 1.0 - exp(-dt * 25.0))
	elif mode == 1:
		var rate = 2.6 * sens / (1.0 + speed / 28.0)
		if touch_dir != 0.0:
			steer = move_toward(steer, clampf(touch_dir, -1.0, 1.0), dt * rate)
		else:
			steer = move_toward(steer, 0.0, dt * rate * 2.2)
	else:
		var ang = wrapf(_tilt_angle() - _tilt_ref, -PI, PI)
		var dead = deg_to_rad(1.5)
		if absf(ang) < dead:
			ang = 0.0
		else:
			ang -= signf(ang) * dead
		var inv = -1.0 if Save.sb("gyro_invert") else 1.0
		target = clampf(ang / deg_to_rad(28.0 / maxf(Save.sf("gyro_sens"), 0.3)) * inv, -1.0, 1.0)
		gyro_smooth = lerpf(gyro_smooth, target, 1.0 - exp(-dt * 14.0))
		steer = gyro_smooth
	var thr = 1.0 if accel_down else 0.0
	var brk = 1.0 if brake_down else 0.0
	# keyboard (desktop testing)
	if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
		thr = 1.0
	if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
		brk = 1.0
	var kd = 0.0
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		kd -= 1.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		kd += 1.0
	if kd != 0.0:
		steer = move_toward(steer, kd, dt * 2.5 / (1.0 + speed / 28.0))
	return {"steer": steer, "throttle": thr, "brake": brk}
