extends RefCounted
## Customisation + upgrades. Static helpers operating on Save data.

static func cat(key: String) -> Dictionary:
	for c in GameData.CUSTOM:
		if c["key"] == key:
			return c
	return {}

static func get_idx(state: Dictionary, key: String) -> int:
	var c = cat(key)
	if state["c"].has(key):
		return int(state["c"][key])
	return int(c.get("def", 0))

static func is_owned(state: Dictionary, key: String, idx: int) -> bool:
	var c = cat(key)
	if int(c["prices"][idx]) == 0 or idx == int(c.get("def", 0)):
		return true
	if state["own"].has(key):
		for v in state["own"][key]:
			if int(v) == idx:
				return true
	return false

# returns "" on success or an error message
static func select(car_id: String, key: String, idx: int) -> String:
	var st = Save.car_state(car_id)
	var c = cat(key)
	if not is_owned(st, key, idx):
		var price = int(c["prices"][idx])
		if not Save.spend(price):
			return "Not enough money"
		if not st["own"].has(key):
			st["own"][key] = []
		st["own"][key].append(idx)
	st["c"][key] = idx
	Save.mark()
	return ""

static func upgrade_level(state: Dictionary, key: String) -> int:
	return int(state["up"].get(key, 0))

static func upgrade_cost(car_id: String, level: int) -> int:
	var base = GameData.car_by_id(car_id)
	return int((150.0 + 0.04 * float(base["price"])) * pow(float(level + 1), 1.5))

static func buy_upgrade(car_id: String, key: String) -> String:
	var st = Save.car_state(car_id)
	var lvl = upgrade_level(st, key)
	if lvl >= 5:
		return "Maxed"
	if not Save.spend(upgrade_cost(car_id, lvl)):
		return "Not enough money"
	st["up"][key] = lvl + 1
	Save.mark()
	return ""

static func buy_car(car_id: String) -> String:
	var base = GameData.car_by_id(car_id)
	if Save.owned(car_id):
		return ""
	if not Save.spend(int(base["price"])):
		return "Not enough money"
	Save.car_state(car_id)["owned"] = true
	Save.mark()
	Save.save_now()
	return ""

# effective physical stats for a car including upgrades + parts
static func effective(car_id: String) -> Dictionary:
	var b = GameData.car_by_id(car_id)
	var s = Save.car_state(car_id)
	var eng = float(upgrade_level(s, "engine"))
	var trn = float(upgrade_level(s, "transmission"))
	var brk = float(upgrade_level(s, "brakes"))
	var tir = float(upgrade_level(s, "tires"))
	var sus = float(upgrade_level(s, "suspension"))
	var tire_i = get_idx(s, "tire")
	var wsize = float(get_idx(s, "wheel_size"))
	var susp_i = get_idx(s, "suspension")
	var spoil = get_idx(s, "spoiler")
	var susp_grip = 1.0
	var susp_steer = 1.0
	if susp_i == 1:
		susp_grip = 1.03
		susp_steer = 1.05
	elif susp_i == 2:
		susp_grip = 0.96
		susp_steer = 0.95
	var down = [0.0, 0.01, 0.02, 0.05, 0.09][spoil]
	var r = {
		"top": float(b["top"]) / 3.6 * (1.0 + 0.025 * eng + 0.012 * trn),
		"accel": float(b["accel"]) * (1.0 + 0.05 * eng + 0.04 * trn),
		"brake": float(b["brake"]) * (1.0 + 0.05 * brk),
		"grip": float(b["grip"]) * float(GameData.TIRE_GRIP[tire_i]) * (1.0 + 0.03 * tir) * (1.0 + 0.008 * wsize) * susp_grip,
		"steer": float(b["steer"]) * (1.0 + 0.04 * sus) * susp_steer,
		"weight": float(b["weight"]) + (10.0 * float(spoil)),
		"wet": float(GameData.TIRE_WET[tire_i]),
		"down": down,
		"drag_mult": 1.0 + 0.02 * float(spoil),
		"shift_time": 0.28 - 0.025 * trn,
		"L": float(b["L"]), "W": float(b["W"]), "wb": float(b["wb"]),
		"cyl": float(b["cyl"]), "idle": float(b["idle"]), "red": float(b["red"]),
		"exhaust": get_idx(s, "exhaust"),
	}
	return r
