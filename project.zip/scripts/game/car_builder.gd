extends RefCounted
## Procedural car models (player + traffic). Local space: forward = -Z, right = +X, ground y = 0.

const MeshBuf = preload("res://scripts/game/mesh_buf.gd")
const TrafficVehicle = preload("res://scripts/game/traffic_vehicle.gd")

static var _mats := {}

const STYLES := {
	"hatch": {"hb": 0.78, "cab0": 0.33, "cab1": 0.97, "ch": 0.63, "rf": 0.65, "rr": 0.12},
	"sedan": {"hb": 0.80, "cab0": 0.34, "cab1": 0.74, "ch": 0.60, "rf": 0.65, "rr": 0.55},
	"suv": {"hb": 0.95, "cab0": 0.32, "cab1": 0.98, "ch": 0.72, "rf": 0.45, "rr": 0.10},
	"pickup": {"hb": 0.95, "cab0": 0.28, "cab1": 0.58, "ch": 0.75, "rf": 0.45, "rr": 0.08},
	"sport": {"hb": 0.72, "cab0": 0.40, "cab1": 0.78, "ch": 0.42, "rf": 0.75, "rr": 0.55},
	"van": {"hb": 1.05, "cab0": 0.18, "cab1": 1.0, "ch": 0.95, "rf": 0.35, "rr": 0.03},
	"truck": {"hb": 1.0, "cab0": 0.0, "cab1": 0.2, "ch": 1.4, "rf": 0.3, "rr": 0.0},
	"bus": {"hb": 0.9, "cab0": 0.0, "cab1": 1.0, "ch": 2.0, "rf": 0.0, "rr": 0.0},
}

static func mat(name: String) -> Material:
	if _mats.has(name):
		return _mats[name]
	var m = StandardMaterial3D.new()
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	match name:
		"body":
			m.metallic = 0.4
			m.roughness = 0.3
			m.metallic_specular = 0.6
		"glass":
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.roughness = 0.05
			m.metallic = 0.2
		"light":
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		"beam":
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
			m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
		"tail_run":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(0.45, 0.02, 0.02)
		"tail_brake":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.08, 0.05)
		"head":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.95, 0.8)
		"signal":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.6, 0.05)
		"interior":
			m.roughness = 0.8
		"wheel":
			m.roughness = 0.5
			m.metallic = 0.4
	_mats[name] = m
	return m

static func hexc(h: String) -> Color:
	return Color.html(h)

static func _wheels(mb, spec: Dictionary, wr: float, wid: float, zs: Array) -> void:
	var W = float(spec["W"])
	var tire = Color(0.04, 0.04, 0.05)
	var rim = Color(0.72, 0.74, 0.78)
	for z in zs:
		for sx in [-1.0, 1.0]:
			var cx = sx * (W * 0.5 - wid * 0.5 - 0.02)
			mb.cyl_x(Vector3(cx, wr, z), wr, wid, 12, tire, true)
			mb.cyl_x(Vector3(cx + sx * 0.004, wr, z), wr * 0.62, wid, 10, rim, true)
			mb.cyl_x(Vector3(cx + sx * 0.012, wr, z), wr * 0.22, wid, 6, Color(0.25, 0.25, 0.28), true)

static func _heavy(mb, gl, spec: Dictionary, col: Color, glass_c: Color, clr: float) -> void:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var zn = -L * 0.5
	var zt = L * 0.5
	var dark = Color(0.06, 0.06, 0.07)
	var chrome = Color(0.78, 0.8, 0.84)
	if String(spec["style"]) == "truck":
		var cab_l = 2.4
		mb.box(Vector3(0, 0.62, 0), Vector3(W * 0.7, 0.3, L), dark)
		mb.box(Vector3(0, 1.55, zn + cab_l * 0.5), Vector3(W, 1.9, cab_l), col)
		gl.quad(Vector3(-W * 0.44, 1.5, zn - 0.01), Vector3(W * 0.44, 1.5, zn - 0.01), Vector3(W * 0.44, 2.35, zn - 0.01), Vector3(-W * 0.44, 2.35, zn - 0.01), glass_c)
		for sx in [-1.0, 1.0]:
			gl.quad(Vector3(sx * (W * 0.5 + 0.01), 1.5, zn + 0.3), Vector3(sx * (W * 0.5 + 0.01), 1.5, zn + 1.7), Vector3(sx * (W * 0.5 + 0.01), 2.3, zn + 1.7), Vector3(sx * (W * 0.5 + 0.01), 2.3, zn + 0.3), glass_c)
			mb.box(Vector3(sx * (W * 0.5 + 0.25), 2.0, zn + 0.5), Vector3(0.08, 0.5, 0.2), dark)
			mb.box(Vector3(sx * (W * 0.5 - 0.3), 0.95, zn - 0.02), Vector3(0.4, 0.2, 0.06), dark)
			mb.cyl_x(Vector3(sx * (W * 0.5 - 0.35), 0.7, zn + cab_l + 1.0), 0.32, 0.8, 10, chrome, true)
		mb.box(Vector3(0, 0.9, zn - 0.03), Vector3(W * 0.7, 0.5, 0.06), dark)
		mb.box(Vector3(0, 1.17, zn - 0.04), Vector3(W * 0.72, 0.03, 0.06), chrome)
		mb.prism_y(Vector3(W * 0.5 - 0.15, 1.5, zn + cab_l + 0.2), 0.09, 0.09, 1.9, 8, chrome, true)
		var bz0 = zn + cab_l + 0.25
		var cargo = Color(0.88, 0.88, 0.9).lerp(col, 0.12)
		mb.box(Vector3(0, 2.15, (bz0 + zt) * 0.5), Vector3(W, 2.7, zt - bz0), cargo)
		var rz = bz0 + 0.8
		while rz < zt - 0.4:
			for sx in [-1.0, 1.0]:
				mb.box(Vector3(sx * (W * 0.5 + 0.006), 2.15, rz), Vector3(0.02, 2.6, 0.06), cargo.darkened(0.3))
			rz += 1.3
		mb.box(Vector3(0, 0.55, zt - 0.1), Vector3(W, 0.3, 0.2), dark)
		for z in [zn + 1.2, zt - 3.2, zt - 1.8]:
			for sx in [-1.0, 1.0]:
				mb.cyl_x(Vector3(sx * (W * 0.5 - 0.02), 0.5, z), 0.62, 0.07, 12, dark)
	else:
		mb.box(Vector3(0, 1.65, 0), Vector3(W, 2.7, L), col)
		mb.box(Vector3(0, 0.42, 0), Vector3(W * 0.98, 0.3, L), dark)
		mb.box(Vector3(0, 3.1, 0.3), Vector3(W * 0.6, 0.25, 2.6), Color(0.82, 0.84, 0.86))
		for sx in [-1.0, 1.0]:
			var x = sx * (W * 0.5 + 0.01)
			mb.box(Vector3(x, 1.0, 0), Vector3(0.01, 0.22, L * 0.96), col.lightened(0.45) if col.get_luminance() < 0.6 else col.darkened(0.35))
			var zz = zn + 2.2 if sx > 0.0 else zn + 1.0
			var seg = 0
			while zz < zt - 1.3:
				if sx > 0.0 and zz < zn + 3.4:
					zz += 1.9
					continue
				gl.quad(Vector3(x, 1.45, zz), Vector3(x, 1.45, zz + 1.6), Vector3(x, 2.55, zz + 1.6), Vector3(x, 2.55, zz), glass_c)
				zz += 1.9
		gl.quad(Vector3(W * 0.5 + 0.012, 0.5, zn + 0.5), Vector3(W * 0.5 + 0.012, 0.5, zn + 1.7), Vector3(W * 0.5 + 0.012, 2.5, zn + 1.7), Vector3(W * 0.5 + 0.012, 2.5, zn + 0.5), Color(0.05, 0.1, 0.14, 0.8))
		gl.quad(Vector3(-W * 0.46, 1.3, zn - 0.01), Vector3(W * 0.46, 1.3, zn - 0.01), Vector3(W * 0.46, 2.65, zn - 0.01), Vector3(-W * 0.46, 2.65, zn - 0.01), glass_c)
		gl.quad(Vector3(-W * 0.4, 1.6, zt + 0.01), Vector3(W * 0.4, 1.6, zt + 0.01), Vector3(W * 0.4, 2.5, zt + 0.01), Vector3(-W * 0.4, 2.5, zt + 0.01), glass_c)
		mb.box(Vector3(0, 2.85, zn - 0.01), Vector3(W * 0.6, 0.2, 0.03), dark)
		for z in [zn + 2.2, zt - 2.4]:
			for sx in [-1.0, 1.0]:
				mb.cyl_x(Vector3(sx * (W * 0.5 - 0.02), 0.5, z), 0.62, 0.07, 12, dark)

const HALF_RING := [[0.80, 0.0], [0.97, 0.10], [1.0, 0.40], [0.99, 0.72], [0.93, 0.92], [0.72, 0.99], [0.35, 1.0], [0.0, 1.0]]

static func _topline(zf: float, c0f: float, c1f: float, hb: float) -> float:
	if zf < c0f:
		return lerpf(hb - 0.12, hb - 0.02, smoothstep(0.0, 1.0, zf / maxf(c0f, 0.01)))
	if zf <= c1f:
		return hb
	return lerpf(hb, hb - 0.1, smoothstep(0.0, 1.0, (zf - c1f) / maxf(1.0 - c1f, 0.02)))

static func _plan(zf: float) -> float:
	var e = minf(zf, 1.0 - zf)
	if e < 0.06:
		var u = (0.06 - e) / 0.06
		return 0.72 + 0.28 * sqrt(maxf(1.0 - u * u, 0.0))
	return 1.0

static func _loft_body(mb, L: float, W: float, hb: float, clr: float, c0f: float, c1f: float, col: Color, zf_end: float = 1.0) -> void:
	var zn = -L * 0.5
	var ns = 22
	var grid = []
	var centers = []
	for i in range(ns + 1):
		var t = float(i) / float(ns)
		var zf = (0.5 - 0.5 * cos(PI * t)) * zf_end
		var z = lerpf(zn, -zn, zf)
		var top = _topline(zf, c0f, c1f, hb)
		var bot = clr + 0.1 + 0.06 * smoothstep(0.85, 1.0, absf(zf - 0.5) * 2.0)
		var hw = W * 0.5 * _plan(zf)
		var hh = top - bot
		var ring = PackedVector3Array()
		for j in range(HALF_RING.size()):
			var p = HALF_RING[j]
			ring.append(Vector3(-hw * float(p[0]), bot + hh * float(p[1]), z))
		for j in range(HALF_RING.size() - 2, -1, -1):
			var p2 = HALF_RING[j]
			ring.append(Vector3(hw * float(p2[0]), bot + hh * float(p2[1]), z))
		grid.append(ring)
		centers.append(Vector3(0, bot + hh * 0.4, z))
	mb.loft(grid, centers, func(i, k): return col)
	var ends = [0, ns] if zf_end >= 0.999 else [0]
	for e in ends:
		var ring2 = grid[e]
		for k in range(ring2.size() - 1):
			mb.tri(centers[e], ring2[k + 1], ring2[k], col)

static func _loft_cabin(mb, gl, W: float, hb: float, ch: float, c0: float, c1: float, rf: float, rr: float, col: Color, glass_c: Color) -> void:
	var base_y = hb - 0.07
	var hwb = W * 0.5 * 0.86
	var hwt = W * 0.5 - 0.22
	var m0 = c0 + rf
	var m1 = c1 - rr
	var zs = [c0, c0 + rf * 0.3, c0 + rf * 0.65, m0, lerpf(m0, m1, 0.33), lerpf(m0, m1, 0.66), m1, c1 - rr * 0.65, c1 - rr * 0.3, c1]
	var grid = []
	var centers = []
	for z in zs:
		var h = ch
		if z <= m0:
			h = ch * pow(clampf((z - c0) / maxf(rf, 0.05), 0.0, 1.0), 0.9)
		elif z >= m1:
			h = ch * pow(clampf((c1 - z) / maxf(rr, 0.05), 0.0, 1.0), 0.8)
		else:
			var tt = (z - m0) / maxf(m1 - m0, 0.05)
			h = ch * (1.0 - 0.05 * pow(2.0 * tt - 1.0, 2.0))
		var half = [[hwb, 0.0], [lerpf(hwb, hwt, 0.55), h * 0.62], [hwt, h * 0.95], [hwt * 0.7, h], [hwt * 0.35, h * 1.01], [0.0, h * 1.015]]
		var ring = PackedVector3Array()
		for j in range(half.size()):
			ring.append(Vector3(-float(half[j][0]), base_y + float(half[j][1]), z))
		for j in range(half.size() - 2, -1, -1):
			ring.append(Vector3(float(half[j][0]), base_y + float(half[j][1]), z))
		grid.append(ring)
		centers.append(Vector3(0, base_y + h * 0.3, z))
	var nr = grid[0].size()
	# glass: all sides, plus windshield and rear window tops
	gl.loft(grid, centers, func(i, k):
		var side = (k <= 1 or k >= nr - 3)
		var top_glass = (i <= 2 or i >= 6)
		if side or top_glass:
			return glass_c
		return null)
	mb.loft(grid, centers, func(i, k):
		var side = (k <= 1 or k >= nr - 3)
		var top_glass = (i <= 2 or i >= 6)
		if side or top_glass:
			return null
		return col)

static func _car(mb, gl, spec: Dictionary, col: Color, glass_c: Color, ride: float, o: Dictionary) -> void:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var style = String(spec["style"])
	var sp = STYLES[style]
	var clr = 0.17 + ride
	var hb = float(sp["hb"]) + ride
	var ch = float(sp["ch"])
	var zn = -L * 0.5
	var zt = L * 0.5
	var c0 = zn + float(sp["cab0"]) * L
	var c1 = zn + float(sp["cab1"]) * L
	var rf = float(sp["rf"])
	var rr = float(sp["rr"])
	var cb = hb - 0.07
	var hwb = W * 0.5 * 0.86
	var hwt = W * 0.5 - 0.22
	var dark = Color(0.06, 0.06, 0.07)
	var chrome = Color(0.78, 0.8, 0.84)
	var wbz = float(spec.get("wb", L * 0.64)) * 0.5
	mb.box(Vector3(0, clr + 0.07, 0), Vector3(W - 0.25, 0.1, L - 0.4), dark)
	_loft_body(mb, L, W, hb, clr, float(sp["cab0"]), float(sp["cab1"]), col)
	_loft_cabin(mb, gl, W, hb, ch, c0, c1, rf, rr, col, glass_c)
	var cl = c1 - c0
	for sx in [-1.0, 1.0]:
		mb.beam(Vector3(sx * hwb, cb + 0.02, c0 + 0.02), Vector3(sx * hwt, cb + ch * 0.95, c0 + rf), 0.05, col)
		mb.beam(Vector3(sx * hwb, cb, c1 - 0.04), Vector3(sx * hwt, cb + ch * 0.95, c1 - rr), 0.12, col)
		mb.box(Vector3(sx * (W * 0.5 * 0.93 + 0.004), hb - 0.04, (c0 + c1) * 0.5), Vector3(0.012, 0.025, cl), chrome)
		for zf in [0.3, 0.64]:
			if style == "sport" and zf > 0.5:
				continue
			mb.box(Vector3(sx * (W * 0.5 + 0.003), (clr + 0.25 + hb - 0.28) * 0.5, c0 + cl * zf), Vector3(0.012, hb - 0.28 - clr - 0.25, 0.02), dark)
			var bz1 = c0 + cl * zf
			var bz2 = (c0 + rf) + ((c1 - rr) - (c0 + rf)) * zf
			mb.beam(Vector3(sx * (hwb + 0.01), cb, bz1), Vector3(sx * (hwt + 0.01), cb + ch * 0.95, bz2), 0.03, dark)
		for zf in [0.22, 0.56]:
			if style == "sport" and zf > 0.5:
				continue
			mb.box(Vector3(sx * (W * 0.5 + 0.012), hb - 0.2, c0 + cl * zf), Vector3(0.02, 0.025, 0.12), chrome)
		mb.box(Vector3(sx * (W * 0.5 - 0.01), clr + 0.1, 0), Vector3(0.05, 0.1, wbz * 1.5), dark)
		for iz in [-1.0, 1.0]:
			mb.cyl_x(Vector3(sx * (W * 0.5 - 0.02), 0.34, iz * wbz), minf(0.4, hb - 0.36), 0.07, 12, dark)
		mb.box(Vector3(sx * (W * 0.5 - 0.27), hb - 0.22, zn + 0.045), Vector3(0.4, 0.15, 0.08), dark)
		mb.box(Vector3(sx * (W * 0.5 - 0.25), hb - 0.2, zt - 0.035), Vector3(0.38, 0.13, 0.07), dark)
		mb.box(Vector3(sx * (W * 0.5 - 0.3), clr + 0.2, zn + 0.04), Vector3(0.14, 0.06, 0.05), Color(0.95, 0.95, 0.85))
		if not bool(o.get("no_mirrors", false)):
			mb.box(Vector3(sx * (W * 0.5 + 0.09), hb + 0.17, c0 + 0.12), Vector3(0.16, 0.1, 0.1), col)
	mb.box(Vector3(0, clr + 0.15, zn + 0.07), Vector3(W * 0.97, 0.28, 0.16), dark)
	mb.box(Vector3(0, clr + 0.15, zt - 0.07), Vector3(W * 0.97, 0.28, 0.16), dark)
	mb.box(Vector3(0, hb - 0.3, zn + 0.02), Vector3(W * 0.44, 0.12, 0.05), dark)
	mb.box(Vector3(0, hb - 0.235, zn + 0.015), Vector3(W * 0.48, 0.015, 0.05), chrome)
	mb.beam(Vector3(-0.5, cb + 0.1, c0 + 0.1), Vector3(0.05, cb + 0.1, c0 + 0.1), 0.012, dark)
	if style == "suv":
		for sx in [-0.5, 0.5]:
			mb.beam(Vector3(sx, cb + ch + 0.04, c0 + rf), Vector3(sx, cb + ch + 0.04, c1 - rr), 0.03, dark)
		mb.box(Vector3(0, clr + 0.05, zn + 0.1), Vector3(W * 0.5, 0.05, 0.35), chrome)
		mb.box(Vector3(0, clr + 0.05, zt - 0.1), Vector3(W * 0.5, 0.05, 0.3), chrome)
	elif style == "sport":
		for sx in [-1.0, 1.0]:
			mb.box(Vector3(sx * (W * 0.5 + 0.002), hb - 0.3, c1 + 0.05), Vector3(0.03, 0.14, 0.35), dark)
		mb.box(Vector3(0, clr + 0.1, zt - 0.08), Vector3(W * 0.7, 0.08, 0.3), dark)
		mb.box(Vector3(0, clr + 0.07, zn - 0.04), Vector3(W * 0.95, 0.03, 0.25), dark)
	elif style == "hatch":
		mb.box(Vector3(0, cb + ch * 0.97, c1 - 0.06), Vector3(hwt * 1.7, 0.04, 0.2), col)
	elif style == "pickup":
		var bz0 = c1 + 0.05
		mb.box(Vector3(0, hb - 0.12, (bz0 + zt) * 0.5), Vector3(W * 0.9, 0.06, zt - bz0), dark)
		for sx in [-1.0, 1.0]:
			mb.box(Vector3(sx * (W * 0.5 - 0.05), hb + 0.1, (bz0 + zt) * 0.5), Vector3(0.1, 0.34, zt - bz0), col)
		mb.box(Vector3(0, hb + 0.1, zt - 0.05), Vector3(W, 0.34, 0.1), col)
		mb.box(Vector3(0, hb + 0.1, bz0 + 0.03), Vector3(W, 0.34, 0.06), col)
		mb.box(Vector3(0, hb + 0.2, zt - 0.1), Vector3(0.25, 0.03, 0.03), chrome)
	elif style == "van":
		mb.box(Vector3(W * 0.5 + 0.004, hb + 0.2, (c0 + c1) * 0.5), Vector3(0.012, 1.0, 0.025), dark)
	if bool(o.get("plates", true)):
		mb.box(Vector3(0, 0.42, zt + 0.015), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))
		mb.box(Vector3(0, 0.42, zn - 0.015), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))

# Builds body (surface 0) and glass (surface 1)
static func body_mesh(spec: Dictionary, col: Color, o: Dictionary) -> ArrayMesh:
	var style = String(spec["style"])
	var ride = float(o.get("ride", 0.0))
	var mb = MeshBuf.new()
	var gl = MeshBuf.new()
	var glass_c = Color(0.07, 0.11, 0.15, float(o.get("glass_a", 0.55)))
	var L = float(spec["L"])
	var wbz = float(spec.get("wb", L * 0.64)) * 0.5
	if style == "truck" or style == "bus":
		_heavy(mb, gl, spec, col, glass_c, 0.17)
		if bool(o.get("merge_wheels", false)):
			var zn = -L * 0.5
			var zt = L * 0.5
			var zs = [zn + 1.2, zt - 3.2, zt - 1.8] if style == "truck" else [zn + 2.2, zt - 2.4]
			_wheels(mb, spec, 0.5, 0.3, zs)
	else:
		_car(mb, gl, spec, col, glass_c, ride, o)
		if bool(o.get("merge_wheels", false)):
			_wheels(mb, spec, 0.32, 0.24, [-wbz, wbz])
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("body"))
	gl.to_mesh(m, mat("glass"))
	return m

static func light_mesh(spec: Dictionary, rear: bool, ride: float = 0.0) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var sp = STYLES[String(spec["style"])]
	var hb = float(sp["hb"]) + ride
	var style = String(spec["style"])
	var y = hb - 0.22
	var h = 0.12
	var w = 0.34
	if style == "truck" or style == "bus":
		y = 0.9
		h = 0.2
	if style == "truck" and not rear:
		y = 0.85
	var z = L * 0.5 + 0.015 if rear else -L * 0.5 - 0.015
	var mb = MeshBuf.new()
	for sx in [-1.0, 1.0]:
		var x = sx * (W * 0.5 - 0.22)
		mb.quad(Vector3(x - w * 0.5, y - h * 0.5, z), Vector3(x + w * 0.5, y - h * 0.5, z), Vector3(x + w * 0.5, y + h * 0.5, z), Vector3(x - w * 0.5, y + h * 0.5, z), Color.WHITE)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("tail_run") if rear else mat("head"))
	return m

static func signal_mesh(spec: Dictionary, side: float) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var mb = MeshBuf.new()
	var y = 0.6
	if String(spec["style"]) == "truck" or String(spec["style"]) == "bus":
		y = 0.75
	var x = side * (W * 0.5 - 0.1)
	for z in [-L * 0.5 - 0.02, L * 0.5 + 0.02]:
		mb.quad(Vector3(x - 0.09, y - 0.05, z), Vector3(x + 0.09, y - 0.05, z), Vector3(x + 0.09, y + 0.05, z), Vector3(x - 0.09, y + 0.05, z), Color.WHITE)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("signal"))
	return m

static func beam_mesh(spec: Dictionary) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var mb = MeshBuf.new()
	var z0 = -L * 0.5
	var a = Color(1.0, 0.95, 0.75, 0.35)
	var b = Color(1.0, 0.95, 0.75, 0.0)
	mb.quadv(Vector3(-W * 0.5, 0.07, z0), Vector3(W * 0.5, 0.07, z0), Vector3(W * 1.8, 0.07, z0 - 32.0), Vector3(-W * 1.8, 0.07, z0 - 32.0), a, a, b, b)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("beam"))
	return m

static var _body_cache := {}

# Traffic vehicle node (pooled by TrafficManager)
static func build_traffic(spec: Dictionary, col_hex: String) -> Node3D:
	var v = TrafficVehicle.new()
	v.spec = spec
	var key = String(spec["id"]) + col_hex
	if not _body_cache.has(key):
		_body_cache[key] = body_mesh(spec, hexc(col_hex), {"merge_wheels": true})
	var body = MeshInstance3D.new()
	body.mesh = _body_cache[key]
	v.add_child(body)
	v.body = body
	var lights = {}
	var rear = MeshInstance3D.new()
	rear.mesh = light_mesh(spec, true)
	rear.material_override = mat("tail_run")
	v.add_child(rear)
	v.rear = rear
	var head = MeshInstance3D.new()
	head.mesh = light_mesh(spec, false)
	v.add_child(head)
	v.head = head
	var sl = MeshInstance3D.new()
	sl.mesh = signal_mesh(spec, -1.0)
	v.add_child(sl)
	v.sig_l = sl
	var sr = MeshInstance3D.new()
	sr.mesh = signal_mesh(spec, 1.0)
	v.add_child(sr)
	v.sig_r = sr
	var bm = MeshInstance3D.new()
	bm.mesh = beam_mesh(spec)
	v.add_child(bm)
	v.beam = bm
	sl.visible = false
	sr.visible = false
	bm.visible = false
	return v


# analog gauge (dial, ticks, numbers, needle) facing +Z, tilted toward the driver
static func _gauge(parent: Node3D, pos: Vector3, r: float, maxv: float, step: float, red_from: float, tilt: float) -> Dictionary:
	var g = Node3D.new()
	g.position = pos
	g.rotation_degrees = Vector3(tilt, 0, 0)
	parent.add_child(g)
	var bezel = MeshInstance3D.new()
	var bm = CylinderMesh.new()
	bm.top_radius = r * 1.1
	bm.bottom_radius = r * 1.1
	bm.height = 0.008
	bezel.mesh = bm
	bezel.rotation_degrees = Vector3(90, 0, 0)
	bezel.position = Vector3(0, 0, -0.004)
	var bmat = StandardMaterial3D.new()
	bmat.albedo_color = Color(0.7, 0.72, 0.76)
	bmat.metallic = 0.8
	bmat.roughness = 0.3
	bezel.material_override = bmat
	bezel.layers = 2
	g.add_child(bezel)
	var dial = MeshInstance3D.new()
	var dm = CylinderMesh.new()
	dm.top_radius = r
	dm.bottom_radius = r
	dm.height = 0.006
	dial.mesh = dm
	dial.rotation_degrees = Vector3(90, 0, 0)
	var dmat = StandardMaterial3D.new()
	dmat.albedo_color = Color(0.02, 0.02, 0.03)
	dmat.roughness = 0.5
	dial.material_override = dmat
	dial.layers = 2
	g.add_child(dial)
	var tb = MeshBuf.new()
	var half = step * 0.5
	var n = int(round(maxv / half))
	for i in range(0, n + 1):
		var v = float(i) * half
		var frac = v / maxv
		var a = deg_to_rad(135.0 - 270.0 * frac)
		var major = (i % 2 == 0)
		var c = Color(1, 1, 1) if v < red_from else Color(1.0, 0.25, 0.2)
		var rr = r * (0.86 if major else 0.89)
		var ctr = Vector3(-sin(a), cos(a), 0.0035) * rr
		tb.box_b(ctr, Vector3(0.005 if major else 0.003, r * (0.16 if major else 0.09), 0.001), Basis(Vector3(0, 0, 1), a), c)
		if major:
			var lb = Label3D.new()
			lb.text = str(int(v))
			lb.font_size = 32
			lb.pixel_size = r * 0.0075
			lb.modulate = c
			lb.position = Vector3(-sin(a), cos(a), 0.0045) * (r * 0.62)
			lb.layers = 2
			g.add_child(lb)
	var tm = ArrayMesh.new()
	tb.to_mesh(tm, mat("light"))
	var tmi = MeshInstance3D.new()
	tmi.mesh = tm
	tmi.layers = 2
	g.add_child(tmi)
	var piv = Node3D.new()
	piv.position = Vector3(0, 0, 0.007)
	g.add_child(piv)
	var nd = MeshInstance3D.new()
	var nb = BoxMesh.new()
	nb.size = Vector3(0.006, r * 0.82, 0.002)
	nd.mesh = nb
	nd.position = Vector3(0, r * 0.31, 0)
	var nmat = StandardMaterial3D.new()
	nmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	nmat.albedo_color = Color(1.0, 0.2, 0.1)
	nd.material_override = nmat
	nd.layers = 2
	piv.add_child(nd)
	var hub = MeshInstance3D.new()
	var hm = CylinderMesh.new()
	hm.top_radius = r * 0.09
	hm.bottom_radius = r * 0.09
	hm.height = 0.004
	hub.mesh = hm
	hub.rotation_degrees = Vector3(90, 0, 0)
	hub.position = Vector3(0, 0, 0.003)
	hub.material_override = bmat
	hub.layers = 2
	piv.add_child(hub)
	piv.rotation.z = deg_to_rad(135.0)
	return {"node": g, "needle": piv, "max": maxv}

# ------------------------------------------------------------------ player car
static func build_player(car_id: String) -> Dictionary:
	var base = GameData.car_by_id(car_id)
	var st = Save.car_state(car_id)
	var Cust = load("res://scripts/game/customization_manager.gd")
	var g = func(k): return Cust.get_idx(st, k)
	var L = float(base["L"])
	var W = float(base["W"])
	var style = String(base["style"])
	var sp = STYLES[style]
	var ride = [0.0, -0.04, 0.06][g.call("suspension")]
	var hb = float(sp["hb"]) + ride
	var ch = float(sp["ch"])
	var col = hexc(String(st["paint"]))
	var tint_a = [0.28, 0.45, 0.62, 0.82][g.call("tint")]
	var spec = base.duplicate()
	var root = Node3D.new()
	var pivot = Node3D.new()
	pivot.position = Vector3(0, 0.5, 0)
	root.add_child(pivot)
	var off = Node3D.new()
	off.position = Vector3(0, -0.5, 0)
	pivot.add_child(off)
	var out = {"root": root, "pivot": pivot, "L": L, "W": W}
	var ext = MeshInstance3D.new()
	var em = body_mesh(spec, col, {"ride": ride, "glass_a": tint_a, "no_mirrors": true, "plates": false})
	var px = MeshBuf.new()
	var dark = Color(0.06, 0.06, 0.07)
	var zn = -L * 0.5
	var zt = L * 0.5
	var c0 = zn + float(sp["cab0"]) * L
	var c1 = zn + float(sp["cab1"]) * L
	var rear_y = hb + 0.02
	var spo = g.call("spoiler")
	var sx_w = W * 0.5 - 0.15
	if spo == 1:
		px.box(Vector3(0, rear_y + 0.05, zt - 0.12), Vector3(W * 0.8, 0.06, 0.25), dark)
	elif spo == 2:
		px.box(Vector3(0, rear_y + 0.1, zt - 0.2), Vector3(W * 0.86, 0.08, 0.4), col)
	elif spo >= 3:
		var hh = 0.3 if spo == 3 else 0.42
		var wd = 0.5 if spo == 3 else 0.7
		for sx in [-1.0, 1.0]:
			px.box(Vector3(sx * sx_w * 0.8, rear_y + hh * 0.5, zt - 0.35), Vector3(0.06, hh, 0.25), dark)
		px.box(Vector3(0, rear_y + hh, zt - 0.35), Vector3(W * 0.95, 0.05, wd), dark)
	var fb = g.call("fbumper")
	if fb == 1:
		px.box(Vector3(0, 0.26, zn - 0.04), Vector3(W * 0.96, 0.1, 0.18), dark)
	elif fb == 2:
		px.box(Vector3(0, 0.2, zn - 0.15), Vector3(W * 1.0, 0.05, 0.4), dark)
		for sx in [-1.0, 1.0]:
			px.box(Vector3(sx * W * 0.5, 0.3, zn - 0.05), Vector3(0.04, 0.2, 0.3), dark)
	var rb = g.call("rbumper")
	if rb == 1:
		px.box(Vector3(0, 0.26, zt + 0.04), Vector3(W * 0.96, 0.1, 0.18), dark)
	elif rb == 2:
		px.box(Vector3(0, 0.24, zt + 0.1), Vector3(W * 0.9, 0.08, 0.3), dark)
		for i in range(-3, 4):
			px.box(Vector3(float(i) * W * 0.12, 0.2, zt + 0.12), Vector3(0.03, 0.14, 0.3), dark)
	var ex = g.call("exhaust")
	var chrome = Color(0.75, 0.77, 0.8)
	var ex_pos = [[0.5], [-0.5, 0.5], [-0.6, -0.4, 0.4, 0.6], [0.0]][ex]
	for xe in ex_pos:
		if ex == 3:
			for sx in [-1.0, 1.0]:
				px.box(Vector3(sx * (W * 0.5 + 0.02), 0.28, zn + L * 0.55), Vector3(0.08, 0.1, 0.25), chrome)
		else:
			px.box(Vector3(float(xe) * W * 0.5, 0.26, zt + 0.12), Vector3(0.11, 0.11, 0.2), chrome)
	var mcol = [col, Color(0.05, 0.05, 0.06), chrome, Color(0.13, 0.13, 0.15)][g.call("mirrors")]
	for sx in [-1.0, 1.0]:
		px.box(Vector3(sx * (W * 0.5 + 0.1), hb + 0.18, c0 + 0.1), Vector3(0.18, 0.1, 0.1), mcol)
		px.box(Vector3(sx * (W * 0.5 + 0.03), hb + 0.1, c0 + 0.1), Vector3(0.06, 0.03, 0.03), dark)
	var dec = g.call("decal")
	if dec > 0:
		var dc = hexc(GameData.DECAL_COLORS[g.call("decal_color")])
		var cabh = hb + ch + 0.02
		if dec == 1 or dec == 3:
			for sx in [-0.14, 0.14]:
				px.quad(Vector3(sx - 0.07, hb + 0.012, zn + 0.45), Vector3(sx + 0.07, hb + 0.012, zn + 0.45), Vector3(sx + 0.07, hb + 0.012, c0), Vector3(sx - 0.07, hb + 0.012, c0), dc)
			if dec == 1:
				for sx in [-0.14, 0.14]:
					px.quad(Vector3(sx - 0.07, cabh, c0 + float(sp["rf"])), Vector3(sx + 0.07, cabh, c0 + float(sp["rf"])), Vector3(sx + 0.07, cabh, c1 - float(sp["rr"])), Vector3(sx - 0.07, cabh, c1 - float(sp["rr"])), dc)
		if dec == 2:
			for sx in [-1.0, 1.0]:
				px.quad(Vector3(sx * (W * 0.5 + 0.012), 0.38 + ride, zn), Vector3(sx * (W * 0.5 + 0.012), 0.38 + ride, zt), Vector3(sx * (W * 0.5 + 0.012), 0.5 + ride, zt), Vector3(sx * (W * 0.5 + 0.012), 0.5 + ride, zn), dc)
	px.box(Vector3(0, 0.42, zt + 0.02), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))
	px.box(Vector3(0, 0.42, zn - 0.02), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))
	px.to_mesh(em, mat("body"))
	ext.mesh = em
	ext.layers = 4
	off.add_child(ext)
	out["ext"] = ext
	var plate = String(st.get("plate", "HWY 001"))
	for side in [1.0, -1.0]:
		var lb = Label3D.new()
		lb.text = plate
		lb.font_size = 40
		lb.pixel_size = 0.0035
		lb.modulate = Color(0.05, 0.05, 0.1)
		lb.position = Vector3(0, 0.42, zt + 0.035) if side > 0.0 else Vector3(0, 0.42, zn - 0.035)
		if side < 0.0:
			lb.rotation.y = PI
		lb.layers = 4
		off.add_child(lb)
	var tl_i = g.call("taillight")
	var rear_mi = MeshInstance3D.new()
	rear_mi.mesh = light_mesh(spec, true, ride)
	rear_mi.layers = 4
	off.add_child(rear_mi)
	var head_mi = MeshInstance3D.new()
	head_mi.mesh = light_mesh(spec, false, ride)
	var hcols = ["#fff0cc", "#e8f2ff", "#bcd2ff", "#ffbb55"]
	var hm = StandardMaterial3D.new()
	hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	hm.albedo_color = hexc(hcols[g.call("headlight")])
	head_mi.material_override = hm
	head_mi.layers = 4
	off.add_child(head_mi)
	out["rear_mi"] = rear_mi
	out["tail_style"] = tl_i
	# wheels
	var wsize = g.call("wheel_size")
	var tr = 0.31 + 0.012 * float(wsize)
	var rimr = tr * (0.58 + 0.03 * float(wsize))
	var wcol = hexc(GameData.WHEEL_COLORS[g.call("wheel_color")])
	var wstyle = g.call("wheel_style")
	var wmesh = ArrayMesh.new()
	var wb = MeshBuf.new()
	wb.cyl_x(Vector3.ZERO, tr, 0.24, 16, Color(0.04, 0.04, 0.05))
	wb.cyl_x(Vector3.ZERO, rimr, 0.25, 14, wcol)
	var nsp = [0, 5, 10, 7][wstyle]
	for i in nsp:
		var a = TAU * float(i) / float(maxi(nsp, 1))
		wb.box_b(Vector3(0.125, sin(a) * rimr * 0.5, cos(a) * rimr * 0.5), Vector3(0.02, rimr * 0.08 + 0.02, rimr * 0.95), Basis(Vector3.RIGHT, -a + PI * 0.5), Color(0.1, 0.1, 0.11))
	wb.cyl_x(Vector3(0.126, 0, 0), rimr * 0.2, 0.02, 8, wcol.darkened(0.3))
	wb.box(Vector3(-0.03, 0.0, -rimr * 0.55), Vector3(0.05, rimr * 0.5, rimr * 0.25), Color(0.7, 0.1, 0.1))
	wb.to_mesh(wmesh, mat("wheel"))
	var wbz = float(base["wb"]) * 0.5
	var track = W * 0.5 - 0.13
	var spins = []
	var fronts = []
	for iz in [-1.0, 1.0]:
		for sx in [-1.0, 1.0]:
			var piv = Node3D.new()
			piv.position = Vector3(sx * track, tr, iz * wbz)
			off.add_child(piv)
			var wm = MeshInstance3D.new()
			wm.mesh = wmesh
			if sx < 0.0:
				wm.rotation.y = PI
			wm.layers = 4
			piv.add_child(wm)
			spins.append(wm)
			if iz < 0.0:
				fronts.append(piv)
	out["spins"] = spins
	out["fronts"] = fronts
	out["wheel_r"] = tr
	var spots = []
	for sx in [-1.0, 1.0]:
		var sl = SpotLight3D.new()
		sl.position = Vector3(sx * W * 0.35, hb - 0.1, zn + 0.1)
		sl.rotation_degrees = Vector3(-3, 0, 0)
		sl.spot_range = 75.0
		sl.spot_angle = 30.0
		sl.spot_attenuation = 0.8
		sl.light_energy = 0.0
		sl.light_color = hexc(hcols[g.call("headlight")])
		off.add_child(sl)
		spots.append(sl)
	out["spots"] = spots
	# ---------------- interior (layer 2) ------------------
	var icol = hexc(GameData.INTERIOR_COLORS[g.call("interior")])
	var ib = MeshBuf.new()
	var ex_ = -0.36 * (W / 1.75)
	var cab_top = hb + ch
	var hwb = W * 0.5 - 0.07
	var hwt = W * 0.5 - 0.2
	var rf = float(sp["rf"])
	var rr_ = float(sp["rr"])
	# dash + hood (visible through the windshield)
	ib.box(Vector3(0, hb + 0.04, c0 + 0.32), Vector3(W - 0.14, 0.1, 0.64), icol)
	ib.box(Vector3(0, hb - 0.04, c0 + 0.04), Vector3(W - 0.2, 0.1, 0.12), icol.darkened(0.3))
	ib.box(Vector3(ex_, hb + 0.2, c0 + 0.5), Vector3(0.5, 0.22, 0.16), icol.darkened(0.25))
	_loft_body(ib, L, W, hb, 0.17 + ride, float(sp["cab0"]), float(sp["cab1"]), col, float(sp["cab0"]) + 0.02)
	ib.box(Vector3(0, hb - 0.1, (c0 + c1) * 0.5 + 0.1), Vector3(W - 0.2, 0.04, c1 - c0), icol.darkened(0.3))
	# centre console + seats
	ib.box(Vector3(0, hb - 0.02, c0 + 1.0), Vector3(0.2, 0.18, 0.7), icol.darkened(0.2))
	for sx in [ex_, -ex_]:
		ib.box(Vector3(sx, hb - 0.05, c0 + 1.15), Vector3(0.46, 0.14, 0.5), icol.lightened(0.05))
		ib.box(Vector3(sx, hb + 0.2, c0 + 1.42), Vector3(0.44, 0.55, 0.12), icol.lightened(0.05))
	for sx in [-1.0, 1.0]:
		ib.beam(Vector3(sx * hwb, hb, c0), Vector3(sx * hwt, cab_top, c0 + rf), 0.07, icol.darkened(0.2))
		ib.box(Vector3(sx * (W * 0.5 - 0.06), hb - 0.1, (c0 + c1) * 0.5), Vector3(0.08, 0.5, c1 - c0), icol)
		ib.beam(Vector3(sx * hwb, hb, c1 - 0.2), Vector3(sx * hwt, cab_top, c1 - rr_), 0.08, icol.darkened(0.2))
		ib.box(Vector3(sx * (W * 0.5 + 0.1), hb + 0.17, c0 + 0.12), Vector3(0.16, 0.1, 0.1), mcol)
	ib.beam(Vector3(-hwt, cab_top, c0 + rf), Vector3(hwt, cab_top, c0 + rf), 0.07, icol.darkened(0.2))
	ib.quad(Vector3(-hwt, cab_top - 0.02, c0 + rf), Vector3(hwt, cab_top - 0.02, c0 + rf), Vector3(hwt, cab_top - 0.02, c1 - rr_), Vector3(-hwt, cab_top - 0.02, c1 - rr_), icol.darkened(0.15))
	ib.beam(Vector3(ex_, hb + 0.12, c0 + 0.76), Vector3(ex_, hb + 0.02, c0 + 0.5), 0.05, Color(0.04, 0.04, 0.05))
	var im = ArrayMesh.new()
	ib.to_mesh(im, mat("interior"))
	var imi = MeshInstance3D.new()
	imi.mesh = im
	imi.layers = 2
	off.add_child(imi)
	var ta = [0.0, 0.08, 0.16, 0.28][g.call("tint")]
	if ta > 0.0:
		var tb = MeshBuf.new()
		tb.quad(Vector3(-hwb, hb, c0 - 0.02), Vector3(hwb, hb, c0 - 0.02), Vector3(hwt, cab_top, c0 + rf - 0.02), Vector3(-hwt, cab_top, c0 + rf - 0.02), Color(0, 0, 0, ta))
		var tm = ArrayMesh.new()
		tb.to_mesh(tm, mat("glass"))
		var tmi = MeshInstance3D.new()
		tmi.mesh = tm
		tmi.layers = 2
		off.add_child(tmi)
	# steering wheel (lower, smaller, so it does not fill the view)
	var sw = Node3D.new()
	sw.position = Vector3(ex_, hb + 0.11, c0 + 0.78)
	sw.rotation_degrees = Vector3(-26, 0, 0)
	off.add_child(sw)
	var swr = Node3D.new()
	sw.add_child(swr)
	var tor = MeshInstance3D.new()
	var tmesh = TorusMesh.new()
	tmesh.inner_radius = 0.135
	tmesh.outer_radius = 0.16
	tmesh.rings = 20
	tmesh.ring_segments = 8
	tor.mesh = tmesh
	tor.rotation_degrees = Vector3(90, 0, 0)
	var swm = StandardMaterial3D.new()
	swm.albedo_color = Color(0.06, 0.06, 0.07)
	swm.roughness = 0.5
	tor.material_override = swm
	tor.layers = 2
	swr.add_child(tor)
	for a in [PI * 0.5, PI * 1.5, PI]:
		var sp_ = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.14, 0.022, 0.018)
		sp_.mesh = bm
		sp_.material_override = swm
		sp_.position = Vector3(cos(a) * 0.07, sin(a) * 0.07, 0)
		sp_.rotation.z = a - PI * 0.5 + PI * 0.5
		sp_.layers = 2
		swr.add_child(sp_)
	out["steer_wheel"] = swr
	# analog gauge cluster on the binnacle (speedometer + tachometer)
	var gz = c0 + 0.585
	var gy = hb + 0.2
	var smax = ceilf(GameData.speed_val(float(base["top"]) / 3.6 * 1.1) / 20.0) * 20.0
	var sstep = 20.0 if smax <= 200.0 else 40.0
	var spd = _gauge(off, Vector3(ex_ + 0.11, gy, gz), 0.085, smax, sstep, smax * 2.0, -12.0)
	var rmax = ceilf(float(base["red"]) / 1000.0)
	var tach = _gauge(off, Vector3(ex_ - 0.11, gy, gz), 0.07, rmax, 1.0, rmax - 1.0, -12.0)
	out["speed_needle"] = spd["needle"]
	out["speedo_max"] = spd["max"]
	out["rpm_needle"] = tach["needle"]
	out["rpm_max"] = tach["max"]
	var gl_ = Label3D.new()
	gl_.text = "D1"
	gl_.font_size = 30
	gl_.pixel_size = 0.0007
	gl_.modulate = Color(1.0, 0.7, 0.2)
	gl_.position = Vector3(0, -0.04, 0.005)
	gl_.layers = 2
	spd["node"].add_child(gl_)
	out["gear_label"] = gl_
	# rear-view mirror quad
	var mq = MeshInstance3D.new()
	var qm = QuadMesh.new()
	qm.size = Vector2(0.3, 0.09)
	mq.mesh = qm
	mq.position = Vector3(0, cab_top - 0.1, c0 + rf + 0.12)
	mq.rotation_degrees = Vector3(-8, 0, 0)
	mq.layers = 2
	mq.visible = false
	off.add_child(mq)
	out["mirror_quad"] = mq
	out["eye"] = Vector3(ex_, hb + 0.45, c0 + 1.05)
	out["eye_min"] = hb + 0.25
	out["eye_max"] = cab_top - 0.12
	out["rear_cam_pos"] = Vector3(0, hb + 0.6, zt - 0.2)
	out["off"] = off
	out["hb"] = hb
	return out
