extends RefCounted
## Procedural car models (player + traffic). Local space: forward = -Z, right = +X, ground y = 0.

const MeshBuf = preload("res://scripts/game/mesh_buf.gd")
const TrafficVehicle = preload("res://scripts/game/traffic_vehicle.gd")

static var _mats := {}

const STYLES := {
	"hatch": {"hb": 0.78, "cab0": 0.33, "cab1": 0.97, "ch": 0.63, "rf": 0.65, "rr": 0.12},
	"sedan": {"hb": 0.80, "cab0": 0.34, "cab1": 0.74, "ch": 0.60, "rf": 0.65, "rr": 0.55},
	"suv": {"hb": 0.95, "cab0": 0.32, "cab1": 0.98, "ch": 0.72, "rf": 0.45, "rr": 0.10},
	"pickup": {"hb": 0.95, "cab0": 0.28, "cab1": 0.58, "ch": 0.75, "rf": 0.45, "rr": 0.08},
	"sport": {"hb": 0.62, "cab0": 0.40, "cab1": 0.78, "ch": 0.42, "rf": 0.75, "rr": 0.55},
	"van": {"hb": 1.05, "cab0": 0.18, "cab1": 1.0, "ch": 0.95, "rf": 0.35, "rr": 0.03},
	"truck": {"hb": 1.0, "cab0": 0.0, "cab1": 0.2, "ch": 1.4, "rf": 0.3, "rr": 0.0},
	"bus": {"hb": 0.9, "cab0": 0.0, "cab1": 1.0, "ch": 2.0, "rf": 0.0, "rr": 0.0},
}

static func mat(name: String) -> Material:
	if _mats.has(name):
		return _mats[name]
	var m = StandardMaterial3D.new()
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.vertex_color_use_as_albedo = true
	match name:
		"body":
			m.metallic = 0.45
			m.roughness = 0.32
			m.metallic_specular = 0.6
		"glass":
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.roughness = 0.05
			m.metallic = 0.2
		"light":
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		"beam":
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
			m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
		"tail_run":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(0.45, 0.02, 0.02)
		"tail_brake":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.08, 0.05)
		"head":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.95, 0.8)
		"signal":
			m.vertex_color_use_as_albedo = false
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_color = Color(1.0, 0.6, 0.05)
		"interior":
			m.roughness = 0.8
		"wheel":
			m.roughness = 0.6
			m.metallic = 0.3
	_mats[name] = m
	return m

static func hexc(h: String) -> Color:
	return Color.html(h)

# Builds body (surface 0) and glass (surface 1)
static func body_mesh(spec: Dictionary, col: Color, o: Dictionary) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var style = String(spec["style"])
	var sp = STYLES[style]
	var clr = 0.17 + float(o.get("ride", 0.0))
	var hb = float(sp["hb"]) + float(o.get("ride", 0.0))
	var mb = MeshBuf.new()
	var gl = MeshBuf.new()
	var dark = Color(0.08, 0.08, 0.09)
	var glass_a = float(o.get("glass_a", 0.55))
	var glass_c = Color(0.08, 0.12, 0.16, glass_a)
	var zn = -L * 0.5
	var zt = L * 0.5
	var merge = bool(o.get("merge_wheels", false))
	if style == "truck":
		var cab_l = 2.3
		mb.box(Vector3(0, (clr + 2.3) * 0.5 + 0.2, zn + cab_l * 0.5), Vector3(W, 2.1, cab_l), col)
		gl.quad(Vector3(-W * 0.45, 1.5, zn - 0.01), Vector3(W * 0.45, 1.5, zn - 0.01), Vector3(W * 0.45, 2.3, zn - 0.01), Vector3(-W * 0.45, 2.3, zn - 0.01), glass_c)
		mb.box(Vector3(0, 0.55, 0), Vector3(W * 0.7, 0.3, L), dark)
		mb.box(Vector3(0, 2.0, zn + cab_l + 0.2 + (L - cab_l - 0.2) * 0.5), Vector3(W, 2.7, L - cab_l - 0.2), Color(0.88, 0.88, 0.9).lerp(col, 0.15))
	elif style == "bus":
		mb.box(Vector3(0, 1.55, 0), Vector3(W, 2.6, L), col)
		var zz = zn + 1.0
		while zz < zt - 1.2:
			gl.quad(Vector3(-W * 0.5 - 0.01, 1.5, zz), Vector3(-W * 0.5 - 0.01, 1.5, zz + 1.6), Vector3(-W * 0.5 - 0.01, 2.5, zz + 1.6), Vector3(-W * 0.5 - 0.01, 2.5, zz), glass_c)
			gl.quad(Vector3(W * 0.5 + 0.01, 1.5, zz), Vector3(W * 0.5 + 0.01, 1.5, zz + 1.6), Vector3(W * 0.5 + 0.01, 2.5, zz + 1.6), Vector3(W * 0.5 + 0.01, 2.5, zz), glass_c)
			zz += 1.9
		gl.quad(Vector3(-W * 0.45, 1.3, zn - 0.01), Vector3(W * 0.45, 1.3, zn - 0.01), Vector3(W * 0.45, 2.6, zn - 0.01), Vector3(-W * 0.45, 2.6, zn - 0.01), glass_c)
	else:
		mb.box(Vector3(0, (clr + hb) * 0.5, 0), Vector3(W, hb - clr, L), col)
		mb.box(Vector3(0, clr + 0.14, zn + 0.05), Vector3(W * 0.98, 0.28, 0.2), dark)
		mb.box(Vector3(0, clr + 0.14, zt - 0.05), Vector3(W * 0.98, 0.28, 0.2), dark)
		var ch = float(sp["ch"])
		var c0 = zn + float(sp["cab0"]) * L
		var c1 = zn + float(sp["cab1"]) * L
		var rf = float(sp["rf"])
		var rr = float(sp["rr"])
		var hwb = W * 0.5 - 0.07
		var hwt = W * 0.5 - 0.2
		gl.frustum(hb, hb + ch, c0, c1, c0 + rf, c1 - rr, hwb, hwt, glass_c, 0.0, false)
		mb.quad(Vector3(-hwt, hb + ch + 0.01, c0 + rf), Vector3(hwt, hb + ch + 0.01, c0 + rf), Vector3(hwt, hb + ch + 0.01, c1 - rr), Vector3(-hwt, hb + ch + 0.01, c1 - rr), col)
		# C pillars
		var pl = (c1 - c0) * 0.18
		for sx in [-1.0, 1.0]:
			mb.quad(Vector3(sx * (hwb + 0.01), hb, c1 - pl), Vector3(sx * (hwb + 0.01), hb, c1), Vector3(sx * (hwt + 0.01), hb + ch, c1 - rr), Vector3(sx * (hwt + 0.01), hb + ch, c1 - rr - pl * 0.6), col)
		if style == "pickup":
			var bz0 = c1 + 0.05
			mb.box(Vector3(0, (clr + hb) * 0.5 + 0.18, (bz0 + zt) * 0.5), Vector3(W, 0.12, zt - bz0), dark)
			mb.box(Vector3(-W * 0.5 + 0.05, hb + 0.12, (bz0 + zt) * 0.5), Vector3(0.1, 0.3, zt - bz0), col)
			mb.box(Vector3(W * 0.5 - 0.05, hb + 0.12, (bz0 + zt) * 0.5), Vector3(0.1, 0.3, zt - bz0), col)
			mb.box(Vector3(0, hb + 0.12, zt - 0.05), Vector3(W, 0.3, 0.1), col)
		if style == "van":
			mb.box(Vector3(0, hb + 0.4, 0), Vector3(W * 0.98, 0.1, L * 0.98), col)
	# wheels merged into body for traffic
	if merge:
		var wr = 0.32
		if style == "truck" or style == "bus":
			wr = 0.5
		var wbz = L * 0.33
		var zs = [-wbz, wbz]
		if style == "truck":
			zs = [zn + 1.2, zt - 3.2, zt - 1.8]
		elif style == "bus":
			zs = [zn + 2.2, zt - 2.4]
		for z in zs:
			for sx in [-1.0, 1.0]:
				mb.cyl_x(Vector3(sx * (W * 0.5 - 0.12), wr, z), wr, 0.24, 8, Color(0.05, 0.05, 0.06), false)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("body"))
	gl.to_mesh(m, mat("glass"))
	return m

static func light_mesh(spec: Dictionary, rear: bool, ride: float = 0.0) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var sp = STYLES[String(spec["style"])]
	var hb = float(sp["hb"]) + ride
	var style = String(spec["style"])
	var y = hb - 0.16
	var h = 0.12
	var w = 0.34
	if style == "truck" or style == "bus":
		y = 0.9
		h = 0.2
	if style == "truck" and not rear:
		y = 0.85
	var z = L * 0.5 + 0.015 if rear else -L * 0.5 - 0.015
	var mb = MeshBuf.new()
	for sx in [-1.0, 1.0]:
		var x = sx * (W * 0.5 - 0.22)
		mb.quad(Vector3(x - w * 0.5, y - h * 0.5, z), Vector3(x + w * 0.5, y - h * 0.5, z), Vector3(x + w * 0.5, y + h * 0.5, z), Vector3(x - w * 0.5, y + h * 0.5, z), Color.WHITE)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("tail_run") if rear else mat("head"))
	return m

static func signal_mesh(spec: Dictionary, side: float) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var mb = MeshBuf.new()
	var y = 0.6
	if String(spec["style"]) == "truck" or String(spec["style"]) == "bus":
		y = 0.75
	var x = side * (W * 0.5 - 0.1)
	for z in [-L * 0.5 - 0.02, L * 0.5 + 0.02]:
		mb.quad(Vector3(x - 0.09, y - 0.05, z), Vector3(x + 0.09, y - 0.05, z), Vector3(x + 0.09, y + 0.05, z), Vector3(x - 0.09, y + 0.05, z), Color.WHITE)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("signal"))
	return m

static func beam_mesh(spec: Dictionary) -> ArrayMesh:
	var L = float(spec["L"])
	var W = float(spec["W"])
	var mb = MeshBuf.new()
	var z0 = -L * 0.5
	var a = Color(1.0, 0.95, 0.75, 0.35)
	var b = Color(1.0, 0.95, 0.75, 0.0)
	mb.quadv(Vector3(-W * 0.5, 0.07, z0), Vector3(W * 0.5, 0.07, z0), Vector3(W * 1.8, 0.07, z0 - 32.0), Vector3(-W * 1.8, 0.07, z0 - 32.0), a, a, b, b)
	var m = ArrayMesh.new()
	mb.to_mesh(m, mat("beam"))
	return m

static var _body_cache := {}

# Traffic vehicle node (pooled by TrafficManager)
static func build_traffic(spec: Dictionary, col_hex: String) -> Node3D:
	var v = TrafficVehicle.new()
	v.spec = spec
	var key = String(spec["id"]) + col_hex
	if not _body_cache.has(key):
		_body_cache[key] = body_mesh(spec, hexc(col_hex), {"merge_wheels": true})
	var body = MeshInstance3D.new()
	body.mesh = _body_cache[key]
	v.add_child(body)
	v.body = body
	var lights = {}
	var rear = MeshInstance3D.new()
	rear.mesh = light_mesh(spec, true)
	rear.material_override = mat("tail_run")
	v.add_child(rear)
	v.rear = rear
	var head = MeshInstance3D.new()
	head.mesh = light_mesh(spec, false)
	v.add_child(head)
	v.head = head
	var sl = MeshInstance3D.new()
	sl.mesh = signal_mesh(spec, -1.0)
	v.add_child(sl)
	v.sig_l = sl
	var sr = MeshInstance3D.new()
	sr.mesh = signal_mesh(spec, 1.0)
	v.add_child(sr)
	v.sig_r = sr
	var bm = MeshInstance3D.new()
	bm.mesh = beam_mesh(spec)
	v.add_child(bm)
	v.beam = bm
	sl.visible = false
	sr.visible = false
	bm.visible = false
	return v

# ------------------------------------------------------------------ player car
static func build_player(car_id: String) -> Dictionary:
	var base = GameData.car_by_id(car_id)
	var st = Save.car_state(car_id)
	var Cust = load("res://scripts/game/customization_manager.gd")
	var g = func(k): return Cust.get_idx(st, k)
	var L = float(base["L"])
	var W = float(base["W"])
	var style = String(base["style"])
	var sp = STYLES[style]
	var ride = [0.0, -0.04, 0.06][g.call("suspension")]
	var hb = float(sp["hb"]) + ride
	var ch = float(sp["ch"])
	var col = hexc(String(st["paint"]))
	var tint_a = [0.28, 0.45, 0.62, 0.82][g.call("tint")]
	var spec = base.duplicate()
	var root = Node3D.new()
	var pivot = Node3D.new()
	pivot.position = Vector3(0, 0.5, 0)
	root.add_child(pivot)
	var off = Node3D.new()
	off.position = Vector3(0, -0.5, 0)
	pivot.add_child(off)
	var out = {"root": root, "pivot": pivot, "L": L, "W": W}
	# exterior
	var ext = MeshInstance3D.new()
	var em = body_mesh(spec, col, {"ride": ride, "glass_a": tint_a})
	# extras (parts) as their own surface
	var px = MeshBuf.new()
	var dark = Color(0.07, 0.07, 0.08)
	var zn = -L * 0.5
	var zt = L * 0.5
	var c1 = zn + float(sp["cab1"]) * L
	var rear_y = hb + 0.02
	var spo = g.call("spoiler")
	var sx_w = W * 0.5 - 0.15
	if spo == 1:
		px.box(Vector3(0, rear_y + 0.05, zt - 0.12), Vector3(W * 0.8, 0.06, 0.25), dark)
	elif spo == 2:
		px.box(Vector3(0, rear_y + 0.1, zt - 0.2), Vector3(W * 0.86, 0.08, 0.4), col)
	elif spo >= 3:
		var hh = 0.3 if spo == 3 else 0.42
		var wd = 0.5 if spo == 3 else 0.7
		for sx in [-1.0, 1.0]:
			px.box(Vector3(sx * sx_w * 0.8, rear_y + hh * 0.5, zt - 0.35), Vector3(0.06, hh, 0.25), dark)
		px.box(Vector3(0, rear_y + hh, zt - 0.35), Vector3(W * 0.95, 0.05, wd), dark)
	var fb = g.call("fbumper")
	if fb == 1:
		px.box(Vector3(0, 0.26, zn - 0.04), Vector3(W * 0.96, 0.1, 0.18), dark)
	elif fb == 2:
		px.box(Vector3(0, 0.2, zn - 0.15), Vector3(W * 1.0, 0.05, 0.4), dark)
		for sx in [-1.0, 1.0]:
			px.box(Vector3(sx * W * 0.5, 0.3, zn - 0.05), Vector3(0.04, 0.2, 0.3), dark)
	var rb = g.call("rbumper")
	if rb == 1:
		px.box(Vector3(0, 0.26, zt + 0.04), Vector3(W * 0.96, 0.1, 0.18), dark)
	elif rb == 2:
		px.box(Vector3(0, 0.24, zt + 0.1), Vector3(W * 0.9, 0.08, 0.3), dark)
		for i in range(-3, 4):
			px.box(Vector3(float(i) * W * 0.12, 0.2, zt + 0.12), Vector3(0.03, 0.14, 0.3), dark)
	var ex = g.call("exhaust")
	var chrome = Color(0.75, 0.77, 0.8)
	var ex_pos = [[0.5], [-0.5, 0.5], [-0.6, -0.4, 0.4, 0.6], [0.0]][ex]
	for xe in ex_pos:
		if ex == 3:
			for sx in [-1.0, 1.0]:
				px.box(Vector3(sx * (W * 0.5 + 0.02), 0.28, zn + L * 0.55), Vector3(0.08, 0.1, 0.25), chrome)
		else:
			px.box(Vector3(float(xe) * W * 0.5, 0.26, zt + 0.12), Vector3(0.11, 0.11, 0.2), chrome)
	var mcol = [col, Color(0.05, 0.05, 0.06), chrome, Color(0.13, 0.13, 0.15)][g.call("mirrors")]
	var c0 = zn + float(sp["cab0"]) * L
	for sx in [-1.0, 1.0]:
		px.box(Vector3(sx * (W * 0.5 + 0.1), hb + 0.18, c0 + 0.1), Vector3(0.18, 0.1, 0.1), mcol)
	var dec = g.call("decal")
	if dec > 0:
		var dc = hexc(GameData.DECAL_COLORS[g.call("decal_color")])
		var cabh = hb + ch + 0.02
		if dec == 1 or dec == 3:
			for sx in [-0.14, 0.14]:
				px.quad(Vector3(sx - 0.07, hb + 0.012, zn), Vector3(sx + 0.07, hb + 0.012, zn), Vector3(sx + 0.07, hb + 0.012, c0), Vector3(sx - 0.07, hb + 0.012, c0), dc)
			if dec == 1:
				for sx in [-0.14, 0.14]:
					px.quad(Vector3(sx - 0.07, cabh, c0 + float(sp["rf"])), Vector3(sx + 0.07, cabh, c0 + float(sp["rf"])), Vector3(sx + 0.07, cabh, c1 - float(sp["rr"])), Vector3(sx - 0.07, cabh, c1 - float(sp["rr"])), dc)
		if dec == 2:
			for sx in [-1.0, 1.0]:
				px.quad(Vector3(sx * (W * 0.5 + 0.004), 0.38 + ride, zn), Vector3(sx * (W * 0.5 + 0.004), 0.38 + ride, zt), Vector3(sx * (W * 0.5 + 0.004), 0.5 + ride, zt), Vector3(sx * (W * 0.5 + 0.004), 0.5 + ride, zn), dc)
	# license plates
	px.box(Vector3(0, 0.42, zt + 0.02), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))
	px.box(Vector3(0, 0.42, zn - 0.02), Vector3(0.52, 0.12, 0.02), Color(0.95, 0.95, 0.9))
	px.to_mesh(em, mat("body"))
	ext.mesh = em
	ext.layers = 4
	off.add_child(ext)
	out["ext"] = ext
	var plate = String(st.get("plate", "HWY 001"))
	for side in [1.0, -1.0]:
		var lb = Label3D.new()
		lb.text = plate
		lb.font_size = 40
		lb.pixel_size = 0.0035
		lb.modulate = Color(0.05, 0.05, 0.1)
		lb.position = Vector3(0, 0.42, zt + 0.035) if side > 0.0 else Vector3(0, 0.42, zn - 0.035)
		if side < 0.0:
			lb.rotation.y = PI
		lb.layers = 4
		off.add_child(lb)
	# lights (exterior)
	var tl_i = g.call("taillight")
	var rear_mi = MeshInstance3D.new()
	rear_mi.mesh = light_mesh(spec, true, ride)
	rear_mi.layers = 4
	off.add_child(rear_mi)
	var head_mi = MeshInstance3D.new()
	head_mi.mesh = light_mesh(spec, false, ride)
	var hcols = ["#fff0cc", "#e8f2ff", "#bcd2ff", "#ffbb55"]
	var hm = StandardMaterial3D.new()
	hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	hm.albedo_color = hexc(hcols[g.call("headlight")])
	head_mi.material_override = hm
	head_mi.layers = 4
	off.add_child(head_mi)
	out["rear_mi"] = rear_mi
	out["tail_style"] = tl_i
	out["head_col"] = hexc(hcols[g.call("headlight")])
	# wheels
	var wsize = g.call("wheel_size")
	var tr = 0.31 + 0.012 * float(wsize)
	var rimr = tr * (0.58 + 0.03 * float(wsize))
	var wcol = hexc(GameData.WHEEL_COLORS[g.call("wheel_color")])
	var wstyle = g.call("wheel_style")
	var wmesh = ArrayMesh.new()
	var wb = MeshBuf.new()
	wb.cyl_x(Vector3.ZERO, tr, 0.24, 14, Color(0.04, 0.04, 0.05))
	wb.cyl_x(Vector3(0.0, 0, 0), rimr, 0.25, 12, wcol)
	var nsp = [0, 5, 10, 7][wstyle]
	for i in nsp:
		var a = TAU * float(i) / float(maxi(nsp, 1))
		wb.box_b(Vector3(0.125, sin(a) * rimr * 0.5, cos(a) * rimr * 0.5), Vector3(0.02, rimr * 0.08 + 0.02, rimr * 0.95), Basis(Vector3.RIGHT, -a + PI * 0.5), Color(0.1, 0.1, 0.11))
	wb.cyl_x(Vector3(0.126, 0, 0), rimr * 0.2, 0.02, 8, wcol.darkened(0.3))
	wb.to_mesh(wmesh, mat("wheel"))
	var wbz = float(base["wb"]) * 0.5
	var track = W * 0.5 - 0.13
	var spins = []
	var fronts = []
	for iz in [-1.0, 1.0]:
		for sx in [-1.0, 1.0]:
			var piv = Node3D.new()
			piv.position = Vector3(sx * track, tr, iz * wbz)
			off.add_child(piv)
			var wm = MeshInstance3D.new()
			wm.mesh = wmesh
			if sx < 0.0:
				wm.rotation.y = PI
			wm.layers = 4
			piv.add_child(wm)
			spins.append(wm)
			if iz < 0.0:
				fronts.append(piv)
	out["spins"] = spins
	out["fronts"] = fronts
	out["wheel_r"] = tr
	# headlight spots
	var spots = []
	for sx in [-1.0, 1.0]:
		var sl = SpotLight3D.new()
		sl.position = Vector3(sx * W * 0.35, hb - 0.1, zn + 0.1)
		sl.rotation_degrees = Vector3(-3, 0, 0)
		sl.spot_range = 75.0
		sl.spot_angle = 30.0
		sl.spot_attenuation = 0.8
		sl.light_energy = 0.0
		sl.light_color = hexc(hcols[g.call("headlight")])
		off.add_child(sl)
		spots.append(sl)
	out["spots"] = spots
	# ---------------- interior (layer 2) ------------------
	var icol = hexc(GameData.INTERIOR_COLORS[g.call("interior")])
	var ib = MeshBuf.new()
	var ex_ = -0.36 * (W / 1.75)
	var cz0 = c0
	var cab_top = hb + ch
	# dash
	ib.box(Vector3(0, hb + 0.05, cz0 + 0.3), Vector3(W - 0.15, 0.2, 0.55), icol)
	ib.box(Vector3(ex_, hb + 0.2, cz0 + 0.5), Vector3(0.7, 0.12, 0.22), icol.darkened(0.3))
	# hood visible through windshield
	ib.box(Vector3(0, hb - 0.02, (zn + cz0) * 0.5 - 0.1), Vector3(W * 0.98, 0.06, (cz0 - zn) - 0.1), col)
	# pillars + header + liner + doors
	var hwb = W * 0.5 - 0.07
	var hwt = W * 0.5 - 0.2
	var rf = float(sp["rf"])
	for sx in [-1.0, 1.0]:
		ib.beam(Vector3(sx * hwb, hb, c0), Vector3(sx * hwt, cab_top, c0 + rf), 0.07, icol.darkened(0.2))
		ib.box(Vector3(sx * (W * 0.5 - 0.06), hb - 0.1, (c0 + c1) * 0.5), Vector3(0.08, 0.5, c1 - c0), icol)
		ib.beam(Vector3(sx * hwb, hb, c1 - 0.2), Vector3(sx * hwt, cab_top, c1 - float(sp["rr"])), 0.08, icol.darkened(0.2))
	ib.beam(Vector3(-hwt, cab_top, c0 + rf), Vector3(hwt, cab_top, c0 + rf), 0.07, icol.darkened(0.2))
	ib.quad(Vector3(-hwt, cab_top - 0.02, c0 + rf), Vector3(hwt, cab_top - 0.02, c0 + rf), Vector3(hwt, cab_top - 0.02, c1 - float(sp["rr"])), Vector3(-hwt, cab_top - 0.02, c1 - float(sp["rr"])), icol.darkened(0.15))
	ib.box(Vector3(0, hb - 0.12, (c0 + c1) * 0.5 + 0.2), Vector3(W - 0.2, 0.04, c1 - c0), icol.darkened(0.25))
	var im = ArrayMesh.new()
	ib.to_mesh(im, mat("interior"))
	var imi = MeshInstance3D.new()
	imi.mesh = im
	imi.layers = 2
	off.add_child(imi)
	# windshield tint overlay
	var tm = ArrayMesh.new()
	var tb = MeshBuf.new()
	var ta = [0.0, 0.08, 0.16, 0.28][g.call("tint")]
	if ta > 0.0:
		var tc = Color(0, 0, 0, ta)
		tb.quad(Vector3(-hwb, hb, c0 - 0.02), Vector3(hwb, hb, c0 - 0.02), Vector3(hwt, cab_top, c0 + rf - 0.02), Vector3(-hwt, cab_top, c0 + rf - 0.02), tc)
		tb.to_mesh(tm, mat("glass"))
		var tmi = MeshInstance3D.new()
		tmi.mesh = tm
		tmi.layers = 2
		off.add_child(tmi)
	# steering wheel
	var sw = Node3D.new()
	sw.position = Vector3(ex_, hb + 0.2, cz0 + 0.62)
	sw.rotation_degrees = Vector3(-22, 0, 0)
	off.add_child(sw)
	var swr = Node3D.new()
	sw.add_child(swr)
	var tor = MeshInstance3D.new()
	var tmesh = TorusMesh.new()
	tmesh.inner_radius = 0.16
	tmesh.outer_radius = 0.19
	tmesh.rings = 20
	tmesh.ring_segments = 8
	tor.mesh = tmesh
	tor.rotation_degrees = Vector3(90, 0, 0)
	var swm = StandardMaterial3D.new()
	swm.albedo_color = Color(0.06, 0.06, 0.07)
	swm.roughness = 0.5
	tor.material_override = swm
	tor.layers = 2
	swr.add_child(tor)
	for a in [0.0, 2.1, 4.2]:
		var sp_ = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.025, 0.17, 0.02)
		sp_.mesh = bm
		sp_.material_override = swm
		sp_.rotation.z = a
		sp_.position = Vector3(-sin(a) * 0.085, cos(a) * 0.085, 0)
		sp_.layers = 2
		swr.add_child(sp_)
	out["steer_wheel"] = swr
	# gauges
	var spl = Label3D.new()
	spl.text = "0"
	spl.font_size = 64
	spl.pixel_size = 0.0014
	spl.modulate = Color(0.7, 1.0, 0.8)
	spl.position = Vector3(ex_, hb + 0.3, cz0 + 0.4)
	spl.rotation_degrees = Vector3(-30, 0, 0)
	spl.layers = 2
	spl.no_depth_test = false
	off.add_child(spl)
	out["speed_label"] = spl
	var gl_ = Label3D.new()
	gl_.text = "1"
	gl_.font_size = 48
	gl_.pixel_size = 0.0012
	gl_.modulate = Color(1.0, 0.7, 0.2)
	gl_.position = Vector3(ex_ + 0.2, hb + 0.3, cz0 + 0.4)
	gl_.rotation_degrees = Vector3(-30, 0, 0)
	gl_.layers = 2
	off.add_child(gl_)
	out["gear_label"] = gl_
	# rear-view mirror quad (texture assigned by camera controller)
	var mq = MeshInstance3D.new()
	var qm = QuadMesh.new()
	qm.size = Vector2(0.3, 0.09)
	mq.mesh = qm
	mq.position = Vector3(0, cab_top - 0.1, c0 + rf + 0.12)
	mq.rotation_degrees = Vector3(-8, 0, 0)
	mq.layers = 2
	mq.visible = false
	off.add_child(mq)
	out["mirror_quad"] = mq
	out["eye"] = Vector3(ex_, hb + 0.36, cz0 + 0.95)
	out["rear_cam_pos"] = Vector3(0, hb + 0.6, zt - 0.2)
	out["off"] = off
	out["hb"] = hb
	return out
