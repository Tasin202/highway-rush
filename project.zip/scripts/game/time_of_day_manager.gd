extends Node3D
## Sun/moon, sky, ambient, fog. Presets for morning/afternoon/evening/night + weather modifiers.

const PRESETS := [
	{"elev": 16.0, "az": 100.0, "col": Color(1.0, 0.82, 0.65), "en": 1.1, "amb": Color(0.55, 0.6, 0.75), "aen": 0.8, "top": Color(0.35, 0.55, 0.85), "hor": Color(0.95, 0.8, 0.65), "fog": Color(0.85, 0.78, 0.72), "dark": 0.0},
	{"elev": 55.0, "az": 140.0, "col": Color(1.0, 0.97, 0.9), "en": 1.3, "amb": Color(0.6, 0.68, 0.85), "aen": 0.95, "top": Color(0.25, 0.5, 0.9), "hor": Color(0.75, 0.85, 0.95), "fog": Color(0.75, 0.84, 0.92), "dark": 0.0},
	{"elev": 5.0, "az": 250.0, "col": Color(1.0, 0.55, 0.25), "en": 1.0, "amb": Color(0.5, 0.45, 0.6), "aen": 0.65, "top": Color(0.2, 0.25, 0.5), "hor": Color(1.0, 0.55, 0.3), "fog": Color(0.9, 0.6, 0.45), "dark": 0.4},
	{"elev": 38.0, "az": 200.0, "col": Color(0.45, 0.55, 0.85), "en": 0.3, "amb": Color(0.12, 0.15, 0.3), "aen": 0.9, "top": Color(0.01, 0.02, 0.07), "hor": Color(0.04, 0.06, 0.14), "fog": Color(0.03, 0.05, 0.1), "dark": 1.0},
]

var env: Environment
var sun: DirectionalLight3D
var sky_mat: ProceduralSkyMaterial
var preset: Dictionary = {}
var weather := 0
var base_energy := 1.0
var base_amb := 1.0
var tunnel_f := 0.0
var dark := 0.0
var fog_col := Color.WHITE
var road
var q: Dictionary = {}

func setup(parent: Node, cam: Camera3D, r, cfg: Dictionary) -> void:
	road = r
	q = cfg["q"]
	weather = cfg["weather"]
	preset = PRESETS[cfg["tod"]]
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_sky_affect = 0.35
	sun = DirectionalLight3D.new()
	add_child(sun)
	sun.rotation_degrees = Vector3(-float(preset["elev"]), float(preset["az"]), 0.0)
	var shadow_q = int(q["shadow"])
	sun.shadow_enabled = shadow_q > 0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = [0.0, 60.0, 100.0, 150.0][shadow_q]
	sun.shadow_bias = 0.08
	sun.shadow_normal_bias = 1.0
	var sc = Color(preset["col"])
	var top = Color(preset["top"])
	var hor = Color(preset["hor"])
	var fog = Color(preset["fog"])
	var amb = Color(preset["amb"])
	base_energy = float(preset["en"])
	base_amb = float(preset["aen"])
	dark = float(preset["dark"])
	var fog_mult = 1.0
	var sun_mult = 1.0
	var gray_t = 0.0
	if weather == 1:
		sun_mult = 0.6
		fog_mult = 1.4
		gray_t = 0.45
	elif weather == 2:
		sun_mult = 0.3
		fog_mult = 2.0
		gray_t = 0.75
		dark = minf(1.0, dark + 0.2)
	var g = func(c: Color) -> Color:
		var l = c.get_luminance()
		return c.lerp(Color(l, l, l) * (0.85 if weather == 2 else 1.0), gray_t)
	top = g.call(top)
	hor = g.call(hor)
	fog = g.call(fog)
	amb = g.call(amb)
	sc = g.call(sc)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = hor.darkened(0.3)
	sky_mat.sun_angle_max = 25.0 if weather == 0 else 5.0
	env.ambient_light_color = amb
	sun.light_color = sc
	base_energy *= sun_mult
	sun.light_energy = base_energy
	env.ambient_light_energy = base_amb
	fog_col = fog
	env.fog_light_color = fog
	var rd = float(q["render"])
	env.fog_density = 2.9 / rd * fog_mult
	cam.environment = env
	road.set_darkness(dark)
	road.set_haze(fog)
	parent.add_child(self)

func update(dt: float, in_tunnel: bool) -> void:
	tunnel_f = move_toward(tunnel_f, 1.0 if in_tunnel else 0.0, dt * 2.5)
	sun.light_energy = base_energy * (1.0 - 0.95 * tunnel_f)
	env.ambient_light_energy = lerpf(base_amb, maxf(base_amb, 0.55), tunnel_f)
	env.fog_light_color = fog_col.lerp(Color(0.05, 0.05, 0.06), tunnel_f)
	road.set_darkness(maxf(dark, tunnel_f))

func effective_dark() -> float:
	return maxf(dark, tunnel_f)
