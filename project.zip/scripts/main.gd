extends Node
## Entry point: showroom + UI. GM (autoload) runs the driving sessions.

const Garage = preload("res://scripts/game/garage_manager.gd")
const UIM = preload("res://scripts/ui/ui_manager.gd")

var showroom
var ui

func _ready() -> void:
	GM.main = self
	showroom = Garage.new()
	add_child(showroom)
	ui = UIM.new()
	add_child(ui)
	GM.ui = ui
	ui.show_screen("menu")

func _unhandled_input(event: InputEvent) -> void:
	if GM.state != "menu" or not showroom.visible:
		return
	if event is InputEventScreenDrag:
		showroom.spin += event.relative.x * 0.01
