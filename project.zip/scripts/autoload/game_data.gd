extends Node
## Static data tables and small helpers (autoload: GameData)

const STEP := 4.0
const GRAV := 9.81
const PALETTE := ["#e9e9e9", "#1d1d1f", "#9aa0a6", "#b02a2a", "#2a4d9b", "#3f7f55", "#c7a640", "#6b4b2a", "#7a7f86", "#d26a1e", "#7b3fa0", "#17a2b8"]
const DIFF_NAMES := ["Easy", "Normal", "Hard", "Extreme"]
const MODE_NAMES := ["Endless", "Time Attack", "Free Drive"]
const TIME_LIMITS := [60, 180, 300, 600, 1200]
const TOD_NAMES := ["Morning", "Afternoon", "Evening", "Night", "Random"]
const WEATHER_NAMES := ["Clear", "Cloudy", "Rain", "Random"]
const RENDER_DISTS := [300.0, 450.0, 650.0, 900.0]
const TRAFFIC_GFX := [0.5, 0.75, 1.0]
const QUALITY_NAMES := ["Low", "Medium", "High", "Ultra"]

var CARS = [
	{"id": "compact", "name": "Compact C1", "price": 0, "style": "hatch", "top": 165.0, "accel": 3.3, "brake": 8.4, "steer": 0.9, "weight": 1050.0, "grip": 0.95, "L": 3.9, "W": 1.72, "H": 1.5, "wb": 2.5, "cyl": 4.0, "idle": 900.0, "red": 6500.0, "color": "#c9ced6"},
	{"id": "metro", "name": "Metro Sedan", "price": 6000, "style": "sedan", "top": 185.0, "accel": 3.7, "brake": 8.8, "steer": 0.95, "weight": 1300.0, "grip": 0.98, "L": 4.6, "W": 1.8, "H": 1.45, "wb": 2.7, "cyl": 4.0, "idle": 850.0, "red": 6500.0, "color": "#2a4d9b"},
	{"id": "urbangt", "name": "Urban GT", "price": 14000, "style": "hatch", "top": 215.0, "accel": 5.0, "brake": 9.8, "steer": 1.1, "weight": 1250.0, "grip": 1.06, "L": 4.0, "W": 1.78, "H": 1.45, "wb": 2.55, "cyl": 4.0, "idle": 950.0, "red": 7200.0, "color": "#b02a2a"},
	{"id": "suv", "name": "Trail SUV", "price": 18000, "style": "suv", "top": 195.0, "accel": 3.9, "brake": 8.7, "steer": 0.85, "weight": 1850.0, "grip": 0.97, "L": 4.7, "W": 1.92, "H": 1.7, "wb": 2.8, "cyl": 6.0, "idle": 800.0, "red": 6000.0, "color": "#3f7f55"},
	{"id": "pickup", "name": "Ranger Pickup", "price": 22000, "style": "pickup", "top": 190.0, "accel": 3.6, "brake": 8.3, "steer": 0.8, "weight": 2050.0, "grip": 0.94, "L": 5.4, "W": 1.95, "H": 1.8, "wb": 3.2, "cyl": 6.0, "idle": 780.0, "red": 5800.0, "color": "#6b4b2a"},
	{"id": "coupe", "name": "Apex Coupe", "price": 45000, "style": "sport", "top": 255.0, "accel": 6.2, "brake": 10.5, "steer": 1.2, "weight": 1450.0, "grip": 1.12, "L": 4.5, "W": 1.86, "H": 1.3, "wb": 2.65, "cyl": 6.0, "idle": 950.0, "red": 7500.0, "color": "#d26a1e"},
	{"id": "gt", "name": "Grand Tourer", "price": 85000, "style": "sport", "top": 285.0, "accel": 6.9, "brake": 10.8, "steer": 1.15, "weight": 1700.0, "grip": 1.15, "L": 4.8, "W": 1.92, "H": 1.32, "wb": 2.8, "cyl": 8.0, "idle": 850.0, "red": 7000.0, "color": "#1d1d1f"},
	{"id": "hyper", "name": "Hyper X", "price": 180000, "style": "sport", "top": 335.0, "accel": 8.8, "brake": 12.0, "steer": 1.3, "weight": 1380.0, "grip": 1.25, "L": 4.5, "W": 2.0, "H": 1.15, "wb": 2.7, "cyl": 10.0, "idle": 1000.0, "red": 9000.0, "color": "#e9e9e9"},
]

var TRAFFIC = [
	{"id": "sedan", "style": "sedan", "L": 4.6, "W": 1.8, "H": 1.45, "vmin": 95.0, "vmax": 130.0, "accel": 2.6, "brake": 7.5, "weight": 1450.0, "p": 20.0},
	{"id": "hatch", "style": "hatch", "L": 3.9, "W": 1.74, "H": 1.5, "vmin": 90.0, "vmax": 125.0, "accel": 2.5, "brake": 7.5, "weight": 1150.0, "p": 14.0},
	{"id": "suv", "style": "suv", "L": 4.7, "W": 1.9, "H": 1.75, "vmin": 90.0, "vmax": 125.0, "accel": 2.4, "brake": 7.2, "weight": 1900.0, "p": 14.0},
	{"id": "pickup", "style": "pickup", "L": 5.3, "W": 1.95, "H": 1.8, "vmin": 85.0, "vmax": 115.0, "accel": 2.2, "brake": 7.0, "weight": 2100.0, "p": 8.0},
	{"id": "van", "style": "van", "L": 5.2, "W": 1.95, "H": 2.2, "vmin": 80.0, "vmax": 110.0, "accel": 2.0, "brake": 6.8, "weight": 2400.0, "p": 6.0},
	{"id": "truck", "style": "truck", "L": 9.5, "W": 2.5, "H": 3.4, "vmin": 70.0, "vmax": 90.0, "accel": 1.0, "brake": 5.5, "weight": 9000.0, "p": 7.0},
	{"id": "bus", "style": "bus", "L": 11.5, "W": 2.55, "H": 3.1, "vmin": 65.0, "vmax": 90.0, "accel": 1.1, "brake": 6.0, "weight": 11000.0, "p": 3.0},
	{"id": "taxi", "style": "sedan", "L": 4.6, "W": 1.8, "H": 1.45, "vmin": 80.0, "vmax": 110.0, "accel": 2.6, "brake": 7.5, "weight": 1450.0, "p": 6.0, "color": "#f2c200"},
	{"id": "sports", "style": "sport", "L": 4.4, "W": 1.9, "H": 1.28, "vmin": 120.0, "vmax": 170.0, "accel": 5.0, "brake": 10.0, "weight": 1500.0, "p": 4.0},
	{"id": "economy", "style": "hatch", "L": 3.7, "W": 1.65, "H": 1.5, "vmin": 80.0, "vmax": 110.0, "accel": 2.2, "brake": 7.2, "weight": 950.0, "p": 10.0},
]

# grade = hill steepness multiplier, hills = terrain amplitude (m), tunnel = tunnel weight
var MAPS = [
	{"id": "city", "name": "City Highway", "scenery": "city", "dens": 1.25, "curve": 0.5, "grade": 0.3, "hills": 0.0, "tunnel": 0.12, "lamps": true, "speed": 0.9, "force_tod": -1,
		"ground": "#5a5f58", "ground2": "#666b62", "rock": "#777777", "snow": "#ffffff"},
	{"id": "country", "name": "Countryside", "scenery": "country", "dens": 0.55, "curve": 0.8, "grade": 1.0, "hills": 12.0, "tunnel": 0.0, "lamps": false, "speed": 1.0, "force_tod": -1,
		"ground": "#5d8a3c", "ground2": "#9aa845", "rock": "#7d7a74", "snow": "#ffffff"},
	{"id": "mountain", "name": "Mountain", "scenery": "mountain", "dens": 0.5, "curve": 1.5, "grade": 2.5, "hills": 80.0, "tunnel": 0.25, "lamps": false, "speed": 0.9, "force_tod": -1,
		"ground": "#46683a", "ground2": "#58704a", "rock": "#7d7a74", "snow": "#f0f3f7"},
	{"id": "desert", "name": "Desert", "scenery": "desert", "dens": 0.35, "curve": 0.35, "grade": 0.6, "hills": 9.0, "tunnel": 0.0, "lamps": false, "speed": 1.1, "force_tod": -1,
		"ground": "#d2b074", "ground2": "#c49a5a", "rock": "#a8744a", "snow": "#d8b57c"},
	{"id": "coastal", "name": "Coastal", "scenery": "coastal", "dens": 0.7, "curve": 0.9, "grade": 1.2, "hills": 24.0, "tunnel": 0.08, "lamps": true, "speed": 1.0, "force_tod": -1,
		"ground": "#6a9a4a", "ground2": "#e1d3a0", "rock": "#8a8a84", "snow": "#ffffff"},
	{"id": "nightcity", "name": "Night City", "scenery": "city", "dens": 1.2, "curve": 0.5, "grade": 0.3, "hills": 0.0, "tunnel": 0.12, "lamps": true, "speed": 0.9, "force_tod": 3,
		"ground": "#50545a", "ground2": "#5a5e66", "rock": "#777777", "snow": "#ffffff"},
]

# Customisation categories: key, label, tab, option names, prices
var CUSTOM = [
	{"key": "wheel_style", "label": "Wheel style", "tab": 1, "names": ["Steel", "Sport 5", "Mesh", "Turbine"], "prices": [0, 300, 600, 900], "def": 0},
	{"key": "wheel_color", "label": "Wheel color", "tab": 1, "names": ["Silver", "Black", "Gold", "White", "Bronze"], "prices": [0, 100, 150, 100, 150], "def": 0},
	{"key": "wheel_size", "label": "Wheel size", "tab": 1, "names": ["16\"", "17\"", "18\"", "19\"", "20\""], "prices": [0, 200, 350, 500, 700], "def": 0},
	{"key": "tire", "label": "Tires", "tab": 1, "names": ["Eco", "Street", "All-Season", "Sport", "Racing"], "prices": [0, 0, 150, 500, 1200], "def": 1},
	{"key": "tint", "label": "Window tint", "tab": 2, "names": ["None", "Light", "Medium", "Dark"], "prices": [0, 0, 150, 200], "def": 1},
	{"key": "spoiler", "label": "Spoiler", "tab": 2, "names": ["None", "Lip", "Ducktail", "GT wing", "Race wing"], "prices": [0, 250, 400, 800, 1500], "def": 0},
	{"key": "fbumper", "label": "Front bumper", "tab": 2, "names": ["Stock", "Sport", "Splitter"], "prices": [0, 350, 700], "def": 0},
	{"key": "rbumper", "label": "Rear bumper", "tab": 2, "names": ["Stock", "Sport", "Diffuser"], "prices": [0, 350, 700], "def": 0},
	{"key": "mirrors", "label": "Mirrors", "tab": 2, "names": ["Body", "Black", "Chrome", "Carbon"], "prices": [0, 100, 200, 300], "def": 0},
	{"key": "exhaust", "label": "Exhaust", "tab": 2, "names": ["Stock", "Dual", "Quad", "Side exit"], "prices": [0, 250, 500, 400], "def": 0},
	{"key": "headlight", "label": "Headlights", "tab": 3, "names": ["Halogen", "LED", "Xenon", "Amber"], "prices": [0, 300, 500, 200], "def": 0},
	{"key": "taillight", "label": "Taillights", "tab": 3, "names": ["Stock", "Smoked", "LED bar", "Clear"], "prices": [0, 200, 350, 250], "def": 0},
	{"key": "suspension", "label": "Ride height", "tab": 4, "names": ["Stock", "Lowered", "Raised"], "prices": [0, 400, 400], "def": 0},
	{"key": "interior", "label": "Interior color", "tab": 4, "names": ["Black", "Gray", "Tan", "Red", "Blue"], "prices": [0, 100, 150, 200, 200], "def": 0},
	{"key": "decal", "label": "Decals", "tab": 4, "names": ["None", "Racing stripes", "Side stripe", "Hood stripe"], "prices": [0, 300, 200, 200], "def": 0},
	{"key": "decal_color", "label": "Decal color", "tab": 4, "names": ["White", "Black", "Red", "Blue", "Yellow"], "prices": [0, 0, 0, 0, 0], "def": 0},
]
const TAB_NAMES := ["Paint", "Wheels", "Body", "Lights", "Extras", "Upgrades"]
const TIRE_GRIP := [0.95, 1.0, 1.0, 1.12, 1.22]
const TIRE_WET := [1.0, 1.0, 1.1, 1.0, 0.85]
const UPGRADES := [
	{"key": "engine", "name": "Engine", "desc": "+acceleration, +top speed"},
	{"key": "transmission", "name": "Transmission", "desc": "+acceleration, faster shifts"},
	{"key": "brakes", "name": "Brakes", "desc": "shorter braking distance"},
	{"key": "tires", "name": "Tire compound", "desc": "+grip"},
	{"key": "suspension", "name": "Suspension", "desc": "+handling, +steering response"},
]
const WHEEL_COLORS := ["#c8ccd2", "#1a1a1c", "#c9a227", "#f2f2f2", "#9a6a3a"]
const INTERIOR_COLORS := ["#1c1c1e", "#5c5e63", "#8a6a45", "#7a1f1f", "#1f3a6e"]
const DECAL_COLORS := ["#f2f2f2", "#111111", "#c21f1f", "#1f4fc2", "#f0c800"]

func car_by_id(id: String) -> Dictionary:
	for c in CARS:
		if c["id"] == id:
			return c
	return CARS[0]

func fmt_money(v) -> String:
	var n = int(v)
	var s = str(absi(n))
	var out = ""
	var cnt = 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return ("-$" if n < 0 else "$") + out

func speed_val(mps: float) -> float:
	return mps * 3.6 if Save.si("units") == 0 else mps * 2.23694

func speed_unit() -> String:
	return "km/h" if Save.si("units") == 0 else "mph"

func fmt_dist(m: float) -> String:
	if Save.si("units") == 0:
		return "%.2f km" % (m / 1000.0)
	return "%.2f mi" % (m / 1609.34)

func fmt_time(t: float) -> String:
	var s = int(t)
	return "%d:%02d" % [s / 60, s % 60]
