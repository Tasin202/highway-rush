extends Node
## Local persistence (autoload: Save). Everything lives in user://highway_save.json

const PATH := "user://highway_save.json"
var data := {}
var _dirty := false
var _t := 0.0

func _ready() -> void:
	load_data()

func default_data() -> Dictionary:
	return {
		"money": 0,
		"current_car": "compact",
		"cars": {},
		"stats": {"total_dist": 0.0, "best_dist": 0.0, "top_speed": 0.0, "total_time": 0.0, "money_total": 0.0,
			"overtakes": 0, "near_misses": 0, "collisions": 0, "best_streak": 0.0},
		"best_ta": {},
		"settings": {
			"quality": 1, "shadow": 1, "traffic_gfx": 1, "render": 1, "fx": 1, "fps": 60,
			"steer_mode": 0, "steer_sens": 1.0, "gyro_sens": 1.0, "gyro_invert": false, "gyro_cal": 0.0,
			"layout": 0, "cam_dist": 1.0, "cam_sens": 1.0, "units": 0, "vol_sfx": 0.8, "vol_music": 0.5,
			"music_on": true, "vibration": true, "weather_fx": true, "damage": 1, "pov": 0,
		},
		"setup": {"mode": 0, "tl": 1, "map": 0, "tod": 1, "weather": 0, "road": 0, "diff": 1, "density": 0.6},
	}

func _merge(dst: Dictionary, src: Dictionary) -> void:
	for k in src.keys():
		if dst.has(k) and typeof(dst[k]) == TYPE_DICTIONARY and typeof(src[k]) == TYPE_DICTIONARY:
			_merge(dst[k], src[k])
		else:
			dst[k] = src[k]

func load_data() -> void:
	data = default_data()
	if FileAccess.file_exists(PATH):
		var f = FileAccess.open(PATH, FileAccess.READ)
		if f != null:
			var parsed = JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_DICTIONARY:
				_merge(data, parsed)
	var c = car_state("compact")
	c["owned"] = true

func save_now() -> void:
	var f = FileAccess.open(PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))
	_dirty = false

func mark() -> void:
	_dirty = true

func _process(dt: float) -> void:
	if _dirty:
		_t += dt
		if _t > 2.0:
			_t = 0.0
			save_now()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_now()

# ---- accessors
func si(key: String) -> int:
	return int(data["settings"].get(key, 0))
func sf(key: String) -> float:
	return float(data["settings"].get(key, 0.0))
func sb(key: String) -> bool:
	return bool(data["settings"].get(key, false))
func set_s(key: String, v) -> void:
	data["settings"][key] = v
	mark()
func su(key: String) -> int:
	return int(data["setup"].get(key, 0))
func set_u(key: String, v) -> void:
	data["setup"][key] = v
	mark()

func money() -> int:
	return int(data["money"])
func add_money(v: float) -> void:
	data["money"] = int(data["money"]) + int(v)
	mark()
func spend(v: int) -> bool:
	if money() >= v:
		data["money"] = money() - v
		mark()
		return true
	return false

func car_state(id: String) -> Dictionary:
	if not data["cars"].has(id):
		var base = GameData.car_by_id(id)
		data["cars"][id] = {"owned": false, "paint": base["color"], "c": {}, "own": {}, "up": {}, "plate": "HWY 001"}
	return data["cars"][id]

func owned(id: String) -> bool:
	return bool(car_state(id)["owned"])

func owned_ids() -> Array:
	var out = []
	for c in GameData.CARS:
		if owned(c["id"]):
			out.append(c["id"])
	return out

func stat(k: String) -> float:
	return float(data["stats"].get(k, 0.0))
func stat_add(k: String, v: float) -> void:
	data["stats"][k] = float(data["stats"].get(k, 0.0)) + v
	mark()
func stat_max(k: String, v: float) -> void:
	if v > float(data["stats"].get(k, 0.0)):
		data["stats"][k] = v
		mark()
