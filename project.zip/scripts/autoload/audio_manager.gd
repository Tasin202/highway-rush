extends Node
## Procedural audio (autoload: Sfx). No audio files needed: everything is synthesised at runtime.

const MIX := 22050.0
const MUSIC_MIX := 11025

var sounds := {}
var pool: Array = []
var pool_i := 0
var gen_player: AudioStreamPlayer
var pb: AudioStreamGeneratorPlayback
var driving := false
var muted := false
var music_player: AudioStreamPlayer
var music_stream: AudioStreamWAV
var thread: Thread
# synth state
var ph := 0.0
var ph2 := 0.0
var ph_s := 0.0
var lp_e := 0.0
var lp_w := 0.0
var lp_t := 0.0
var p_rpm := 0.0
var p_thr := 0.0
var p_speed := 0.0
var p_slip := 0.0
var p_rain := false
var p_off := false
var p_brk := 0.0
var s_rpm := 0.0
var s_thr := 0.0
var cyl := 4.0
var idle := 900.0
var red := 6500.0
var ex_idx := 0

func _ready() -> void:
	for n in ["SFX", "Music"]:
		var i = AudioServer.bus_count
		AudioServer.add_bus(i)
		AudioServer.set_bus_name(i, n)
		AudioServer.set_bus_send(i, "Master")
	for i in 10:
		var p = AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		pool.append(p)
	_build_sounds()
	gen_player = AudioStreamPlayer.new()
	gen_player.bus = "SFX"
	var g = AudioStreamGenerator.new()
	g.mix_rate = MIX
	g.buffer_length = 0.12
	gen_player.stream = g
	add_child(gen_player)
	music_player = AudioStreamPlayer.new()
	music_player.bus = "Music"
	music_player.volume_db = -4.0
	add_child(music_player)
	apply_volumes()
	thread = Thread.new()
	thread.start(_gen_music)

func _exit_tree() -> void:
	if thread != null and thread.is_started():
		thread.wait_to_finish()

func apply_volumes() -> void:
	var si = AudioServer.get_bus_index("SFX")
	var mi = AudioServer.get_bus_index("Music")
	AudioServer.set_bus_volume_db(si, linear_to_db(maxf(Save.sf("vol_sfx"), 0.0001)))
	AudioServer.set_bus_volume_db(mi, linear_to_db(maxf(Save.sf("vol_music"), 0.0001)))
	AudioServer.set_bus_mute(mi, not Save.sb("music_on"))

func play(name: String, db: float = 0.0, pitch: float = 1.0) -> void:
	if not sounds.has(name):
		return
	var p: AudioStreamPlayer = pool[pool_i]
	pool_i = (pool_i + 1) % pool.size()
	p.stream = sounds[name]
	p.volume_db = db
	p.pitch_scale = pitch
	p.play()

# ------------------------------------------------------------ sound design
func _wav(data: PackedFloat32Array, rate: int = 22050, loop: bool = false) -> AudioStreamWAV:
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	var bytes = PackedByteArray()
	bytes.resize(data.size() * 2)
	for i in data.size():
		bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 32000.0))
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = data.size()
	return w

func _tone(freqs: Array, dur: float, decay: float, amp: float = 0.5) -> PackedFloat32Array:
	var n = int(dur * MIX)
	var d = PackedFloat32Array()
	d.resize(n)
	for i in n:
		var t = float(i) / MIX
		var s = 0.0
		for f in freqs:
			s += sin(TAU * float(f) * t)
		d[i] = s / float(freqs.size()) * exp(-t * decay) * amp
	return d

func _concat(a: PackedFloat32Array, b: PackedFloat32Array) -> PackedFloat32Array:
	var o = PackedFloat32Array()
	o.append_array(a)
	o.append_array(b)
	return o

func _build_sounds() -> void:
	sounds["click"] = _wav(_tone([1200.0], 0.05, 60.0, 0.4))
	sounds["confirm"] = _wav(_concat(_tone([660.0], 0.08, 25.0), _tone([880.0], 0.12, 20.0)))
	var arp = PackedFloat32Array()
	for f in [523.0, 659.0, 784.0, 1047.0]:
		arp = _concat(arp, _tone([f], 0.09, 18.0))
	sounds["buy"] = _wav(arp)
	var err = PackedFloat32Array()
	err.resize(int(0.2 * MIX))
	for i in err.size():
		var t = float(i) / MIX
		err[i] = (1.0 if fmod(t * 150.0, 1.0) < 0.5 else -1.0) * 0.25 * exp(-t * 8.0)
	sounds["error"] = _wav(err)
	sounds["ding"] = _wav(_tone([1318.0, 1975.0], 0.45, 9.0, 0.5))
	# crash
	var n = int(0.9 * MIX)
	var cr = PackedFloat32Array()
	cr.resize(n)
	var lp = 0.0
	for i in n:
		var t = float(i) / MIX
		lp += (randf() * 2.0 - 1.0 - lp) * 0.35
		cr[i] = lp * exp(-t * 4.5) * 0.9 + sin(TAU * 55.0 * t) * exp(-t * 7.0) * 0.7 + sin(TAU * (240.0 - 100.0 * t) * t) * exp(-t * 10.0) * 0.25
	sounds["crash"] = _wav(cr)
	var n2 = int(0.45 * MIX)
	var sc = PackedFloat32Array()
	sc.resize(n2)
	var l2 = 0.0
	for i in n2:
		var t = float(i) / MIX
		var nz = randf() * 2.0 - 1.0
		l2 += (nz - l2) * 0.5
		sc[i] = (nz - l2) * exp(-t * 6.0) * 0.6
	sounds["scrape"] = _wav(sc)
	var n3 = int(0.7 * MIX)
	var hn = PackedFloat32Array()
	hn.resize(n3)
	for i in n3:
		var t = float(i) / MIX
		var e = smoothstep(0.0, 0.03, t) * (1.0 - smoothstep(0.55, 0.7, t))
		var s = sin(TAU * 392.0 * t) + sin(TAU * 494.0 * t) + 0.4 * sin(TAU * 784.0 * t) + 0.3 * sin(TAU * 988.0 * t)
		hn[i] = clampf(s * 0.3, -1.0, 1.0) * e * 0.6
	sounds["horn"] = _wav(hn)
	var n4 = int(0.8 * MIX)
	var wh = PackedFloat32Array()
	wh.resize(n4)
	var l4 = 0.0
	for i in n4:
		var t = float(i) / MIX
		var u = t / 0.8
		var e = sin(PI * u)
		e = e * e
		var c = 0.03 + 0.25 * e
		l4 += (randf() * 2.0 - 1.0 - l4) * c
		wh[i] = l4 * e * 1.3
	sounds["whoosh"] = _wav(wh)

func _gen_music() -> void:
	var chords = [[110.0, 164.8, 220.0, 261.6], [87.3, 130.8, 174.6, 220.0], [130.8, 196.0, 261.6, 329.6], [98.0, 146.8, 196.0, 247.0]]
	var R = float(MUSIC_MIX)
	var total = int(16.0 * R)
	var d = PackedFloat32Array()
	d.resize(total)
	for i in total:
		var t = float(i) / R
		var ci = int(t / 4.0)
		var tl = t - float(ci) * 4.0
		var s = 0.0
		var env = smoothstep(0.0, 1.2, tl) * (1.0 - smoothstep(3.0, 4.2, tl))
		var ch = chords[ci]
		for f in ch:
			s += (sin(TAU * f * t) + sin(TAU * f * 1.004 * t)) * 0.5 * env
		if tl < 0.3:
			var pc = chords[(ci + 3) % 4]
			var penv = 1.0 - smoothstep(3.0, 4.2, tl + 4.0)
			for f in pc:
				s += (sin(TAU * f * t) + sin(TAU * f * 1.004 * t)) * 0.5 * penv
		var step_t = fmod(t, 0.5)
		var note = ch[int(t / 0.5) % 4] * 2.0
		s += sin(TAU * note * t) * exp(-step_t * 6.0) * 1.2
		d[i] = s * 0.06
	var w = _wav(d, MUSIC_MIX, true)
	call_deferred("_music_ready", w)

func _music_ready(w: AudioStreamWAV) -> void:
	music_stream = w
	music_player.stream = w
	music_player.play()

# ------------------------------------------------------------ driving sound
func start_drive(st: Dictionary) -> void:
	cyl = float(st["cyl"])
	idle = float(st["idle"])
	red = float(st["red"])
	ex_idx = int(st.get("exhaust", 0))
	gen_player.play()
	pb = gen_player.get_stream_playback()
	driving = true
	muted = false

func stop_drive() -> void:
	driving = false
	gen_player.stop()
	pb = null

func set_drive_muted(m: bool) -> void:
	muted = m

func update_drive(rpm_n: float, thr: float, speed: float, slip: float, rain: bool, off: bool, brk: float, st: Dictionary) -> void:
	p_rpm = rpm_n
	p_thr = thr
	p_speed = speed
	p_slip = slip
	p_rain = rain
	p_off = off
	p_brk = brk

func _process(dt: float) -> void:
	if driving and pb != null and not muted:
		_fill(dt)

func _fill(dt: float) -> void:
	var n = mini(pb.get_frames_available(), 2200)
	if n <= 0:
		return
	s_rpm = lerpf(s_rpm, p_rpm, 1.0 - exp(-dt * 14.0))
	s_thr = lerpf(s_thr, p_thr, 1.0 - exp(-dt * 8.0))
	var rpm_val = idle + (red - idle) * s_rpm
	var fire = minf(rpm_val / 60.0 * cyl * 0.5, 420.0)
	var load_ = 0.15 + 0.85 * s_thr
	var eg = (0.09 + 0.2 * load_) * (0.75 + 0.25 * s_rpm)
	var lpc = 0.07 + 0.4 * load_ * (0.4 + 0.6 * s_rpm)
	var sub_g = 0.3 + 0.08 * float(ex_idx)
	var wg = pow(clampf(p_speed / 60.0, 0.0, 1.0), 1.7) * 0.5
	var tg = clampf(p_speed / 45.0, 0.0, 1.0) * (0.09 + (0.1 if p_off else 0.0))
	var scr = clampf(p_slip - 0.25, 0.0, 1.0) * (1.0 if p_speed > 8.0 else 0.0)
	var rg = 0.07 if p_rain else 0.0
	var buf = PackedVector2Array()
	buf.resize(n)
	var inv = 1.0 / MIX
	var fph = ph
	var fph2 = ph2
	var fps = ph_s
	var le = lp_e
	var lw = lp_w
	var lt = lp_t
	var tau = TAU
	for i in n:
		fph += fire * inv
		if fph >= 1.0:
			fph -= 1.0
		fph2 += fire * 0.5 * inv
		if fph2 >= 1.0:
			fph2 -= 1.0
		fps += (1500.0 + 500.0 * scr) * inv
		if fps >= 1.0:
			fps -= 1.0
		var e = (fph * 2.0 - 1.0) * 0.5 + sin(tau * fph) * 0.3 + sin(tau * fph2) * sub_g + (0.2 if fph < 0.12 else 0.0)
		le += (e - le) * lpc
		var nz = randf() * 2.0 - 1.0
		lw += (nz - lw) * 0.05
		lt += (nz - lt) * 0.3
		var smp = le * eg + lw * wg + (lt - lw) * tg + nz * rg + sin(tau * fps) * scr * scr * 0.1
		smp = clampf(smp, -1.0, 1.0)
		buf[i] = Vector2(smp, smp)
	ph = fph
	ph2 = fph2
	ph_s = fps
	lp_e = le
	lp_w = lw
	lp_t = lt
	pb.push_buffer(buf)
