extends Node
## All menus, built in code (no hidden dead buttons: every control is wired).

const HudScript = preload("res://scripts/ui/hud.gd")
const Cust = preload("res://scripts/game/customization_manager.gd")

var layer: CanvasLayer
var root: Control
var hud
var content: Control
var theme: Theme
var shop_idx := 0
var garage_idx := 0
var cust_tab := 0
var money_lbl: Label
const ACCENT := Color(1.0, 0.62, 0.1)

func _ready() -> void:
	layer = CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	_make_theme()
	root.theme = theme
	hud = HudScript.new()
	root.add_child(hud)

func _make_theme() -> void:
	theme = Theme.new()
	theme.default_font_size = 26
	var n = _flat(Color(0.12, 0.14, 0.2, 0.92), Color(1, 1, 1, 0.2), 14)
	var h = _flat(Color(0.2, 0.23, 0.32, 0.95), ACCENT, 14)
	var p = _flat(ACCENT.darkened(0.15), Color.WHITE, 14)
	theme.set_stylebox("normal", "Button", n)
	theme.set_stylebox("hover", "Button", h)
	theme.set_stylebox("pressed", "Button", p)
	theme.set_stylebox("focus", "Button", h)
	theme.set_stylebox("panel", "PanelContainer", _flat(Color(0.04, 0.05, 0.09, 0.82), Color(1, 1, 1, 0.12), 20))
	var fill = _flat(ACCENT, ACCENT, 6)
	var bg = _flat(Color(1, 1, 1, 0.12), Color(1, 1, 1, 0), 6)
	theme.set_stylebox("fill", "ProgressBar", fill)
	theme.set_stylebox("background", "ProgressBar", bg)
	theme.set_stylebox("slider", "HSlider", bg)
	theme.set_stylebox("grabber_area", "HSlider", fill)
	theme.set_stylebox("grabber_area_highlight", "HSlider", fill)

func _flat(bg: Color, border: Color, r: int) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(r)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

# ------------------------------------------------------------ helpers
func _clear() -> void:
	if content != null:
		content.queue_free()
		content = null
	money_lbl = null

func _vsize() -> Vector2:
	return get_viewport().get_visible_rect().size

func _label(text: String, size_: int = 26, col: Color = Color.WHITE) -> Label:
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size_)
	l.add_theme_color_override("font_color", col)
	return l

func _button(text: String, cb: Callable, minsize: Vector2 = Vector2(0, 62)) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = minsize
	b.pressed.connect(func():
		Sfx.play("click", -4.0)
		cb.call())
	return b

func _btn(text: String, minsize: Vector2, cb: Callable) -> Button:
	return _button(text, cb, minsize)

func _menu_toast(msg: String) -> void:
	var l = _label(msg, 30, Color(1.0, 0.4, 0.3))
	l.position = Vector2(_vsize().x * 0.5 - 150.0, _vsize().y - 90.0)
	root.add_child(l)
	var tw = create_tween()
	tw.tween_interval(1.2)
	tw.tween_callback(l.queue_free)

func _money() -> void:
	money_lbl = _label(GameData.fmt_money(Save.money()), 38, Color(0.5, 1.0, 0.6))
	money_lbl.position = Vector2(_vsize().x - 300.0, 18.0)
	money_lbl.size = Vector2(280, 50)
	money_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	content.add_child(money_lbl)

func _frame(title: String, back: String = "menu", width: float = 580.0) -> VBoxContainer:
	_clear()
	hud.visible = false
	content = Control.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(content)
	var vs = _vsize()
	var panel = PanelContainer.new()
	panel.position = Vector2(20, 20)
	panel.custom_minimum_size = Vector2(width, vs.y - 40.0)
	panel.size = Vector2(width, vs.y - 40.0)
	content.add_child(panel)
	var m = MarginContainer.new()
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 18)
	panel.add_child(m)
	var outer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", 10)
	m.add_child(outer)
	outer.add_child(_label(title, 40, ACCENT))
	var sc = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(sc)
	var vb = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 10)
	sc.add_child(vb)
	outer.add_child(_button("BACK", func(): show_screen(back)))
	_money()
	return vb

func _opt(parent: Control, label: String, values: Array, idx: int, cb: Callable, tags: Array = []) -> void:
	var box = VBoxContainer.new()
	parent.add_child(box)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	box.add_child(row)
	var l = _label(label, 24)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	var st = [idx]
	var vl = _label("", 24, Color(1.0, 0.85, 0.5))
	vl.custom_minimum_size = Vector2(190, 0)
	vl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var upd = func():
		vl.text = str(values[st[0]]) + (("  " + str(tags[st[0]])) if tags.size() > st[0] else "")
	upd.call()
	var bl = _btn("<", Vector2(64, 56), func():
		st[0] = (st[0] - 1 + values.size()) % values.size()
		upd.call()
		cb.call(st[0]))
	var br = _btn(">", Vector2(64, 56), func():
		st[0] = (st[0] + 1) % values.size()
		upd.call()
		cb.call(st[0]))
	row.add_child(bl)
	row.add_child(vl)
	row.add_child(br)

func _slider(parent: Control, label: String, lo: float, hi: float, step: float, val: float, cb: Callable) -> void:
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	parent.add_child(row)
	var l = _label(label, 24)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	var s = HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.value = val
	s.custom_minimum_size = Vector2(230, 44)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(s)
	var vl = _label("%.2f" % val, 22, Color(1.0, 0.85, 0.5))
	vl.custom_minimum_size = Vector2(70, 0)
	row.add_child(vl)
	s.value_changed.connect(func(v):
		vl.text = "%.2f" % v
		cb.call(v))

func _toggle(parent: Control, label: String, val: bool, cb: Callable) -> void:
	var row = HBoxContainer.new()
	parent.add_child(row)
	var l = _label(label, 24)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	var c = CheckButton.new()
	c.button_pressed = val
	c.toggled.connect(func(b):
		Sfx.play("click", -4.0)
		cb.call(b))
	row.add_child(c)

func _bar(parent: Control, label: String, frac: float, txt: String) -> void:
	var row = HBoxContainer.new()
	parent.add_child(row)
	var l = _label(label, 22)
	l.custom_minimum_size = Vector2(140, 0)
	row.add_child(l)
	var b = ProgressBar.new()
	b.min_value = 0.0
	b.max_value = 1.0
	b.value = clampf(frac, 0.0, 1.0)
	b.show_percentage = false
	b.custom_minimum_size = Vector2(190, 20)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(b)
	var t = _label(txt, 20, Color(0.85, 0.9, 1.0))
	t.custom_minimum_size = Vector2(100, 0)
	row.add_child(t)

func _stats_bars(parent: Control, st: Dictionary) -> void:
	_bar(parent, "Top speed", (float(st["top"]) * 3.6 - 120.0) / 240.0, "%d km/h" % int(float(st["top"]) * 3.6))
	_bar(parent, "Acceleration", (float(st["accel"]) - 2.5) / 7.0, "%.1f m/s²" % float(st["accel"]))
	_bar(parent, "Handling", (float(st["steer"]) * float(st["grip"]) - 0.7) / 1.0, "%.2f" % (float(st["steer"]) * float(st["grip"])))
	_bar(parent, "Braking", (float(st["brake"]) - 7.0) / 6.0, "%.1f m/s²" % float(st["brake"]))
	_bar(parent, "Weight", (float(st["weight"]) - 900.0) / 1300.0, "%d kg" % int(float(st["weight"])))
	_bar(parent, "Grip", (float(st["grip"]) - 0.85) / 0.5, "%.2f" % float(st["grip"]))

# ------------------------------------------------------------ screens
func show_screen(name: String) -> void:
	match name:
		"menu":
			_menu()
		"setup":
			_setup()
		"cars":
			_cars()
		"garage":
			_garage()
		"custom":
			_custom()
		"stats":
			_stats()
		"settings":
			_settings()

func _menu() -> void:
	_clear()
	hud.visible = false
	content = Control.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(content)
	var vb = VBoxContainer.new()
	vb.position = Vector2(40, 30)
	vb.add_theme_constant_override("separation", 14)
	content.add_child(vb)
	vb.add_child(_label("HIGHWAY DRIVE", 54, ACCENT))
	var car = GameData.car_by_id(Save.data["current_car"])
	vb.add_child(_label("Your car: " + String(car["name"]), 24, Color(0.85, 0.9, 1.0)))
	for e in [["DRIVE", "setup"], ["CARS", "cars"], ["GARAGE", "garage"], ["CUSTOMIZE", "custom"], ["STATS", "stats"], ["SETTINGS", "settings"]]:
		var target = e[1]
		var b = _btn(e[0], Vector2(360, 66), func(): show_screen(target))
		if e[0] == "DRIVE":
			b.add_theme_font_size_override("font_size", 36)
		vb.add_child(b)
	_money()
	GM.main.showroom.show_car(Save.data["current_car"])

func _setup() -> void:
	var vb = _frame("DRIVE", "menu")
	_opt(vb, "Mode", GameData.MODE_NAMES, Save.su("mode"), func(i):
		Save.set_u("mode", i)
		_setup())
	if Save.su("mode") == 1:
		var names = []
		for t in GameData.TIME_LIMITS:
			names.append("%d min" % (int(t) / 60))
		_opt(vb, "Time limit", names, Save.su("tl"), func(i): Save.set_u("tl", i))
	var mnames = []
	for m in GameData.MAPS:
		mnames.append(m["name"])
	_opt(vb, "Map", mnames, Save.su("map"), func(i):
		Save.set_u("map", i))
	_opt(vb, "Time of day", GameData.TOD_NAMES, Save.su("tod"), func(i): Save.set_u("tod", i))
	_opt(vb, "Weather", GameData.WEATHER_NAMES, Save.su("weather"), func(i): Save.set_u("weather", i))
	_opt(vb, "Road", ["One-way", "Two-way"], Save.su("road"), func(i): Save.set_u("road", i))
	_opt(vb, "Difficulty", GameData.DIFF_NAMES, Save.su("diff"), func(i): Save.set_u("diff", i))
	_slider(vb, "Traffic density", 0.1, 1.0, 0.05, float(Save.data["setup"]["density"]), func(v): Save.set_u("density", v))
	_opt(vb, "Camera", ["Third person", "First person"], Save.si("pov"), func(i): Save.set_s("pov", i))
	_opt(vb, "Steering", ["Wheel", "Touch", "Tilt"], Save.si("steer_mode"), func(i): Save.set_s("steer_mode", i))
	var go = _btn("START DRIVING", Vector2(0, 76), func():
		Save.save_now()
		GM.start_run())
	go.add_theme_font_size_override("font_size", 34)
	vb.add_child(go)
	GM.main.showroom.show_car(Save.data["current_car"])

func _cars() -> void:
	var vb = _frame("CAR DEALERSHIP", "menu")
	var car = GameData.CARS[shop_idx]
	var id = String(car["id"])
	GM.main.showroom.show_car(id)
	var nav = HBoxContainer.new()
	vb.add_child(nav)
	nav.add_child(_btn("<", Vector2(70, 60), func():
		shop_idx = (shop_idx - 1 + GameData.CARS.size()) % GameData.CARS.size()
		_cars()))
	var nm = _label(String(car["name"]), 30, Color.WHITE)
	nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nav.add_child(nm)
	nav.add_child(_btn(">", Vector2(70, 60), func():
		shop_idx = (shop_idx + 1) % GameData.CARS.size()
		_cars()))
	var st = Cust.effective(id)
	_stats_bars(vb, st)
	if Save.owned(id):
		vb.add_child(_label("OWNED", 30, Color(0.5, 1.0, 0.6)))
		if Save.data["current_car"] != id:
			vb.add_child(_button("SELECT THIS CAR", func():
				Save.data["current_car"] = id
				Save.mark()
				_cars()))
		else:
			vb.add_child(_label("Currently selected", 22, Color(0.8, 0.85, 1.0)))
	else:
		vb.add_child(_label("Price: " + GameData.fmt_money(car["price"]), 32, Color(1.0, 0.9, 0.4)))
		var buy = _button("BUY", func():
			var err = Cust.buy_car(id)
			if err == "":
				Sfx.play("buy")
				Save.data["current_car"] = id
				Save.mark()
			else:
				Sfx.play("error")
			_cars())
		buy.disabled = Save.money() < int(car["price"])
		vb.add_child(buy)
		if buy.disabled:
			vb.add_child(_label("Earn money by driving!", 22, Color(1.0, 0.6, 0.5)))

func _garage() -> void:
	var vb = _frame("GARAGE", "menu")
	var owned = Save.owned_ids()
	garage_idx = clampi(garage_idx, 0, owned.size() - 1)
	var id = String(owned[garage_idx])
	GM.main.showroom.show_car(id)
	var nav = HBoxContainer.new()
	vb.add_child(nav)
	nav.add_child(_btn("<", Vector2(70, 60), func():
		garage_idx = (garage_idx - 1 + owned.size()) % owned.size()
		_garage()))
	var nm = _label(String(GameData.car_by_id(id)["name"]), 30)
	nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nav.add_child(nm)
	nav.add_child(_btn(">", Vector2(70, 60), func():
		garage_idx = (garage_idx + 1) % owned.size()
		_garage()))
	_stats_bars(vb, Cust.effective(id))
	var cs = Save.car_state(id)
	for u in GameData.UPGRADES:
		vb.add_child(_label("%s  Lv %d/5" % [u["name"], Cust.upgrade_level(cs, u["key"])], 22, Color(0.85, 0.9, 1.0)))
	if Save.data["current_car"] != id:
		vb.add_child(_button("SELECT FOR DRIVING", func():
			Save.data["current_car"] = id
			Save.mark()
			_garage()))
	else:
		vb.add_child(_label("Selected for driving", 24, Color(0.5, 1.0, 0.6)))
	vb.add_child(_button("CUSTOMIZE / UPGRADE", func():
		Save.data["current_car"] = id
		Save.mark()
		show_screen("custom")))

func _custom() -> void:
	var id = String(Save.data["current_car"])
	var st = Save.car_state(id)
	var vb = _frame("CUSTOMIZE  -  " + String(GameData.car_by_id(id)["name"]), "menu", 640.0)
	GM.main.showroom.show_car(id)
	var tabs = HFlowContainer.new()
	vb.add_child(tabs)
	for i in GameData.TAB_NAMES.size():
		var t = i
		var b = _btn(GameData.TAB_NAMES[i], Vector2(0, 52), func():
			cust_tab = t
			_custom())
		b.add_theme_font_size_override("font_size", 22)
		if i == cust_tab:
			b.modulate = Color(1.0, 0.75, 0.3)
		tabs.add_child(b)
	if cust_tab == 0:
		vb.add_child(_label("Paint (free)", 24))
		var grid = GridContainer.new()
		grid.columns = 6
		vb.add_child(grid)
		for hx in GameData.PALETTE:
			var h = String(hx)
			var b = Button.new()
			b.custom_minimum_size = Vector2(70, 56)
			b.add_theme_stylebox_override("normal", _flat(Color.html(h), Color.WHITE, 10))
			b.add_theme_stylebox_override("hover", _flat(Color.html(h).lightened(0.15), ACCENT, 10))
			b.add_theme_stylebox_override("pressed", _flat(Color.html(h), ACCENT, 10))
			b.pressed.connect(func():
				st["paint"] = h
				Save.mark()
				Sfx.play("click", -4.0)
				GM.main.showroom.refresh())
			grid.add_child(b)
		var hue = Color.html(String(st["paint"])).h
		_slider(vb, "Custom hue", 0.0, 1.0, 0.01, hue, func(v):
			st["paint"] = "#" + Color.from_hsv(v, 0.75, 0.8).to_html(false)
			Save.mark()
			GM.main.showroom.refresh())
	elif cust_tab == 5:
		_upgrades(vb, id)
	else:
		for c in GameData.CUSTOM:
			if int(c["tab"]) != cust_tab:
				continue
			var key = String(c["key"])
			var tags = []
			for i in c["names"].size():
				tags.append("owned" if Cust.is_owned(st, key, i) else GameData.fmt_money(c["prices"][i]))
			var on_pick = func(i):
				var err = Cust.select(id, key, i)
				if err != "":
					Sfx.play("error")
					_menu_toast(err)
				else:
					Sfx.play("click", -4.0)
				_custom()
			_opt(vb, c["label"], c["names"], Cust.get_idx(st, key), on_pick, tags)
		if cust_tab == 3:
			var le = LineEdit.new()
			le.text = String(st.get("plate", "HWY 001"))
			le.max_length = 8
			le.custom_minimum_size = Vector2(0, 58)
			le.text_changed.connect(func(t):
				st["plate"] = t.to_upper()
				Save.mark())
			le.text_submitted.connect(func(t): GM.main.showroom.refresh())
			le.focus_exited.connect(func(): GM.main.showroom.refresh())
			vb.add_child(_label("License plate", 24))
			vb.add_child(le)

func _upgrades(vb: Control, id: String) -> void:
	var st = Save.car_state(id)
	for u in GameData.UPGRADES:
		var key = String(u["key"])
		var lvl = Cust.upgrade_level(st, key)
		vb.add_child(_label("%s   Lv %d / 5" % [u["name"], lvl], 26, Color.WHITE))
		vb.add_child(_label(String(u["desc"]), 20, Color(0.7, 0.8, 1.0)))
		if lvl < 5:
			var cost = Cust.upgrade_cost(id, lvl)
			var b = _button("UPGRADE  " + GameData.fmt_money(cost), func():
				var err = Cust.buy_upgrade(id, key)
				if err == "":
					Sfx.play("buy")
				else:
					Sfx.play("error")
				_custom())
			b.disabled = Save.money() < cost
			vb.add_child(b)
		else:
			vb.add_child(_label("MAX", 24, Color(0.5, 1.0, 0.6)))
	_stats_bars(vb, Cust.effective(id))

func _stats() -> void:
	var vb = _frame("STATISTICS", "menu")
	var s = Save.data["stats"]
	var rows = [
		["Total distance", GameData.fmt_dist(float(s["total_dist"]))],
		["Best distance", GameData.fmt_dist(float(s["best_dist"]))],
		["Highest speed", "%d %s" % [int(GameData.speed_val(float(s["top_speed"]))), GameData.speed_unit()]],
		["Total driving time", GameData.fmt_time(float(s["total_time"]))],
		["Cars owned", str(Save.owned_ids().size()) + " / " + str(GameData.CARS.size())],
		["Total money earned", GameData.fmt_money(float(s["money_total"]))],
		["Overtakes", str(int(s["overtakes"]))],
		["Near misses", str(int(s["near_misses"]))],
		["Collisions", str(int(s["collisions"]))],
		["Longest high-speed streak", GameData.fmt_time(float(s["best_streak"]))],
	]
	for r in rows:
		var row = HBoxContainer.new()
		vb.add_child(row)
		var a = _label(r[0], 24)
		a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(a)
		row.add_child(_label(r[1], 24, Color(1.0, 0.85, 0.5)))
	for k in Save.data["best_ta"].keys():
		vb.add_child(_label("Time attack %d min: %s" % [int(k) / 60, GameData.fmt_dist(float(Save.data["best_ta"][k]))], 22, Color(0.8, 0.9, 1.0)))
	GM.main.showroom.show_car(Save.data["current_car"])

func _settings() -> void:
	var vb = _frame("SETTINGS", "menu", 640.0)
	vb.add_child(_label("Graphics", 28, ACCENT))
	_opt(vb, "Quality preset", GameData.QUALITY_NAMES, Save.si("quality"), func(i):
		GM.apply_quality_preset(i)
		_settings())
	_opt(vb, "Shadow quality", ["Off", "Low", "Medium", "High"], Save.si("shadow"), func(i):
		Save.set_s("shadow", i)
		GM.apply_graphics())
	_opt(vb, "Traffic (graphics)", ["Light", "Medium", "Full"], Save.si("traffic_gfx"), func(i): Save.set_s("traffic_gfx", i))
	_opt(vb, "Render distance", ["300 m", "450 m", "650 m", "900 m"], Save.si("render"), func(i): Save.set_s("render", i))
	_opt(vb, "Effects quality", ["Low", "Medium", "High"], Save.si("fx"), func(i): Save.set_s("fx", i))
	_opt(vb, "FPS limit", ["30", "60", "90", "120"], [30, 60, 90, 120].find(Save.si("fps")), func(i):
		Save.set_s("fps", [30, 60, 90, 120][i])
		GM.apply_graphics())
	_toggle(vb, "Weather effects", Save.sb("weather_fx"), func(b): Save.set_s("weather_fx", b))
	_opt(vb, "Damage", ["Off", "Normal", "Realistic"], Save.si("damage"), func(i): Save.set_s("damage", i))
	vb.add_child(_label("Driving", 28, ACCENT))
	_slider(vb, "Traffic density", 0.1, 1.0, 0.05, float(Save.data["setup"]["density"]), func(v): Save.set_u("density", v))
	_opt(vb, "Steering", ["Wheel", "Touch", "Tilt (gyro)"], Save.si("steer_mode"), func(i): Save.set_s("steer_mode", i))
	_opt(vb, "Control layout", ["Standard", "Mirrored"], Save.si("layout"), func(i): Save.set_s("layout", i))
	_slider(vb, "Steering sensitivity", 0.5, 2.0, 0.05, Save.sf("steer_sens"), func(v): Save.set_s("steer_sens", v))
	_slider(vb, "Gyro sensitivity", 0.5, 2.0, 0.05, Save.sf("gyro_sens"), func(v): Save.set_s("gyro_sens", v))
	_toggle(vb, "Invert gyro", Save.sb("gyro_invert"), func(b): Save.set_s("gyro_invert", b))
	vb.add_child(_button("CALIBRATE GYRO (hold phone level, then tap)", func():
		GM.input.calibrate()
		Sfx.play("confirm")))
	_opt(vb, "Camera", ["Third person", "First person"], Save.si("pov"), func(i): Save.set_s("pov", i))
	_slider(vb, "Camera distance", 0.7, 1.5, 0.05, Save.sf("cam_dist"), func(v): Save.set_s("cam_dist", v))
	_slider(vb, "Camera sensitivity", 0.5, 2.0, 0.05, Save.sf("cam_sens"), func(v): Save.set_s("cam_sens", v))
	_opt(vb, "Speed unit", ["KM/H", "MPH"], Save.si("units"), func(i): Save.set_s("units", i))
	vb.add_child(_label("Audio & feedback", 28, ACCENT))
	_slider(vb, "Sound volume", 0.0, 1.0, 0.05, Save.sf("vol_sfx"), func(v):
		Save.set_s("vol_sfx", v)
		Sfx.apply_volumes())
	_slider(vb, "Music volume", 0.0, 1.0, 0.05, Save.sf("vol_music"), func(v):
		Save.set_s("vol_music", v)
		Sfx.apply_volumes())
	_toggle(vb, "Music", Save.sb("music_on"), func(b):
		Save.set_s("music_on", b)
		Sfx.apply_volumes())
	_toggle(vb, "Vibration", Save.sb("vibration"), func(b): Save.set_s("vibration", b))
	GM.main.showroom.show_car(Save.data["current_car"])

func show_hud(cfg: Dictionary) -> void:
	_clear()
	hud.activate(cfg)

func show_results(r: Dictionary) -> void:
	hud.visible = false
	hud.show_pause(false)
	_clear()
	content = Control.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(content)
	var vs = _vsize()
	var panel = PanelContainer.new()
	content.add_child(panel)
	var m = MarginContainer.new()
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 26)
	panel.add_child(m)
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	m.add_child(vb)
	var title = {"crash": "CRASHED", "time": "TIME UP", "quit": "RUN ENDED"}.get(String(r["reason"]), "RUN COMPLETE")
	vb.add_child(_label(title, 48, Color(1.0, 0.4, 0.3) if r["reason"] == "crash" else ACCENT))
	if r["record"]:
		vb.add_child(_label("NEW RECORD!", 32, Color(1.0, 0.9, 0.3)))
	var rows = [
		["Distance", GameData.fmt_dist(float(r["dist"]))],
		["Time", GameData.fmt_time(float(r["time"]))],
		["Top speed", "%d %s" % [int(GameData.speed_val(float(r["top"]))), GameData.speed_unit()]],
		["Overtakes", str(r["overtakes"])],
		["Near misses", str(r["near"])],
		["Collisions", str(r["collisions"])],
		["High-speed streak", GameData.fmt_time(float(r["streak"]))],
		["Money earned", GameData.fmt_money(r["earned"])],
	]
	for row in rows:
		var h = HBoxContainer.new()
		vb.add_child(h)
		var a = _label(row[0], 28)
		a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(a)
		h.add_child(_label(row[1], 28, Color(1.0, 0.85, 0.5)))
	var br = HBoxContainer.new()
	br.add_theme_constant_override("separation", 14)
	vb.add_child(br)
	br.add_child(_btn("DRIVE AGAIN", Vector2(260, 68), func():
		GM.leave_run()
		GM.start_run()))
	br.add_child(_btn("MENU", Vector2(200, 68), func(): GM.leave_run()))
	panel.size = Vector2(620, 0)
	panel.position = Vector2((vs.x - 620.0) * 0.5, vs.y * 0.12)
