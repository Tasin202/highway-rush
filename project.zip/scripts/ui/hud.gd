extends Control
## In-run HUD: speedometer, run info, steering wheel, pedals, pause menu, toasts.

var d := {}
var font: Font
var sb_idle: StyleBoxFlat
var sb_down: StyleBoxFlat
var sb_panel: StyleBoxFlat
var toast_box: VBoxContainer
var pause_panel: PanelContainer
var pause_btn: Button
var horn_btn: Button
var speedo_c := Vector2.ZERO
var speedo_r := 120.0
var mode_steer := 0
var layout_n := -1
var pause_vb: VBoxContainer
var cam_btn: Button
var steer_btn: Button

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	font = ThemeDB.fallback_font
	sb_idle = _sb(Color(0.1, 0.12, 0.18, 0.55), Color(1, 1, 1, 0.35))
	sb_down = _sb(Color(1.0, 0.62, 0.1, 0.75), Color(1, 1, 1, 0.8))
	sb_panel = _sb(Color(0.05, 0.06, 0.1, 0.92), Color(1.0, 0.62, 0.1, 0.9))
	toast_box = VBoxContainer.new()
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	add_child(toast_box)
	pause_btn = Button.new()
	pause_btn.text = "II"
	pause_btn.add_theme_font_size_override("font_size", 34)
	pause_btn.custom_minimum_size = Vector2(84, 64)
	pause_btn.pressed.connect(func(): GM.set_paused(true))
	add_child(pause_btn)
	horn_btn = Button.new()
	horn_btn.text = "HORN"
	horn_btn.add_theme_font_size_override("font_size", 22)
	horn_btn.custom_minimum_size = Vector2(110, 64)
	horn_btn.pressed.connect(func(): Sfx.play("horn", -2.0, 0.95))
	add_child(horn_btn)
	_build_pause()
	resized.connect(_layout)
	visible = false

func _sb(bg: Color, border: Color) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(3)
	s.set_corner_radius_all(22)
	return s

func _build_pause() -> void:
	pause_panel = PanelContainer.new()
	pause_panel.add_theme_stylebox_override("panel", sb_panel)
	pause_panel.visible = false
	add_child(pause_panel)
	var m = MarginContainer.new()
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 24)
	pause_panel.add_child(m)
	pause_vb = VBoxContainer.new()
	pause_vb.add_theme_constant_override("separation", 12)
	m.add_child(pause_vb)
	var t = Label.new()
	t.text = "PAUSED"
	t.add_theme_font_size_override("font_size", 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_vb.add_child(t)
	pause_vb.add_child(_pb("RESUME", func(): GM.set_paused(false)))
	cam_btn = _pb("", func():
		GM.cam.set_pov(not GM.cam.fp)
		_refresh_pause())
	pause_vb.add_child(cam_btn)
	steer_btn = _pb("", func():
		Save.set_s("steer_mode", (Save.si("steer_mode") + 1) % 3)
		if Save.si("steer_mode") == 2:
			GM.input.calibrate()
		GM.input.reset()
		_layout()
		_refresh_pause())
	pause_vb.add_child(steer_btn)
	pause_vb.add_child(_pb("CALIBRATE TILT", func(): GM.input.calibrate()))
	pause_vb.add_child(_pb("END RUN", func(): GM.quit_to_results()))

func _pb(text: String, cb: Callable) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(380, 62)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(cb)
	return b

func _refresh_pause() -> void:
	cam_btn.text = "VIEW: " + ("FIRST PERSON" if GM.cam.fp else "THIRD PERSON")
	steer_btn.text = "STEERING: " + ["WHEEL", "TOUCH", "TILT"][Save.si("steer_mode")]

func show_pause(p: bool) -> void:
	pause_panel.visible = p
	if p:
		_refresh_pause()
		pause_panel.reset_size()
		pause_panel.position = (size - pause_panel.size) * 0.5

func activate(cfg: Dictionary) -> void:
	visible = true
	d = {}
	for c in toast_box.get_children():
		c.queue_free()
	pause_panel.visible = false
	layout_n = -1
	_layout()

func _layout() -> void:
	var sz = size
	if sz.x < 10.0:
		sz = get_viewport_rect().size
	var mirror = Save.si("layout") == 1
	mode_steer = Save.si("steer_mode")
	var pw = clampf(sz.x * 0.12, 120.0, 200.0)
	var ah = sz.y * 0.34
	var bh = sz.y * 0.24
	var ax = sz.x - pw - 24.0
	var bx = ax - pw - 16.0
	var accel = Rect2(ax, sz.y - ah - 24.0, pw, ah)
	var brake = Rect2(bx, sz.y - bh - 24.0, pw, bh)
	var wr = sz.y * 0.19
	var wc = Vector2(wr + 36.0, sz.y - wr - 28.0)
	if mode_steer != 0:
		# split layout: brake bottom-left, accelerator bottom-right
		brake = Rect2(24.0, sz.y - bh - 24.0, pw, bh)
		wc = Vector2(-1000, -1000)
	if mirror:
		accel.position.x = sz.x - accel.position.x - accel.size.x
		brake.position.x = sz.x - brake.position.x - brake.size.x
		if mode_steer == 0:
			wc.x = sz.x - wc.x
	GM.input.accel_rect = accel
	GM.input.brake_rect = brake
	GM.input.wheel_center = wc
	GM.input.wheel_radius = wr
	pause_btn.position = Vector2(sz.x - 100.0, 14.0)
	horn_btn.position = Vector2(sz.x - 224.0, 14.0)
	GM.input.block_rects = [Rect2(pause_btn.position, pause_btn.size), Rect2(horn_btn.position, horn_btn.size)]
	speedo_r = sz.y * 0.16
	speedo_c = Vector2(sz.x * 0.5, sz.y - speedo_r - 16.0)
	toast_box.position = Vector2(sz.x * 0.5 - 220.0, sz.y * 0.16)
	toast_box.size = Vector2(440, 200)
	if pause_panel.visible:
		pause_panel.position = (sz - pause_panel.size) * 0.5
	queue_redraw()

func update_hud(data: Dictionary) -> void:
	d = data
	queue_redraw()

func toast(text: String, col: Color) -> void:
	if toast_box.get_child_count() > 3:
		toast_box.get_child(0).queue_free()
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.add_child(l)
	var tw = create_tween()
	tw.tween_interval(1.1)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)

func _text(s: String, pos: Vector2, size_: int, col: Color, align = HORIZONTAL_ALIGNMENT_LEFT, w: float = -1.0) -> void:
	draw_string_outline(font, pos, s, align, w, size_, 6, Color(0, 0, 0, 0.8))
	draw_string(font, pos, s, align, w, size_, col)

func _draw() -> void:
	if d.is_empty():
		return
	var inp = GM.input
	# speedometer
	var c = speedo_c
	var r = speedo_r
	var top_disp = float(d["top"]) * (1.0 if Save.si("units") == 0 else 0.6214)
	var frac = clampf(float(d["speed"]) / maxf(top_disp, 1.0), 0.0, 1.0)
	draw_arc(c, r, deg_to_rad(135.0), deg_to_rad(405.0), 48, Color(0, 0, 0, 0.45), 16.0, true)
	draw_arc(c, r, deg_to_rad(135.0), deg_to_rad(405.0), 48, Color(1, 1, 1, 0.18), 8.0, true)
	var col = Color(0.4, 0.9, 1.0).lerp(Color(1.0, 0.35, 0.2), frac)
	if frac > 0.01:
		draw_arc(c, r, deg_to_rad(135.0), deg_to_rad(135.0 + 270.0 * frac), 48, col, 10.0, true)
	draw_arc(c, r - 18.0, deg_to_rad(135.0), deg_to_rad(135.0 + 270.0 * float(d["rpm"])), 40, Color(1.0, 0.7, 0.2, 0.7), 4.0, true)
	_text(str(int(d["speed"])), c + Vector2(-80, 14), int(r * 0.55), Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 160.0)
	_text(String(d["unit"]), c + Vector2(-60, 44), 22, Color(0.8, 0.85, 1.0), HORIZONTAL_ALIGNMENT_CENTER, 120.0)
	_text("G" + str(d["gear"]), c + Vector2(-40, r * 0.78), 24, Color(1.0, 0.75, 0.3), HORIZONTAL_ALIGNMENT_CENTER, 80.0)
	# run info (top-left)
	var y = 44.0
	_text(GameData.fmt_dist(float(d["dist"])), Vector2(24, y), 34, Color.WHITE)
	y += 42.0
	if int(d["mode"]) == 1:
		var tl = float(d["time_left"])
		_text("TIME  " + GameData.fmt_time(tl), Vector2(24, y), 30, Color(1.0, 0.85, 0.3) if tl > 10.0 else Color(1.0, 0.3, 0.3))
	else:
		_text("TIME  " + GameData.fmt_time(float(d["time"])), Vector2(24, y), 30, Color(0.85, 0.9, 1.0))
	y += 40.0
	_text(GameData.fmt_money(float(d["money"])), Vector2(24, y), 34, Color(0.5, 1.0, 0.6))
	if int(d["tier"]) > 0:
		_text("x%.1f SPEED" % float(d["mult"]), Vector2(24, y + 40.0), 28, Color(1.0, 0.8, 0.2))
	# damage bar
	var dm = float(d["damage"]) / 100.0
	if dm > 0.001:
		var bx = Rect2(size.x - 224.0, 90.0, 200.0, 12.0)
		draw_rect(bx, Color(0, 0, 0, 0.5))
		draw_rect(Rect2(bx.position, Vector2(bx.size.x * dm, bx.size.y)), Color(1.0, 0.3, 0.2))
		_text("DAMAGE", Vector2(bx.position.x, bx.position.y - 4.0), 18, Color(1, 0.8, 0.8))
	# controls
	if mode_steer == 0:
		var wc = inp.wheel_center
		var wr = inp.wheel_radius
		draw_circle(wc, wr * 1.05, Color(0, 0, 0, 0.25))
		draw_arc(wc, wr, 0.0, TAU, 48, Color(0.9, 0.9, 0.95, 0.85), 14.0, true)
		for a in [0.0, 2.094, 4.188]:
			var ang = a + inp.wheel_angle - PI * 0.5
			draw_line(wc, wc + Vector2(cos(ang), sin(ang)) * wr, Color(0.9, 0.9, 0.95, 0.7), 8.0, true)
		var top_a = inp.wheel_angle - PI * 0.5
		draw_circle(wc + Vector2(cos(top_a), sin(top_a)) * wr, 10.0, Color(1.0, 0.62, 0.1))
		draw_circle(wc, wr * 0.18, Color(0.15, 0.15, 0.2, 0.9))
	elif mode_steer == 1:
		var vs = get_viewport_rect().size
		draw_line(Vector2(vs.x * 0.5, vs.y * 0.3), Vector2(vs.x * 0.5, vs.y * 0.55), Color(1, 1, 1, 0.08), 3.0)
		if inp.touch_dir < 0.0:
			draw_rect(Rect2(0, vs.y * 0.2, 14, vs.y * 0.5), Color(1.0, 0.62, 0.1, 0.5))
		elif inp.touch_dir > 0.0:
			draw_rect(Rect2(vs.x - 14, vs.y * 0.2, 14, vs.y * 0.5), Color(1.0, 0.62, 0.1, 0.5))
	else:
		var bw = 240.0
		var bc = Vector2(size.x * 0.5, 28.0)
		draw_rect(Rect2(bc.x - bw * 0.5, bc.y, bw, 8.0), Color(1, 1, 1, 0.2))
		draw_rect(Rect2(bc.x + inp.steer * bw * 0.5 - 6.0, bc.y - 6.0, 12.0, 20.0), Color(1.0, 0.62, 0.1))
	draw_style_box(sb_down if inp.accel_down else sb_idle, inp.accel_rect)
	_text("GAS", inp.accel_rect.position + Vector2(0, inp.accel_rect.size.y * 0.55), 34, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, inp.accel_rect.size.x)
	draw_style_box(sb_down if inp.brake_down else sb_idle, inp.brake_rect)
	_text("BRAKE", inp.brake_rect.position + Vector2(0, inp.brake_rect.size.y * 0.55), 30, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, inp.brake_rect.size.x)
